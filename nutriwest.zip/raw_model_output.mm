<map version="1.0.1">
<node TEXT="Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Sign In As Provider Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Positive Functional" FOLDED="true">
<node TEXT="1. Verify that a registered provider can successfully sign in using valid email and password." />
<node TEXT="2. Verify that the 'Remember Me' checkbox retains the user's session after closing and reopening the browser." />
<node TEXT="3. Verify that the 'Did you forget your username or password?' link navigates to the password recovery page." />
<node TEXT="4. Verify that the sign-in form fields accept valid email and password input formats." />
<node TEXT="5. Verify that the user is redirected to the provider dashboard upon successful sign-in." />
<node TEXT="6. Verify that the 'Sign Up For Professional Account' link navigates to the account creation page." />
<node TEXT="7. Verify that the sign-in page loads correctly and displays all required fields and links." />
<node TEXT="8. Verify that the 'Sign In' button is enabled only when both email and password fields are filled." />
<node TEXT="9. Verify that the user can log out successfully after signing in as a provider." />
<node TEXT="10. Verify that the sign-in form supports keyboard navigation and accessibility standards." />
</node>
<node TEXT="Negative Functional" FOLDED="true">
<node TEXT="1. Verify that an error message is displayed when an invalid email format is entered." />
<node TEXT="2. Verify that an error message is shown when an incorrect password is provided." />
<node TEXT="3. Verify that the sign-in form does not submit when required fields are left blank." />
<node TEXT="4. Verify that the account is locked after multiple failed sign-in attempts, if applicable." />
<node TEXT="5. Verify that the 'Sign In' button remains disabled when only one field is filled." />
<node TEXT="6. Verify that the system does not allow sign-in with an unregistered email address." />
<node TEXT="7. Verify that the 'Remember Me' checkbox does not retain session if cookies are disabled." />
<node TEXT="8. Verify that the password field does not accept spaces as valid input." />
<node TEXT="9. Verify that the sign-in form rejects SQL injection attempts in the email or password fields." />
<node TEXT="10. Verify that the 'Did you forget your username or password?' link shows an error for non-existent accounts." />
</node>
<node TEXT="Non-Functional" FOLDED="true">
<node TEXT="1. Verify that the sign-in page loads within 2 seconds on a standard broadband connection." />
<node TEXT="2. Verify that the sign-in form is responsive and displays correctly on mobile devices." />
<node TEXT="3. Verify that the sign-in page is accessible to screen readers and meets WCAG 2.1 AA standards." />
<node TEXT="4. Verify that the sign-in process is protected with HTTPS encryption." />
<node TEXT="5. Verify that the sign-in form fields are protected against cross-site scripting (XSS) attacks." />
<node TEXT="6. Verify that the sign-in page maintains consistent branding and layout across browsers." />
<node TEXT="7. Verify that the 'Remember Me' functionality does not store sensitive data in plain text." />
<node TEXT="8. Verify that the sign-in page is available 24/7 without downtime." />
<node TEXT="9. Verify that the sign-in form supports high-contrast mode for accessibility." />
<node TEXT="10. Verify that the sign-in page displays correctly in Chrome, Firefox, Safari, and Edge browsers." />
</node>
</node>
<node TEXT="Create Provider Account Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Positive Functional" FOLDED="true">
<node TEXT="1. Verify that a new provider can successfully create an account using a valid distributor code." />
<node TEXT="2. Verify that the 'Request Distributor Code' link navigates to the appropriate request page." />
<node TEXT="3. Verify that all required fields in the account creation form accept valid input." />
<node TEXT="4. Verify that a confirmation message is displayed after successful account creation." />
<node TEXT="5. Verify that the 'Create Account' button is enabled only when all required fields are filled." />
<node TEXT="6. Verify that the distributor code field accepts valid alphanumeric codes." />
<node TEXT="7. Verify that the user receives a verification email after account creation, if applicable." />
<node TEXT="8. Verify that the 'Not a Current Customer?' section displays information about access restrictions." />
<node TEXT="9. Verify that the account creation form supports keyboard navigation." />
<node TEXT="10. Verify that the user can sign in immediately after creating an account." />
</node>
<node TEXT="Negative Functional" FOLDED="true">
<node TEXT="1. Verify that an error message is displayed when an invalid distributor code is entered." />
<node TEXT="2. Verify that the account creation form does not submit with missing required fields." />
<node TEXT="3. Verify that the system prevents duplicate account creation with the same email address." />
<node TEXT="4. Verify that the distributor code field does not accept special characters." />
<node TEXT="5. Verify that the 'Create Account' button remains disabled if only some fields are filled." />
<node TEXT="6. Verify that the form displays an error for an expired or revoked distributor code." />
<node TEXT="7. Verify that the account creation form rejects SQL injection attempts in any field." />
<node TEXT="8. Verify that the system does not allow account creation for non-qualified users." />
<node TEXT="9. Verify that the 'Request Distributor Code' link shows an error for invalid requests." />
<node TEXT="10. Verify that the form displays an error when the email address format is invalid." />
</node>
<node TEXT="Non-Functional" FOLDED="true">
<node TEXT="1. Verify that the account creation page loads within 2 seconds on a standard broadband connection." />
<node TEXT="2. Verify that the account creation form is responsive and displays correctly on mobile devices." />
<node TEXT="3. Verify that the account creation page is accessible to screen readers and meets WCAG 2.1 AA standards." />
<node TEXT="4. Verify that all form submissions are protected with HTTPS encryption." />
<node TEXT="5. Verify that the account creation form fields are protected against cross-site scripting (XSS) attacks." />
<node TEXT="6. Verify that the account creation page maintains consistent branding and layout across browsers." />
<node TEXT="7. Verify that sensitive information is not stored in plain text in the browser." />
<node TEXT="8. Verify that the account creation page is available 24/7 without downtime." />
<node TEXT="9. Verify that the form supports high-contrast mode for accessibility." />
<node TEXT="10. Verify that the account creation page displays correctly in Chrome, Firefox, Safari, and Edge browsers." />
</node>
</node>
<node TEXT="Patient Connect Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Positive Functional" FOLDED="true">
<node TEXT="1. Verify that a patient can request a Patient Connect account by submitting the application form." />
<node TEXT="2. Verify that the 'Create Patient Connect' link navigates to the account creation page." />
<node TEXT="3. Verify that the 'Already Connected?' link navigates to the patient sign-in page." />
<node TEXT="4. Verify that the application form accepts valid input for all required fields." />
<node TEXT="5. Verify that a confirmation message is displayed after submitting a Patient Connect application." />
<node TEXT="6. Verify that the provider receives a notification to verify and activate the patient account." />
<node TEXT="7. Verify that the 'Click Here To Connect With The Nutri-West Distributor' link navigates to the distributor page." />
<node TEXT="8. Verify that the Patient Connect section displays all relevant instructions and information." />
<node TEXT="9. Verify that the patient can sign in after account activation by the provider." />
<node TEXT="10. Verify that the Patient Connect form supports keyboard navigation and accessibility." />
</node>
<node TEXT="Negative Functional" FOLDED="true">
<node TEXT="1. Verify that an error message is displayed when required fields are left blank in the application form." />
<node TEXT="2. Verify that the system does not allow duplicate Patient Connect account requests with the same email." />
<node TEXT="3. Verify that the application form rejects invalid email address formats." />
<node TEXT="4. Verify that the 'Create Patient Connect' form does not submit with invalid or incomplete data." />
<node TEXT="5. Verify that the system displays an error if the provider does not approve the patient application." />
<node TEXT="6. Verify that the 'Already Connected?' link shows an error for invalid login credentials." />
<node TEXT="7. Verify that the application form rejects SQL injection attempts in any field." />
<node TEXT="8. Verify that the 'Click Here To Connect With The Nutri-West Distributor' link shows an error for invalid distributor selection." />
<node TEXT="9. Verify that the system does not allow account creation for non-patient users." />
<node TEXT="10. Verify that the form displays an error when the patient tries to connect without a valid provider code." />
</node>
<node TEXT="Non-Functional" FOLDED="true">
<node TEXT="1. Verify that the Patient Connect page loads within 2 seconds on a standard broadband connection." />
<node TEXT="2. Verify that the Patient Connect form is responsive and displays correctly on mobile devices." />
<node TEXT="3. Verify that the Patient Connect page is accessible to screen readers and meets WCAG 2.1 AA standards." />
<node TEXT="4. Verify that all form submissions are protected with HTTPS encryption." />
<node TEXT="5. Verify that the Patient Connect form fields are protected against cross-site scripting (XSS) attacks." />
<node TEXT="6. Verify that the Patient Connect page maintains consistent branding and layout across browsers." />
<node TEXT="7. Verify that sensitive information is not stored in plain text in the browser." />
<node TEXT="8. Verify that the Patient Connect page is available 24/7 without downtime." />
<node TEXT="9. Verify that the form supports high-contrast mode for accessibility." />
<node TEXT="10. Verify that the Patient Connect page displays correctly in Chrome, Firefox, Safari, and Edge browsers." />
</node>
</node>
<node TEXT="Contact Us Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Positive Functional" FOLDED="true">
<node TEXT="1. Verify that a user can successfully submit a message using the Contact Us form with valid input." />
<node TEXT="2. Verify that all required fields (email, first name, last name, subject, message) accept valid input." />
<node TEXT="3. Verify that a confirmation message is displayed after successful form submission." />
<node TEXT="4. Verify that the 'Submit' button is enabled only when all required fields are filled." />
<node TEXT="5. Verify that the contact information (address, phone, email) is displayed correctly." />
<node TEXT="6. Verify that the 'info@nutri-west.net' email link opens the default mail client." />
<node TEXT="7. Verify that the phone number links initiate a call on mobile devices." />
<node TEXT="8. Verify that the Contact Us page loads correctly and displays all required sections." />
<node TEXT="9. Verify that the form supports keyboard navigation and accessibility." />
<node TEXT="10. Verify that the user receives a response to their inquiry, if applicable." />
</node>
<node TEXT="Negative Functional" FOLDED="true">
<node TEXT="1. Verify that an error message is displayed when required fields are left blank." />
<node TEXT="2. Verify that the form does not submit with an invalid email address format." />
<node TEXT="3. Verify that the form displays an error when the message field is empty." />
<node TEXT="4. Verify that the system rejects form submissions with invalid characters in any field." />
<node TEXT="5. Verify that the form does not submit if the email address is already used for spam." />
<node TEXT="6. Verify that the form displays an error for excessively long input in any field." />
<node TEXT="7. Verify that the form rejects SQL injection attempts in any field." />
<node TEXT="8. Verify that the phone number links do not work on unsupported devices." />
<node TEXT="9. Verify that the form displays an error if the email server is unavailable." />
<node TEXT="10. Verify that the form does not submit if JavaScript is disabled in the browser." />
</node>
<node TEXT="Non-Functional" FOLDED="true">
<node TEXT="1. Verify that the Contact Us page loads within 2 seconds on a standard broadband connection." />
<node TEXT="2. Verify that the Contact Us form is responsive and displays correctly on mobile devices." />
<node TEXT="3. Verify that the Contact Us page is accessible to screen readers and meets WCAG 2.1 AA standards." />
<node TEXT="4. Verify that all form submissions are protected with HTTPS encryption." />
<node TEXT="5. Verify that the Contact Us form fields are protected against cross-site scripting (XSS) attacks." />
<node TEXT="6. Verify that the Contact Us page maintains consistent branding and layout across browsers." />
<node TEXT="7. Verify that sensitive information is not stored in plain text in the browser." />
<node TEXT="8. Verify that the Contact Us page is available 24/7 without downtime." />
<node TEXT="9. Verify that the form supports high-contrast mode for accessibility." />
<node TEXT="10. Verify that the Contact Us page displays correctly in Chrome, Firefox, Safari, and Edge browsers." />
</node>
</node>
<node TEXT="Select Language Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Positive Functional" FOLDED="true">
<node TEXT="1. Verify that the language selection dropdown displays all available language options." />
<node TEXT="2. Verify that selecting a different language updates the website content accordingly." />
<node TEXT="3. Verify that the selected language preference is retained during the session." />
<node TEXT="4. Verify that the language selection is accessible via keyboard navigation." />
<node TEXT="5. Verify that the default language is set correctly on initial page load." />
<node TEXT="6. Verify that the language selection does not affect the functionality of other website features." />
<node TEXT="7. Verify that the language selection is visible and accessible on all pages." />
<node TEXT="8. Verify that the language selection updates all static and dynamic content." />
<node TEXT="9. Verify that the language selection works correctly on both desktop and mobile devices." />
<node TEXT="10. Verify that the language selection persists after page refresh." />
</node>
<node TEXT="Negative Functional" FOLDED="true">
<node TEXT="1. Verify that an error message is displayed if an unsupported language is selected." />
<node TEXT="2. Verify that the website does not break if the language selection dropdown is tampered with." />
<node TEXT="3. Verify that the language selection does not revert to default unexpectedly during navigation." />
<node TEXT="4. Verify that the language selection does not cause layout issues with right-to-left languages." />
<node TEXT="5. Verify that the language selection does not allow selection of empty or null values." />
<node TEXT="6. Verify that the website displays an error if the language resource file is missing." />
<node TEXT="7. Verify that the language selection does not trigger a page reload loop." />
<node TEXT="8. Verify that the language selection does not affect form submissions or data entry." />
<node TEXT="9. Verify that the language selection does not cause broken links or missing images." />
<node TEXT="10. Verify that the language selection does not persist across sessions if not intended." />
</node>
<node TEXT="Non-Functional" FOLDED="true">
<node TEXT="1. Verify that the language selection dropdown is responsive and displays correctly on mobile devices." />
<node TEXT="2. Verify that the language selection feature is accessible to screen readers." />
<node TEXT="3. Verify that the language selection does not impact website performance or load time." />
<node TEXT="4. Verify that the language selection feature is protected against cross-site scripting (XSS) attacks." />
<node TEXT="5. Verify that the language selection maintains consistent branding and layout across browsers." />
<node TEXT="6. Verify that the language selection is available 24/7 without downtime." />
<node TEXT="7. Verify that the language selection supports high-contrast mode for accessibility." />
<node TEXT="8. Verify that the language selection works correctly in Chrome, Firefox, Safari, and Edge browsers." />
<node TEXT="9. Verify that the language selection does not store sensitive data in plain text." />
<node TEXT="10. Verify that the language selection feature loads within 1 second on a standard broadband connection." />
</node>
</node>
</node>
</map>