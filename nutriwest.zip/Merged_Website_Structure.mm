<?xml version='1.0' encoding='utf-8'?>
<node TEXT="home">
  <node TEXT="Header">
    <node TEXT="Top Bar">
      <node TEXT="Sign In As Provider" LINK="https://nutriwest.com/provider-account/signin">
        <node TEXT="Sign In Healthcare Provider" />
        <node TEXT="Sign In Form">
          <node TEXT="Email Address Field" />
          <node TEXT="Password Field" />
          <node TEXT="Remember Me Checkbox" />
          <node TEXT="Sign In" LINK="https://nutriwest.com/provider-account/signin" />
          <node TEXT="Did you forget your username or password?" LINK="https://nutriwest.com/provider-account/forgot-password" />
        </node>
        <node TEXT="Sign Up For Professional Account">
          <node TEXT="Licensed and Certified Providers can access free webinar, fact sheets, training materials and more." />
          <node TEXT="Sign Up" LINK="https://nutriwest.com/provider-account" />
        </node>
        <node TEXT="Made with pride in Wyoming">
          <node TEXT="Business is still done on a handshake." />
        </node>
        <node TEXT="Provider Dedication">
          <node TEXT="Our dedication to you, the health care provider, is absolute. You deserve our personal best in service and support." />
        </node>
      </node>
      <node TEXT="Create Provider Account" LINK="https://nutriwest.com/provider-account">
        <node TEXT="Sign Up for an Account">
          <node TEXT="Health Care Providers">
            <node TEXT="Distributor Code Form">
              <node TEXT="Distributor Code Field" />
              <node TEXT="Create Account" />
            </node>
            <node TEXT="Not a Current Customer?">
              <node TEXT="Access to the Nutri-West website is only available to qualified health care providers." />
              <node TEXT="Request Distributor Code" LINK="https://nutriwest.com/provider-account/request-code" />
            </node>
          </node>
        </node>
        <node TEXT="Made with pride in Wyoming">
          <node TEXT="Business is still done on a handshake." />
          <node TEXT="Our dedication to you, the health care provider, is absolute. You deserve our personal best in service and support." />
        </node>
      </node>
      <node TEXT="Patient Connect" LINK="https://nutriwest.com/patient-connect">
        <node TEXT="Main Content">
          <node TEXT="Patient Connect Section">
            <node TEXT="Request a Patient Connect Account by submitting an application; provider will verify and activate upon approval." />
            <node TEXT="Create Patient Connect" LINK="https://nutriwest.com/patient-connect/code" />
            <node TEXT="Already Connected?" LINK="https://nutriwest.com/patient-connect/signin" />
          </node>
          <node TEXT="No Nutri-West Healthcare Provider?">
            <node TEXT="Distributors can refer you to healthcare providers who carry Nutri-West products." />
            <node TEXT="Click Here To Connect With The Nutri-West Distributor For Your State or Country." LINK="https://nutriwest.com/distributors" />
          </node>
          <node TEXT="Made with pride in Wyoming">
            <node TEXT="Business is still done on a handshake." />
          </node>
          <node TEXT="Dedication Statement">
            <node TEXT="Our dedication to you, the health care provider, is absolute. You deserve our personal best in service and support." />
          </node>
        </node>
      </node>
      <node TEXT="Contact Us" LINK="https://nutriwest.com/contact-us">
        <node TEXT="Contact Information">
          <node TEXT="Nutri-West Corporate Office, 2132 E. Richards St., Douglas, WY 82633" />
          <node TEXT="800-443-3333" LINK="tel:800-443-3333" />
          <node TEXT="(307)-358-5066" LINK="tel:307-358-5066" />
          <node TEXT="info@nutri-west.net" LINK="mailto:info@nutri-west.net" />
        </node>
        <node TEXT="Send Us A Message">
          <node TEXT="Email Address Field" />
          <node TEXT="First Name Field" />
          <node TEXT="Last Name Field" />
          <node TEXT="Subject Field" />
          <node TEXT="Write Message Field" />
          <node TEXT="Submit" />
        </node>
        <node TEXT="Made with pride in Wyoming">
          <node TEXT="Business is still done on a handshake in Wyoming." />
        </node>
        <node TEXT="Dedication Statement">
          <node TEXT="Our dedication to health care providers is absolute; you deserve our personal best in service and support." />
        </node>
      </node>
      <node TEXT="Select Language">
        <node TEXT="Hero Section">
          <node TEXT="A company dedicated to healthy patients, focusing on patient well-being and provider education." />
          <node TEXT="Read More" LINK="https://nutriwest.com/about-nutriwest" />
        </node>
        <node TEXT="Upcoming Seminars">
          <node TEXT="Macomb County Chiropractic Association Seminar">
            <node TEXT="Nov 8-9, 2025, Warren (Detroit), MI. Speaker: Dan Murphy, DC." />
            <node TEXT="View More" LINK="https://nutriwest.com/seminars/macomb-county-chiropractic-association-seminar" />
          </node>
          <node TEXT="WEBINAR - Cornerstone Nutrient Support">
            <node TEXT="Dec 13, 2025, Webinar. Speaker: Jared Allomong, DC." />
            <node TEXT="View More" LINK="https://nutriwest.com/seminars/webinar-cornerstone-nutrient-support-for-thriving-functional-medicine-and-chiropractic-practice" />
          </node>
        </node>
        <node TEXT="Quick Access Tiles">
          <node TEXT="Distributors">
            <node TEXT="View Our Distributors" LINK="https://nutriwest.com/distributors" />
          </node>
          <node TEXT="Seminars">
            <node TEXT="View Upcoming Seminars" LINK="https://nutriwest.com/seminars" />
            <node TEXT="Introduction">
              <node TEXT="Nutri-West sponsors professional seminars and webinars on nutritional support for healthcare practices." />
            </node>
            <node TEXT="October 2025">
              <node TEXT="Georgia Chiropractic Association Annual Fall Conference">
                <node TEXT="Speaker: Brandon Lundell, DC" />
                <node TEXT="Distributor: Nutri-West Coastal Plains" />
                <node TEXT="Location: Atlanta, GA" />
                <node TEXT="Telephone: 770-723-1100" />
                <node TEXT="View More" LINK="https://nutriwest.com/seminars/georgia-chiropractic-association-annual-fall-conference" />
              </node>
              <node TEXT="Colorado Chiropractic Association 91st Annual Fall Convention">
                <node TEXT="Speaker: Dan Murphy, DC and Various Speakers" />
                <node TEXT="Distributor: NUTRI-WEST CORPORATE OFFICE" />
                <node TEXT="Location: Aurora, CO" />
                <node TEXT="Telephone: 303-755-9011" />
                <node TEXT="View More" LINK="https://nutriwest.com/seminars/colorado-chiropractic-association-91st-annual-fall-convention" />
              </node>
            </node>
            <node TEXT="November 2025">
              <node TEXT="Macomb County Chiropractic Association Seminar">
                <node TEXT="Speaker: Dan Murphy, DC" />
                <node TEXT="Distributor: Nutri-West Upper Midwest" />
                <node TEXT="Location: Warren (Detroit), MI" />
                <node TEXT="Telephone: 586-795-3366" />
                <node TEXT="View More" LINK="https://nutriwest.com/seminars/macomb-county-chiropractic-association-seminar" />
              </node>
            </node>
            <node TEXT="Wyoming Pride Section">
              <node TEXT="Nutri-West is proud of its Wyoming roots and commitment to service and support for healthcare providers." />
            </node>
          </node>
          <node TEXT="Employment">
            <node TEXT="Check Current Openings" LINK="https://nutriwest.com/employment" />
          </node>
          <node TEXT="About Us">
            <node TEXT="Know More About Us" LINK="https://nutriwest.com/about-nutriwest" />
          </node>
        </node>
        <node TEXT="Nutri-West Products">
          <node TEXT="Industry-leading standards for quality, purity, and potency in nutritional supplements." />
          <node TEXT="#12 UR-KID (Herbal)">
            <node TEXT="100 tablets per bottle" LINK="https://nutriwest.com/products/12-ur-kid-herbal" />
          </node>
          <node TEXT="#14 LB-CLN (Herbal)">
            <node TEXT="100 tablets per bottle" LINK="https://nutriwest.com/products/14-lb-cln-herbal" />
          </node>
          <node TEXT="5-MTH Folate***">
            <node TEXT="90 tablets per bottle" LINK="https://nutriwest.com/products/5-mth-folate" />
          </node>
          <node TEXT="Adenosyl B-12 Lozenge">
            <node TEXT="90 lozenge tablets per bottle" LINK="https://nutriwest.com/products/adenosyl-b-12-lozenge" />
          </node>
          <node TEXT="BROWSE ONLINE CATALOG" LINK="https://nutriwest.com/products" />
          <node TEXT="HOW TO ORDER" />
        </node>
        <node TEXT="Wyoming Pride Section">
          <node TEXT="Made with pride in Wyoming, where business is still done on a handshake." />
          <node TEXT="Dedication to healthcare providers with personal best in service and support." />
        </node>
      </node>
    </node>
    <node TEXT="Navigation Links">
      <node TEXT="Home" LINK="https://nutriwest.com/" />
      <node TEXT="About Nutri-West" LINK="https://nutriwest.com/about-nutriwest">
        <node TEXT="About Nutri-West">
          <node TEXT="Overview of Nutri-West's mission, history, and dedication to healthy patients." />
        </node>
        <node TEXT="A Company Dedicated to Healthy Patients">
          <node TEXT="Nutri-West is a leading nutritional supplement company focused on quality and health care professionals." />
        </node>
        <node TEXT="Our History">
          <node TEXT="Founded in 1982, Nutri-West has grown into a global company with a commitment to quality and research." />
        </node>
        <node TEXT="Nutri-West Contact Details">
          <node TEXT="Location: P.O. Box 950, 210 E. Richards St. Douglas, WY 82633" />
          <node TEXT="Email Us">
            <node TEXT="info@nutriwest.com" LINK="mailto:info@nutriwest.com" />
            <node TEXT="info@nutri-west.net" LINK="mailto:info@nutri-west.net" />
          </node>
          <node TEXT="Toll Free">
            <node TEXT="(800) 443-3333" LINK="tel:800-443-3333" />
          </node>
          <node TEXT="Phone">
            <node TEXT="307-358-5066" LINK="tel:307-358-5066" />
          </node>
          <node TEXT="Fax">
            <node TEXT="(307) 358-5208 (office) / (307) 358-5252 (orders)" />
          </node>
        </node>
        <node TEXT="Made with pride in Wyoming">
          <node TEXT="Nutri-West values business integrity and personal service." />
        </node>
        <node TEXT="Dedication to Health Care Providers">
          <node TEXT="Nutri-West is committed to providing the best service and support to health care providers." />
        </node>
      </node>
      <node TEXT="Products" LINK="https://nutriwest.com/products">
        <node TEXT="Nutri-West Products" LINK="https://nutriwest.com/products" />
        <node TEXT="Homeopathic Products" LINK="https://nutriwest.com/products?category=homeopathic-products" />
        <node TEXT="Herbal Tincture Products" LINK="https://nutriwest.com/products?category=tincture-products" />
        <node TEXT="Browse Online Catalog">
          <node TEXT="Product Search Form">
            <node TEXT="Product Category Dropdown" />
            <node TEXT="Index of Common Applications Group Field" />
            <node TEXT="Product Name Field" />
            <node TEXT="Ingredient Field" />
            <node TEXT="Apply" />
          </node>
        </node>
        <node TEXT="Product Listings">
          <node TEXT="#1 - AD (Tincture)" LINK="https://nutriwest.com/products/1-ad-tincture">
            <node TEXT="Herbal Tincture Products" />
          </node>
          <node TEXT="#12 UR-KID (Herbal)" LINK="https://nutriwest.com/products/12-ur-kid-herbal">
            <node TEXT="Nutri-West Products" />
          </node>
          <node TEXT="#14 LB-CLN (Herbal)" LINK="https://nutriwest.com/products/14-lb-cln-herbal">
            <node TEXT="Nutri-West Products" />
          </node>
          <node TEXT="#2 - CF (Tincture)" LINK="https://nutriwest.com/products/2-cf-tincture">
            <node TEXT="Herbal Tincture Products" />
          </node>
        </node>
        <node TEXT="Pride in Wyoming">
          <node TEXT="Business is still done on a handshake and products are made with pride in Wyoming." />
          <node TEXT="Our dedication to health care providers is absolute, with a focus on personal best in service and support." />
        </node>
      </node>
      <node TEXT="Find A Nutri-West Distributor" LINK="https://nutriwest.com/distributors">
        <node TEXT="Nutri-West Distributors">
          <node TEXT="Find Nutri-West distributors by selecting your state or region." />
          <node TEXT="Search by State">
            <node TEXT="State Dropdown" />
            <node TEXT="Apply Button" />
          </node>
          <node TEXT="Distributor Tabs">
            <node TEXT="U.S. Distributors" />
            <node TEXT="Foreign Distributors" />
          </node>
          <node TEXT="U.S. Distributor Map">
            <node TEXT="Interactive map showing distributor locations by state." />
          </node>
          <node TEXT="Distributor Contact Information">
            <node TEXT="Nutri-West Corporate Office">
              <node TEXT="Contact details and states served: AL, AR, CO, LA, MS, OH, WV." />
            </node>
            <node TEXT="Nutri-West of Florida">
              <node TEXT="Contact details and state served: Florida." />
            </node>
            <node TEXT="Nutri-West New York">
              <node TEXT="Contact details and states served: CT, ME, MA, NH, NY, RI, VT." />
            </node>
            <node TEXT="Nutri-West Southern California">
              <node TEXT="Contact details and state served: California." />
            </node>
            <node TEXT="Nutri-West Kansas">
              <node TEXT="Contact details and states served: Kansas, Missouri." />
            </node>
            <node TEXT="Nutri-West Northern California Hawaii">
              <node TEXT="Contact details and state served: California." />
            </node>
            <node TEXT="Nutri-West Mid-Atlantic">
              <node TEXT="Contact details and states served: DE, MD, NJ, PA, VA." />
            </node>
          </node>
        </node>
        <node TEXT="Made with pride in Wyoming">
          <node TEXT="Business is still done on a handshake and dedication to service and support." />
        </node>
      </node>
      <node TEXT="Seminars" LINK="https://nutriwest.com/seminars" />
    </node>
  </node>
  <node TEXT="Main Content">
    <node TEXT="Hero Section">
      <node TEXT="A Company Dedicated to Healthy Patients" />
      <node TEXT="Mission - Our fundamental focus is patient well-being. We hold to the principle that the healthcare provider is the surest way to optimal health." />
      <node TEXT="Purpose - To provide the ultimate in nutritional products combined with superior education, to foster success for our providers and health for their patients." />
      <node TEXT="Read More" LINK="https://nutriwest.com/about-nutriwest" />
    </node>
    <node TEXT="Upcoming Seminars">
      <node TEXT="Macomb County Chiropractic Association Seminar">
        <node TEXT="Speaker: Dan Murphy, DC" />
        <node TEXT="Distributor: Nutri-West Upper Midwest" />
        <node TEXT="Location: Warren (Detroit), MI" />
        <node TEXT="Telephone: 586-795-3866" />
        <node TEXT="View More" LINK="https://nutriwest.com/seminars/macomb-county-chiropractic-association-seminar" />
      </node>
      <node TEXT="WEBINAR - Cornerstone Nutrient Support for Thriving Functional Medicine and Chiropractic Practice">
        <node TEXT="Speaker: Jared Almoning, DC" />
        <node TEXT="Distributor: Nutri-West 4 Life" />
        <node TEXT="Location: WEBINAR" />
        <node TEXT="Telephone: 800-255-3292" />
        <node TEXT="View More" LINK="https://nutriwest.com/seminars/webinar-cornerstone-nutrient-support-for-thriving-functional-medicine-and-chiropractic-practice" />
      </node>
    </node>
    <node TEXT="Quick Links Section">
      <node TEXT="Distributors - View Our Distributors" LINK="https://nutriwest.com/distributors" />
      <node TEXT="Seminars - View Upcoming Seminars" LINK="https://nutriwest.com/seminars" />
      <node TEXT="Employment - Check Current Openings" LINK="https://nutriwest.com/employment" />
      <node TEXT="About Us - Know More About Us" LINK="https://nutriwest.com/about-nutriwest" />
    </node>
    <node TEXT="Nutri-West Products">
      <node TEXT="Nutri-West products are made to the industry's most exacting standards of quality, purity, and potency. Our products are the most hypo-allergenic on the market." />
      <node TEXT="#12 UR-KID (Herbal) - 100 tablets per bottle" LINK="https://nutriwest.com/products/12-ur-kid-herbal" />
      <node TEXT="#14 LB-CLN (Herbal) - 100 tablets per bottle" LINK="https://nutriwest.com/products/14-lb-cln-herbal" />
      <node TEXT="5-MTH Folate*** - 90 tablets per bottle" LINK="https://nutriwest.com/products/5-mth-folate" />
      <node TEXT="Adenosyl B-12 Lozenge - 90 lozenge tablets per bottle" LINK="https://nutriwest.com/products/adenosyl-b-12-lozenge" />
      <node TEXT="Browse Online Catalog" LINK="https://nutriwest.com/products" />
      <node TEXT="How To Order" LINK="javascript:void(0);" />
    </node>
    <node TEXT="Made with pride in Wyoming">
      <node TEXT="Where business is still done on a handshake" />
      <node TEXT="Our dedication to you, the health care provider, is absolute. You deserve our personal best in service and support" />
    </node>
  </node>
  <node TEXT="Footer">
    <node TEXT="Why Buy Nutri-West" LINK="https://nutriwest.com/page/why-buy-nutri-west" />
    <node TEXT="Nutritional Supplements and Your Health" LINK="https://nutriwest.com/page/nutritional-supplements-and-your-health" />
    <node TEXT="Nutri-West Manufacturing" LINK="https://nutriwest.com/page/nutri-west-manufacturing" />
    <node TEXT="Nutri-West Distributor Login" LINK="https://nutriwest.com/distributor-login" />
    <node TEXT="About Nutri-West">
      <node TEXT="About Our Products" LINK="https://nutriwest.com/page/about-our-products" />
      <node TEXT="Educational Seminars" LINK="https://nutriwest.com/page/educational-seminars" />
      <node TEXT="About Our Services" LINK="https://nutriwest.com/page/provider-access" />
      <node TEXT="Rapid Shipping" LINK="https://nutriwest.com/page/rapid-shipping" />
      <node TEXT="Direct-To-Patient Shipping" LINK="https://nutriwest.com/page/provider-access" />
      <node TEXT="Register For An Account" LINK="https://nutriwest.com/provider-account/signin" />
    </node>
    <node TEXT="Company Policies">
      <node TEXT="Terms Of Use" LINK="https://nutriwest.com/page/terms-of-use" />
      <node TEXT="Resale Policy" LINK="https://nutriwest.com/page/resale-policy" />
      <node TEXT="Return Policy - Provider" LINK="https://nutriwest.com/page/return-policy-provider" />
      <node TEXT="Return Policy - Patient" LINK="https://nutriwest.com/page/return-policy-patient" />
      <node TEXT="Privacy Policy" LINK="https://nutriwest.com/page/privacy-policy" />
    </node>
    <node TEXT="Contact Us" LINK="https://nutriwest.com/contact-us" />
  </node>
</node>