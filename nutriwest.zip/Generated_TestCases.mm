<map version="1.0.1">
<node TEXT="Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Sign In As Provider Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Positive Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that a registered provider can successfully sign in using valid email and password." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the 'Remember Me' checkbox retains the user's session after closing and reopening the browser." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the 'Did you forget your username or password?' link navigates to the password recovery page." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that the sign-in form fields accept valid email and password input formats." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the user is redirected to the provider dashboard upon successful sign-in." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the 'Sign Up For Professional Account' link navigates to the account creation page." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the sign-in page loads correctly and displays all required fields and links." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the 'Sign In' button is enabled only when both email and password fields are filled." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the user can log out successfully after signing in as a provider." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the sign-in form supports keyboard navigation and accessibility standards." FOLDED="true" POSITION="left" />
</node>
<node TEXT="Negative Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that an error message is displayed when an invalid email format is entered." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that an error message is shown when an incorrect password is provided." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the sign-in form does not submit when required fields are left blank." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that the account is locked after multiple failed sign-in attempts, if applicable." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the 'Sign In' button remains disabled when only one field is filled." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the system does not allow sign-in with an unregistered email address." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the 'Remember Me' checkbox does not retain session if cookies are disabled." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the password field does not accept spaces as valid input." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the sign-in form rejects SQL injection attempts in the email or password fields." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the 'Did you forget your username or password?' link shows an error for non-existent accounts." FOLDED="true" POSITION="left" />
</node>
<node TEXT="Non-Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that the sign-in page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the sign-in form is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the sign-in page is accessible to screen readers and meets WCAG 2.1 AA standards." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that the sign-in process is protected with HTTPS encryption." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the sign-in form fields are protected against cross-site scripting (XSS) attacks." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the sign-in page maintains consistent branding and layout across browsers." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the 'Remember Me' functionality does not store sensitive data in plain text." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the sign-in page is available 24/7 without downtime." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the sign-in form supports high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the sign-in page displays correctly in Chrome, Firefox, Safari, and Edge browsers." FOLDED="true" POSITION="left" />
</node>
</node>
<node TEXT="Create Provider Account Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Positive Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that a new provider can successfully create an account using a valid distributor code." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the 'Request Distributor Code' link navigates to the appropriate request page." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that all required fields in the account creation form accept valid input." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that a confirmation message is displayed after successful account creation." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the 'Create Account' button is enabled only when all required fields are filled." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the distributor code field accepts valid alphanumeric codes." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the user receives a verification email after account creation, if applicable." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the 'Not a Current Customer?' section displays information about access restrictions." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the account creation form supports keyboard navigation." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the user can sign in immediately after creating an account." FOLDED="true" POSITION="left" />
</node>
<node TEXT="Negative Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that an error message is displayed when an invalid distributor code is entered." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the account creation form does not submit with missing required fields." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the system prevents duplicate account creation with the same email address." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that the distributor code field does not accept special characters." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the 'Create Account' button remains disabled if only some fields are filled." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the form displays an error for an expired or revoked distributor code." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the account creation form rejects SQL injection attempts in any field." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the system does not allow account creation for non-qualified users." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the 'Request Distributor Code' link shows an error for invalid requests." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the form displays an error when the email address format is invalid." FOLDED="true" POSITION="left" />
</node>
<node TEXT="Non-Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that the account creation page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the account creation form is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the account creation page is accessible to screen readers and meets WCAG 2.1 AA standards." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that all form submissions are protected with HTTPS encryption." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the account creation form fields are protected against cross-site scripting (XSS) attacks." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the account creation page maintains consistent branding and layout across browsers." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that sensitive information is not stored in plain text in the browser." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the account creation page is available 24/7 without downtime." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the form supports high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the account creation page displays correctly in Chrome, Firefox, Safari, and Edge browsers." FOLDED="true" POSITION="left" />
</node>
</node>
<node TEXT="Patient Connect Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Positive Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that a patient can request a Patient Connect account by submitting the application form." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the 'Create Patient Connect' link navigates to the account creation page." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the 'Already Connected?' link navigates to the patient sign-in page." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that the application form accepts valid input for all required fields." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that a confirmation message is displayed after submitting a Patient Connect application." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the provider receives a notification to verify and activate the patient account." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the 'Click Here To Connect With The Nutri-West Distributor' link navigates to the distributor page." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the Patient Connect section displays all relevant instructions and information." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the patient can sign in after account activation by the provider." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the Patient Connect form supports keyboard navigation and accessibility." FOLDED="true" POSITION="left" />
</node>
<node TEXT="Negative Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that an error message is displayed when required fields are left blank in the application form." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the system does not allow duplicate Patient Connect account requests with the same email." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the application form rejects invalid email address formats." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that the 'Create Patient Connect' form does not submit with invalid or incomplete data." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the system displays an error if the provider does not approve the patient application." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the 'Already Connected?' link shows an error for invalid login credentials." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the application form rejects SQL injection attempts in any field." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the 'Click Here To Connect With The Nutri-West Distributor' link shows an error for invalid distributor selection." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the system does not allow account creation for non-patient users." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the form displays an error when the patient tries to connect without a valid provider code." FOLDED="true" POSITION="left" />
</node>
<node TEXT="Non-Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that the Patient Connect page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the Patient Connect form is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the Patient Connect page is accessible to screen readers and meets WCAG 2.1 AA standards." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that all form submissions are protected with HTTPS encryption." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the Patient Connect form fields are protected against cross-site scripting (XSS) attacks." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the Patient Connect page maintains consistent branding and layout across browsers." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that sensitive information is not stored in plain text in the browser." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the Patient Connect page is available 24/7 without downtime." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the form supports high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the Patient Connect page displays correctly in Chrome, Firefox, Safari, and Edge browsers." FOLDED="true" POSITION="left" />
</node>
</node>
<node TEXT="Contact Us Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Positive Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that a user can successfully submit a message using the Contact Us form with valid input." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that all required fields (email, first name, last name, subject, message) accept valid input." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that a confirmation message is displayed after successful form submission." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that the 'Submit' button is enabled only when all required fields are filled." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the contact information (address, phone, email) is displayed correctly." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the 'info@nutri-west.net' email link opens the default mail client." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the phone number links initiate a call on mobile devices." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the Contact Us page loads correctly and displays all required sections." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the form supports keyboard navigation and accessibility." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the user receives a response to their inquiry, if applicable." FOLDED="true" POSITION="left" />
</node>
<node TEXT="Negative Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that an error message is displayed when required fields are left blank." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the form does not submit with an invalid email address format." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the form displays an error when the message field is empty." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that the system rejects form submissions with invalid characters in any field." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the form does not submit if the email address is already used for spam." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the form displays an error for excessively long input in any field." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the form rejects SQL injection attempts in any field." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the phone number links do not work on unsupported devices." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the form displays an error if the email server is unavailable." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the form does not submit if JavaScript is disabled in the browser." FOLDED="true" POSITION="left" />
</node>
<node TEXT="Non-Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that the Contact Us page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the Contact Us form is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the Contact Us page is accessible to screen readers and meets WCAG 2.1 AA standards." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that all form submissions are protected with HTTPS encryption." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the Contact Us form fields are protected against cross-site scripting (XSS) attacks." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the Contact Us page maintains consistent branding and layout across browsers." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that sensitive information is not stored in plain text in the browser." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the Contact Us page is available 24/7 without downtime." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the form supports high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the Contact Us page displays correctly in Chrome, Firefox, Safari, and Edge browsers." FOLDED="true" POSITION="left" />
</node>
</node>
<node TEXT="Select Language Test Cases" POSITION="left" FOLDED="true">
<node TEXT="Positive Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that the language selection dropdown displays all available language options." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that selecting a different language updates the website content accordingly." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the selected language preference is retained during the session." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that the language selection is accessible via keyboard navigation." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the default language is set correctly on initial page load." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the language selection does not affect the functionality of other website features." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the language selection is visible and accessible on all pages." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the language selection updates all static and dynamic content." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the language selection works correctly on both desktop and mobile devices." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the language selection persists after page refresh." FOLDED="true" POSITION="left" />
</node>
<node TEXT="Negative Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that an error message is displayed if an unsupported language is selected." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the website does not break if the language selection dropdown is tampered with." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the language selection does not revert to default unexpectedly during navigation." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that the language selection does not cause layout issues with right-to-left languages." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the language selection does not allow selection of empty or null values." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the website displays an error if the language resource file is missing." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the language selection does not trigger a page reload loop." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the language selection does not affect form submissions or data entry." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the language selection does not cause broken links or missing images." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the language selection does not persist across sessions if not intended." FOLDED="true" POSITION="left" />
</node>
<node TEXT="Non-Functional" FOLDED="true" POSITION="left">
<node TEXT="1. Verify that the language selection dropdown is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
<node TEXT="2. Verify that the language selection feature is accessible to screen readers." FOLDED="true" POSITION="left" />
<node TEXT="3. Verify that the language selection does not impact website performance or load time." FOLDED="true" POSITION="left" />
<node TEXT="4. Verify that the language selection feature is protected against cross-site scripting (XSS) attacks." FOLDED="true" POSITION="left" />
<node TEXT="5. Verify that the language selection maintains consistent branding and layout across browsers." FOLDED="true" POSITION="left" />
<node TEXT="6. Verify that the language selection is available 24/7 without downtime." FOLDED="true" POSITION="left" />
<node TEXT="7. Verify that the language selection supports high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
<node TEXT="8. Verify that the language selection works correctly in Chrome, Firefox, Safari, and Edge browsers." FOLDED="true" POSITION="left" />
<node TEXT="9. Verify that the language selection does not store sensitive data in plain text." FOLDED="true" POSITION="left" />
<node TEXT="10. Verify that the language selection feature loads within 1 second on a standard broadband connection." FOLDED="true" POSITION="left" />
</node>
</node>
</node>
</map>