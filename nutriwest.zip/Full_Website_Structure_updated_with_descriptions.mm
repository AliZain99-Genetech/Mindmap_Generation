<?xml version='1.0' encoding='UTF-8'?>
<map version="1.0.1">
  <node TEXT="Home Page" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Top Bar" FOLDED="true">
        <node TEXT="Sign In As Provider" LINK="https://nutriwest.com/provider-account/signin" FOLDED="true">
          <node TEXT="Sign In Healthcare Provider" FOLDED="true"/>
          <node TEXT="Sign In Form" FOLDED="true">
            <node TEXT="Email Address Field" FOLDED="true"/>
            <node TEXT="Password Field" FOLDED="true"/>
            <node TEXT="Remember Me Checkbox" FOLDED="true"/>
            <node TEXT="Sign In" LINK="https://nutriwest.com/provider-account/signin" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_provider-account_signin.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Did you forget your username or password?" LINK="https://nutriwest.com/provider-account/forgot-password" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_provider-account_forgot-password.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Sign Up For Professional Account" FOLDED="true">
            <node TEXT="Licensed and Certified Providers can access free webinar, fact sheets, training materials and more." FOLDED="true"/>
            <node TEXT="Sign Up" LINK="https://nutriwest.com/provider-account" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_provider-account.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Made with pride in Wyoming" FOLDED="true">
            <node TEXT="Business is still done on a handshake." FOLDED="true"/>
          </node>
          <node TEXT="Provider Dedication" FOLDED="true">
            <node TEXT="Our dedication to you, the health care provider, is absolute. You deserve our personal best in service and support." FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_provider-account_signin.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Create Provider Account" LINK="https://nutriwest.com/provider-account" FOLDED="true">
          <node TEXT="Sign Up for an Account" FOLDED="true">
            <node TEXT="Health Care Providers" FOLDED="true">
              <node TEXT="Distributor Code Form" FOLDED="true">
                <node TEXT="Distributor Code Field" FOLDED="true"/>
                <node TEXT="Create Account" FOLDED="true"/>
              </node>
              <node TEXT="Not a Current Customer?" FOLDED="true">
                <node TEXT="Access to the Nutri-West website is only available to qualified health care providers." FOLDED="true"/>
                <node TEXT="Request Distributor Code" LINK="https://nutriwest.com/provider-account/request-code" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_provider-account_request-code.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
          </node>
          <node TEXT="Made with pride in Wyoming" FOLDED="true">
            <node TEXT="Business is still done on a handshake." FOLDED="true"/>
            <node TEXT="Our dedication to you, the health care provider, is absolute. You deserve our personal best in service and support." FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_provider-account.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Patient Connect" LINK="https://nutriwest.com/patient-connect" FOLDED="true">
          <node TEXT="Main Content" FOLDED="true">
            <node TEXT="Patient Connect Section" FOLDED="true">
              <node TEXT="Request a Patient Connect Account by submitting an application; provider will verify and activate upon approval." FOLDED="true"/>
              <node TEXT="Create Patient Connect" LINK="https://nutriwest.com/patient-connect/code" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_patient-connect_code.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Already Connected?" LINK="https://nutriwest.com/patient-connect/signin" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_patient-connect_signin.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="No Nutri-West Healthcare Provider?" FOLDED="true">
              <node TEXT="Distributors can refer you to healthcare providers who carry Nutri-West products." FOLDED="true"/>
              <node TEXT="Click Here To Connect With The Nutri-West Distributor For Your State or Country." LINK="https://nutriwest.com/distributors" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_distributors.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Made with pride in Wyoming" FOLDED="true">
              <node TEXT="Business is still done on a handshake." FOLDED="true"/>
            </node>
            <node TEXT="Dedication Statement" FOLDED="true">
              <node TEXT="Our dedication to you, the health care provider, is absolute. You deserve our personal best in service and support." FOLDED="true"/>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_patient-connect.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://nutriwest.com/contact-us" FOLDED="true">
          <node TEXT="Contact Information" FOLDED="true">
            <node TEXT="Nutri-West Corporate Office, 2132 E. Richards St., Douglas, WY 82633" FOLDED="true"/>
            <node TEXT="800-443-3333" LINK="tel:800-443-3333" FOLDED="true"/>
            <node TEXT="(307)-358-5066" LINK="tel:307-358-5066" FOLDED="true"/>
            <node TEXT="info@nutri-west.net" LINK="mailto:info@nutri-west.net" FOLDED="true"/>
          </node>
          <node TEXT="Send Us A Message" FOLDED="true">
            <node TEXT="Email Address Field" FOLDED="true"/>
            <node TEXT="First Name Field" FOLDED="true"/>
            <node TEXT="Last Name Field" FOLDED="true"/>
            <node TEXT="Subject Field" FOLDED="true"/>
            <node TEXT="Write Message Field" FOLDED="true"/>
            <node TEXT="Submit" FOLDED="true"/>
          </node>
          <node TEXT="Made with pride in Wyoming" FOLDED="true">
            <node TEXT="Business is still done on a handshake in Wyoming." FOLDED="true"/>
          </node>
          <node TEXT="Dedication Statement" FOLDED="true">
            <node TEXT="Our dedication to health care providers is absolute; you deserve our personal best in service and support." FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_contact-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Select Language" FOLDED="true">
          <node TEXT="Hero Section" FOLDED="true">
            <node TEXT="A company dedicated to healthy patients, focusing on patient well-being and provider education." FOLDED="true"/>
            <node TEXT="Read More" LINK="https://nutriwest.com/about-nutriwest" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_about-nutriwest.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Upcoming Seminars" FOLDED="true">
            <node TEXT="Macomb County Chiropractic Association Seminar" FOLDED="true">
              <node TEXT="Nov 8-9, 2025, Warren (Detroit), MI. Speaker: Dan Murphy, DC." FOLDED="true"/>
              <node TEXT="View More" LINK="https://nutriwest.com/seminars/macomb-county-chiropractic-association-seminar" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_seminars_macomb-county-chiropractic-association-seminar.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="WEBINAR - Cornerstone Nutrient Support" FOLDED="true">
              <node TEXT="Dec 13, 2025, Webinar. Speaker: Jared Allomong, DC." FOLDED="true"/>
              <node TEXT="View More" LINK="https://nutriwest.com/seminars/webinar-cornerstone-nutrient-support-for-thriving-functional-medicine-and-chiropractic-practice" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_seminars_webinar-cornerstone-nutrient-support-for-thriving-functional-medicine-and-chiropractic-practice.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Quick Access Tiles" FOLDED="true">
            <node TEXT="Distributors" FOLDED="true">
              <node TEXT="View Our Distributors" LINK="https://nutriwest.com/distributors" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_distributors.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Seminars" FOLDED="true">
              <node TEXT="View Upcoming Seminars" LINK="https://nutriwest.com/seminars" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_seminars.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Introduction" FOLDED="true">
                <node TEXT="Nutri-West sponsors professional seminars and webinars on nutritional support for healthcare practices." FOLDED="true"/>
              </node>
              <node TEXT="October 2025" FOLDED="true">
                <node TEXT="Georgia Chiropractic Association Annual Fall Conference" FOLDED="true">
                  <node TEXT="Speaker: Brandon Lundell, DC" FOLDED="true"/>
                  <node TEXT="Distributor: Nutri-West Coastal Plains" FOLDED="true"/>
                  <node TEXT="Location: Atlanta, GA" FOLDED="true"/>
                  <node TEXT="Telephone: 770-723-1100" FOLDED="true"/>
                  <node TEXT="View More" LINK="https://nutriwest.com/seminars/georgia-chiropractic-association-annual-fall-conference" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_seminars_georgia-chiropractic-association-annual-fall-conference.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
                </node>
                <node TEXT="Colorado Chiropractic Association 91st Annual Fall Convention" FOLDED="true">
                  <node TEXT="Speaker: Dan Murphy, DC and Various Speakers" FOLDED="true"/>
                  <node TEXT="Distributor: NUTRI-WEST CORPORATE OFFICE" FOLDED="true"/>
                  <node TEXT="Location: Aurora, CO" FOLDED="true"/>
                  <node TEXT="Telephone: 303-755-9011" FOLDED="true"/>
                  <node TEXT="View More" LINK="https://nutriwest.com/seminars/colorado-chiropractic-association-91st-annual-fall-convention" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_seminars_colorado-chiropractic-association-91st-annual-fall-convention.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
                </node>
              </node>
              <node TEXT="November 2025" FOLDED="true">
                <node TEXT="Macomb County Chiropractic Association Seminar" FOLDED="true">
                  <node TEXT="Speaker: Dan Murphy, DC" FOLDED="true"/>
                  <node TEXT="Distributor: Nutri-West Upper Midwest" FOLDED="true"/>
                  <node TEXT="Location: Warren (Detroit), MI" FOLDED="true"/>
                  <node TEXT="Telephone: 586-795-3366" FOLDED="true"/>
                  <node TEXT="View More" LINK="https://nutriwest.com/seminars/macomb-county-chiropractic-association-seminar" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_seminars_macomb-county-chiropractic-association-seminar.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
                </node>
              </node>
              <node TEXT="Wyoming Pride Section" FOLDED="true">
                <node TEXT="Nutri-West is proud of its Wyoming roots and commitment to service and support for healthcare providers." FOLDED="true"/>
              </node>
            </node>
            <node TEXT="Employment" FOLDED="true">
              <node TEXT="Check Current Openings" LINK="https://nutriwest.com/employment" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_employment.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="About Us" FOLDED="true">
              <node TEXT="Know More About Us" LINK="https://nutriwest.com/about-nutriwest" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_about-nutriwest.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Nutri-West Products" FOLDED="true">
            <node TEXT="Industry-leading standards for quality, purity, and potency in nutritional supplements." FOLDED="true"/>
            <node TEXT="#12 UR-KID (Herbal)" FOLDED="true">
              <node TEXT="100 tablets per bottle" LINK="https://nutriwest.com/products/12-ur-kid-herbal" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_12-ur-kid-herbal.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="#14 LB-CLN (Herbal)" FOLDED="true">
              <node TEXT="100 tablets per bottle" LINK="https://nutriwest.com/products/14-lb-cln-herbal" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_14-lb-cln-herbal.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="5-MTH Folate***" FOLDED="true">
              <node TEXT="90 tablets per bottle" LINK="https://nutriwest.com/products/5-mth-folate" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_5-mth-folate.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Adenosyl B-12 Lozenge" FOLDED="true">
              <node TEXT="90 lozenge tablets per bottle" LINK="https://nutriwest.com/products/adenosyl-b-12-lozenge" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_adenosyl-b-12-lozenge.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="BROWSE ONLINE CATALOG" LINK="https://nutriwest.com/products" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="HOW TO ORDER" FOLDED="true"/>
          </node>
          <node TEXT="Wyoming Pride Section" FOLDED="true">
            <node TEXT="Made with pride in Wyoming, where business is still done on a handshake." FOLDED="true"/>
            <node TEXT="Dedication to healthcare providers with personal best in service and support." FOLDED="true"/>
          </node>
        </node>
      </node>
      <node TEXT="Navigation Links" FOLDED="true">
        <node TEXT="Home" LINK="https://nutriwest.com/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About Nutri-West" LINK="https://nutriwest.com/about-nutriwest" FOLDED="true">
          <node TEXT="About Nutri-West" FOLDED="true">
            <node TEXT="Overview of Nutri-West's mission, history, and dedication to healthy patients." FOLDED="true"/>
          </node>
          <node TEXT="A Company Dedicated to Healthy Patients" FOLDED="true">
            <node TEXT="Nutri-West is a leading nutritional supplement company focused on quality and health care professionals." FOLDED="true"/>
          </node>
          <node TEXT="Our History" FOLDED="true">
            <node TEXT="Founded in 1982, Nutri-West has grown into a global company with a commitment to quality and research." FOLDED="true"/>
          </node>
          <node TEXT="Nutri-West Contact Details" FOLDED="true">
            <node TEXT="Location: P.O. Box 950, 210 E. Richards St. Douglas, WY 82633" FOLDED="true"/>
            <node TEXT="Email Us" FOLDED="true">
              <node TEXT="info@nutriwest.com" LINK="mailto:info@nutriwest.com" FOLDED="true"/>
              <node TEXT="info@nutri-west.net" LINK="mailto:info@nutri-west.net" FOLDED="true"/>
            </node>
            <node TEXT="Toll Free" FOLDED="true">
              <node TEXT="(800) 443-3333" LINK="tel:800-443-3333" FOLDED="true"/>
            </node>
            <node TEXT="Phone" FOLDED="true">
              <node TEXT="307-358-5066" LINK="tel:307-358-5066" FOLDED="true"/>
            </node>
            <node TEXT="Fax" FOLDED="true">
              <node TEXT="(307) 358-5208 (office) / (307) 358-5252 (orders)" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Made with pride in Wyoming" FOLDED="true">
            <node TEXT="Nutri-West values business integrity and personal service." FOLDED="true"/>
          </node>
          <node TEXT="Dedication to Health Care Providers" FOLDED="true">
            <node TEXT="Nutri-West is committed to providing the best service and support to health care providers." FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_about-nutriwest.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Products" LINK="https://nutriwest.com/products" FOLDED="true">
          <node TEXT="Nutri-West Products" LINK="https://nutriwest.com/products" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Homeopathic Products" LINK="https://nutriwest.com/products?category=homeopathic-products" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_category_homeopathic-products.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Herbal Tincture Products" LINK="https://nutriwest.com/products?category=tincture-products" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_category_tincture-products.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Browse Online Catalog" FOLDED="true">
            <node TEXT="Product Search Form" FOLDED="true">
              <node TEXT="Product Category Dropdown" FOLDED="true"/>
              <node TEXT="Index of Common Applications Group Field" FOLDED="true"/>
              <node TEXT="Product Name Field" FOLDED="true"/>
              <node TEXT="Ingredient Field" FOLDED="true"/>
              <node TEXT="Apply" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Product Listings" FOLDED="true">
            <node TEXT="#1 - AD (Tincture)" LINK="https://nutriwest.com/products/1-ad-tincture" FOLDED="true">
              <node TEXT="Herbal Tincture Products" FOLDED="true"/>
            <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_1-ad-tincture.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="#12 UR-KID (Herbal)" LINK="https://nutriwest.com/products/12-ur-kid-herbal" FOLDED="true">
              <node TEXT="Nutri-West Products" FOLDED="true"/>
            <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_12-ur-kid-herbal.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="#14 LB-CLN (Herbal)" LINK="https://nutriwest.com/products/14-lb-cln-herbal" FOLDED="true">
              <node TEXT="Nutri-West Products" FOLDED="true"/>
            <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_14-lb-cln-herbal.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="#2 - CF (Tincture)" LINK="https://nutriwest.com/products/2-cf-tincture" FOLDED="true">
              <node TEXT="Herbal Tincture Products" FOLDED="true"/>
            <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_2-cf-tincture.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Pride in Wyoming" FOLDED="true">
            <node TEXT="Business is still done on a handshake and products are made with pride in Wyoming." FOLDED="true"/>
            <node TEXT="Our dedication to health care providers is absolute, with a focus on personal best in service and support." FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Find A Nutri-West Distributor" LINK="https://nutriwest.com/distributors" FOLDED="true">
          <node TEXT="Nutri-West Distributors" FOLDED="true">
            <node TEXT="Find Nutri-West distributors by selecting your state or region." FOLDED="true"/>
            <node TEXT="Search by State" FOLDED="true">
              <node TEXT="State Dropdown" FOLDED="true"/>
              <node TEXT="Apply Button" FOLDED="true"/>
            </node>
            <node TEXT="Distributor Tabs" FOLDED="true">
              <node TEXT="U.S. Distributors" FOLDED="true"/>
              <node TEXT="Foreign Distributors" FOLDED="true"/>
            </node>
            <node TEXT="U.S. Distributor Map" FOLDED="true">
              <node TEXT="Interactive map showing distributor locations by state." FOLDED="true"/>
            </node>
            <node TEXT="Distributor Contact Information" FOLDED="true">
              <node TEXT="Nutri-West Corporate Office" FOLDED="true">
                <node TEXT="Contact details and states served: AL, AR, CO, LA, MS, OH, WV." FOLDED="true"/>
              </node>
              <node TEXT="Nutri-West of Florida" FOLDED="true">
                <node TEXT="Contact details and state served: Florida." FOLDED="true"/>
              </node>
              <node TEXT="Nutri-West New York" FOLDED="true">
                <node TEXT="Contact details and states served: CT, ME, MA, NH, NY, RI, VT." FOLDED="true"/>
              </node>
              <node TEXT="Nutri-West Southern California" FOLDED="true">
                <node TEXT="Contact details and state served: California." FOLDED="true"/>
              </node>
              <node TEXT="Nutri-West Kansas" FOLDED="true">
                <node TEXT="Contact details and states served: Kansas, Missouri." FOLDED="true"/>
              </node>
              <node TEXT="Nutri-West Northern California Hawaii" FOLDED="true">
                <node TEXT="Contact details and state served: California." FOLDED="true"/>
              </node>
              <node TEXT="Nutri-West Mid-Atlantic" FOLDED="true">
                <node TEXT="Contact details and states served: DE, MD, NJ, PA, VA." FOLDED="true"/>
              </node>
            </node>
          </node>
          <node TEXT="Made with pride in Wyoming" FOLDED="true">
            <node TEXT="Business is still done on a handshake and dedication to service and support." FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_distributors.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Seminars" LINK="https://nutriwest.com/seminars" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_seminars.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Main Content" FOLDED="true">
      <node TEXT="Hero Section" FOLDED="true">
        <node TEXT="A Company Dedicated to Healthy Patients" FOLDED="true"/>
        <node TEXT="Mission - Our fundamental focus is patient well-being. We hold to the principle that the healthcare provider is the surest way to optimal health." FOLDED="true"/>
        <node TEXT="Purpose - To provide the ultimate in nutritional products combined with superior education, to foster success for our providers and health for their patients." FOLDED="true"/>
        <node TEXT="Read More" LINK="https://nutriwest.com/about-nutriwest" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_about-nutriwest.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Upcoming Seminars" FOLDED="true">
        <node TEXT="Macomb County Chiropractic Association Seminar" FOLDED="true">
          <node TEXT="Speaker: Dan Murphy, DC" FOLDED="true"/>
          <node TEXT="Distributor: Nutri-West Upper Midwest" FOLDED="true"/>
          <node TEXT="Location: Warren (Detroit), MI" FOLDED="true"/>
          <node TEXT="Telephone: 586-795-3866" FOLDED="true"/>
          <node TEXT="View More" LINK="https://nutriwest.com/seminars/macomb-county-chiropractic-association-seminar" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_seminars_macomb-county-chiropractic-association-seminar.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="WEBINAR - Cornerstone Nutrient Support for Thriving Functional Medicine and Chiropractic Practice" FOLDED="true">
          <node TEXT="Speaker: Jared Almoning, DC" FOLDED="true"/>
          <node TEXT="Distributor: Nutri-West 4 Life" FOLDED="true"/>
          <node TEXT="Location: WEBINAR" FOLDED="true"/>
          <node TEXT="Telephone: 800-255-3292" FOLDED="true"/>
          <node TEXT="View More" LINK="https://nutriwest.com/seminars/webinar-cornerstone-nutrient-support-for-thriving-functional-medicine-and-chiropractic-practice" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_seminars_webinar-cornerstone-nutrient-support-for-thriving-functional-medicine-and-chiropractic-practice.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
      </node>
      <node TEXT="Quick Links Section" FOLDED="true">
        <node TEXT="Distributors - View Our Distributors" LINK="https://nutriwest.com/distributors" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_distributors.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Seminars - View Upcoming Seminars" LINK="https://nutriwest.com/seminars" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_seminars.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Employment - Check Current Openings" LINK="https://nutriwest.com/employment" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_employment.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About Us - Know More About Us" LINK="https://nutriwest.com/about-nutriwest" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_about-nutriwest.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Nutri-West Products" FOLDED="true">
        <node TEXT="Nutri-West products are made to the industry's most exacting standards of quality, purity, and potency. Our products are the most hypo-allergenic on the market." FOLDED="true"/>
        <node TEXT="#12 UR-KID (Herbal) - 100 tablets per bottle" LINK="https://nutriwest.com/products/12-ur-kid-herbal" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_12-ur-kid-herbal.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="#14 LB-CLN (Herbal) - 100 tablets per bottle" LINK="https://nutriwest.com/products/14-lb-cln-herbal" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_14-lb-cln-herbal.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="5-MTH Folate*** - 90 tablets per bottle" LINK="https://nutriwest.com/products/5-mth-folate" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_5-mth-folate.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Adenosyl B-12 Lozenge - 90 lozenge tablets per bottle" LINK="https://nutriwest.com/products/adenosyl-b-12-lozenge" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products_adenosyl-b-12-lozenge.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Browse Online Catalog" LINK="https://nutriwest.com/products" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_products.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="How To Order" LINK="javascript:void(0);" FOLDED="true"/>
      </node>
      <node TEXT="Made with pride in Wyoming" FOLDED="true">
        <node TEXT="Where business is still done on a handshake" FOLDED="true"/>
        <node TEXT="Our dedication to you, the health care provider, is absolute. You deserve our personal best in service and support" FOLDED="true"/>
      </node>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Why Buy Nutri-West" LINK="https://nutriwest.com/page/why-buy-nutri-west" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_why-buy-nutri-west.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Nutritional Supplements and Your Health" LINK="https://nutriwest.com/page/nutritional-supplements-and-your-health" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_nutritional-supplements-and-your-health.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Nutri-West Manufacturing" LINK="https://nutriwest.com/page/nutri-west-manufacturing" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_nutri-west-manufacturing.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Nutri-West Distributor Login" LINK="https://nutriwest.com/distributor-login" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_distributor-login.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="About Nutri-West" FOLDED="true">
        <node TEXT="About Our Products" LINK="https://nutriwest.com/page/about-our-products" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_about-our-products.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Educational Seminars" LINK="https://nutriwest.com/page/educational-seminars" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_educational-seminars.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About Our Services" LINK="https://nutriwest.com/page/provider-access" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_provider-access.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Rapid Shipping" LINK="https://nutriwest.com/page/rapid-shipping" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_rapid-shipping.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Direct-To-Patient Shipping" LINK="https://nutriwest.com/page/provider-access" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_provider-access.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Register For An Account" LINK="https://nutriwest.com/provider-account/signin" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_provider-account_signin.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Company Policies" FOLDED="true">
        <node TEXT="Terms Of Use" LINK="https://nutriwest.com/page/terms-of-use" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_terms-of-use.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Resale Policy" LINK="https://nutriwest.com/page/resale-policy" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_resale-policy.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Return Policy - Provider" LINK="https://nutriwest.com/page/return-policy-provider" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_return-policy-provider.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Return Policy - Patient" LINK="https://nutriwest.com/page/return-policy-patient" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_return-policy-patient.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Privacy Policy" LINK="https://nutriwest.com/page/privacy-policy" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_page_privacy-policy.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us" LINK="https://nutriwest.com/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_contact-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Nutri-West Distributor Login" LINK="https://nutriwest.com/distributor-login" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_distributor-login.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Sign In As Provider" LINK="https://nutriwest.com/provider-account/signin" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_provider-account_signin.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Sign Up For Professional Account" LINK="https://nutriwest.com/provider-account" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nutriwest.com_provider-account.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
  </node>
</map>
