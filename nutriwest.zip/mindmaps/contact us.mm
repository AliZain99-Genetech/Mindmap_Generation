<node TEXT="contact us">
    <node TEXT="Main Content">
      <node TEXT="Contact Information">
        <node TEXT="Nutri-West Corporate Office, 2132 E. Richards St., Douglas, WY 82633"/>
        <node TEXT="800-443-3333" LINK="tel:800-443-3333"/>
        <node TEXT="(307)-358-5066" LINK="tel:307-358-5066"/>
        <node TEXT="info@nutri-west.net" LINK="mailto:info@nutri-west.net"/>
      </node>
      <node TEXT="Send Us A Message">
        <node TEXT="Email Address Field"/>
        <node TEXT="First Name Field"/>
        <node TEXT="Last Name Field"/>
        <node TEXT="Subject Field"/>
        <node TEXT="Write Message Field"/>
        <node TEXT="Submit"/>
      </node>
      <node TEXT="Made with pride in Wyoming">
        <node TEXT="Business is still done on a handshake in Wyoming."/>
      </node>
      <node TEXT="Dedication Statement">
        <node TEXT="Our dedication to health care providers is absolute; you deserve our personal best in service and support."/>
      </node>
    </node>
  </node>