<node TEXT="about nutri-west">
    <node TEXT="Main Content">
      <node TEXT="About Nutri-West">
        <node TEXT="Overview of Nutri-West's mission, history, and dedication to healthy patients."/>
      </node>
      <node TEXT="A Company Dedicated to Healthy Patients">
        <node TEXT="Nutri-West is a leading nutritional supplement company focused on quality and health care professionals."/>
      </node>
      <node TEXT="Our History">
        <node TEXT="Founded in 1982, Nutri-West has grown into a global company with a commitment to quality and research."/>
      </node>
      <node TEXT="Nutri-West Contact Details">
        <node TEXT="Location: P.O. Box 950, 210 E. Richards St. Douglas, WY 82633"/>
        <node TEXT="Email Us">
          <node TEXT="info@nutriwest.com" LINK="mailto:info@nutriwest.com"/>
          <node TEXT="info@nutri-west.net" LINK="mailto:info@nutri-west.net"/>
        </node>
        <node TEXT="Toll Free">
          <node TEXT="(800) 443-3333" LINK="tel:800-443-3333"/>
        </node>
        <node TEXT="Phone">
          <node TEXT="307-358-5066" LINK="tel:307-358-5066"/>
        </node>
        <node TEXT="Fax">
          <node TEXT="(307) 358-5208 (office) / (307) 358-5252 (orders)"/>
        </node>
      </node>
      <node TEXT="Made with pride in Wyoming">
        <node TEXT="Nutri-West values business integrity and personal service."/>
      </node>
      <node TEXT="Dedication to Health Care Providers">
        <node TEXT="Nutri-West is committed to providing the best service and support to health care providers."/>
      </node>
    </node>
  </node>