<node TEXT="home">
    <node TEXT="Header">
      <node TEXT="Top Bar">
        <node TEXT="Sign In As Provider" LINK="https://nutriwest.com/provider-account/signin"/>
        <node TEXT="Create Provider Account" LINK="https://nutriwest.com/provider-account"/>
        <node TEXT="Patient Connect" LINK="https://nutriwest.com/patient-connect"/>
        <node TEXT="Contact Us" LINK="https://nutriwest.com/contact-us"/>
        <node TEXT="Select Language"/>
      </node>
      <node TEXT="Navigation Links">
        <node TEXT="Home" LINK="https://nutriwest.com/"/>
        <node TEXT="About Nutri-West" LINK="https://nutriwest.com/about-nutriwest"/>
        <node TEXT="Products" LINK="https://nutriwest.com/products">
          <node TEXT="Nutri-West Products" LINK="https://nutriwest.com/products"/>
          <node TEXT="Homeopathic Products" LINK="https://nutriwest.com/products?category=homeopathic-products"/>
          <node TEXT="Herbal Tincture Products" LINK="https://nutriwest.com/products?category=tincture-products"/>
        </node>
        <node TEXT="Find A Nutri-West Distributor" LINK="https://nutriwest.com/distributors"/>
        <node TEXT="Seminars" LINK="https://nutriwest.com/seminars"/>
      </node>
    </node>
    <node TEXT="Main Content">
      <node TEXT="Hero Section">
        <node TEXT="A Company Dedicated to Healthy Patients"/>
        <node TEXT="Mission - Our fundamental focus is patient well-being. We hold to the principle that the healthcare provider is the surest way to optimal health."/>
        <node TEXT="Purpose - To provide the ultimate in nutritional products combined with superior education, to foster success for our providers and health for their patients."/>
        <node TEXT="Read More" LINK="https://nutriwest.com/about-nutriwest"/>
      </node>
      <node TEXT="Upcoming Seminars">
        <node TEXT="Macomb County Chiropractic Association Seminar">
          <node TEXT="Speaker: Dan Murphy, DC"/>
          <node TEXT="Distributor: Nutri-West Upper Midwest"/>
          <node TEXT="Location: Warren (Detroit), MI"/>
          <node TEXT="Telephone: 586-795-3866"/>
          <node TEXT="View More" LINK="https://nutriwest.com/seminars/macomb-county-chiropractic-association-seminar"/>
        </node>
        <node TEXT="WEBINAR - Cornerstone Nutrient Support for Thriving Functional Medicine and Chiropractic Practice">
          <node TEXT="Speaker: Jared Almoning, DC"/>
          <node TEXT="Distributor: Nutri-West 4 Life"/>
          <node TEXT="Location: WEBINAR"/>
          <node TEXT="Telephone: 800-255-3292"/>
          <node TEXT="View More" LINK="https://nutriwest.com/seminars/webinar-cornerstone-nutrient-support-for-thriving-functional-medicine-and-chiropractic-practice"/>
        </node>
      </node>
      <node TEXT="Quick Links Section">
        <node TEXT="Distributors - View Our Distributors" LINK="https://nutriwest.com/distributors"/>
        <node TEXT="Seminars - View Upcoming Seminars" LINK="https://nutriwest.com/seminars"/>
        <node TEXT="Employment - Check Current Openings" LINK="https://nutriwest.com/employment"/>
        <node TEXT="About Us - Know More About Us" LINK="https://nutriwest.com/about-nutriwest"/>
      </node>
      <node TEXT="Nutri-West Products">
        <node TEXT="Nutri-West products are made to the industry's most exacting standards of quality, purity, and potency. Our products are the most hypo-allergenic on the market."/>
        <node TEXT="#12 UR-KID (Herbal) - 100 tablets per bottle" LINK="https://nutriwest.com/products/12-ur-kid-herbal"/>
        <node TEXT="#14 LB-CLN (Herbal) - 100 tablets per bottle" LINK="https://nutriwest.com/products/14-lb-cln-herbal"/>
        <node TEXT="5-MTH Folate*** - 90 tablets per bottle" LINK="https://nutriwest.com/products/5-mth-folate"/>
        <node TEXT="Adenosyl B-12 Lozenge - 90 lozenge tablets per bottle" LINK="https://nutriwest.com/products/adenosyl-b-12-lozenge"/>
        <node TEXT="Browse Online Catalog" LINK="https://nutriwest.com/products"/>
        <node TEXT="How To Order" LINK="javascript:void(0);"/>
      </node>
      <node TEXT="Made with pride in Wyoming">
        <node TEXT="Where business is still done on a handshake"/>
        <node TEXT="Our dedication to you, the health care provider, is absolute. You deserve our personal best in service and support"/>
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Why Buy Nutri-West" LINK="https://nutriwest.com/page/why-buy-nutri-west"/>
      <node TEXT="Nutritional Supplements and Your Health" LINK="https://nutriwest.com/page/nutritional-supplements-and-your-health"/>
      <node TEXT="Nutri-West Manufacturing" LINK="https://nutriwest.com/page/nutri-west-manufacturing"/>
      <node TEXT="Nutri-West Distributor Login" LINK="https://nutriwest.com/distributor-login"/>
      <node TEXT="About Nutri-West">
        <node TEXT="About Our Products" LINK="https://nutriwest.com/page/about-our-products"/>
        <node TEXT="Educational Seminars" LINK="https://nutriwest.com/page/educational-seminars"/>
        <node TEXT="About Our Services" LINK="https://nutriwest.com/page/provider-access"/>
        <node TEXT="Rapid Shipping" LINK="https://nutriwest.com/page/rapid-shipping"/>
        <node TEXT="Direct-To-Patient Shipping" LINK="https://nutriwest.com/page/provider-access"/>
        <node TEXT="Register For An Account" LINK="https://nutriwest.com/provider-account/signin"/>
      </node>
      <node TEXT="Company Policies">
        <node TEXT="Terms Of Use" LINK="https://nutriwest.com/page/terms-of-use"/>
        <node TEXT="Resale Policy" LINK="https://nutriwest.com/page/resale-policy"/>
        <node TEXT="Return Policy - Provider" LINK="https://nutriwest.com/page/return-policy-provider"/>
        <node TEXT="Return Policy - Patient" LINK="https://nutriwest.com/page/return-policy-patient"/>
        <node TEXT="Privacy Policy" LINK="https://nutriwest.com/page/privacy-policy"/>
      </node>
      <node TEXT="Contact Us" LINK="https://nutriwest.com/contact-us"/>
    </node>
  </node>