<node TEXT="find a nutri-west distributor">
    <node TEXT="Main Content">
      <node TEXT="Nutri-West Distributors">
        <node TEXT="Find Nutri-West distributors by selecting your state or region."/>
        <node TEXT="Search by State">
          <node TEXT="State Dropdown"/>
          <node TEXT="Apply Button"/>
        </node>
        <node TEXT="Distributor Tabs">
          <node TEXT="U.S. Distributors"/>
          <node TEXT="Foreign Distributors"/>
        </node>
        <node TEXT="U.S. Distributor Map">
          <node TEXT="Interactive map showing distributor locations by state."/>
        </node>
        <node TEXT="Distributor Contact Information">
          <node TEXT="Nutri-West Corporate Office">
            <node TEXT="Contact details and states served: AL, AR, CO, LA, MS, OH, WV."/>
          </node>
          <node TEXT="Nutri-West of Florida">
            <node TEXT="Contact details and state served: Florida."/>
          </node>
          <node TEXT="Nutri-West New York">
            <node TEXT="Contact details and states served: CT, ME, MA, NH, NY, RI, VT."/>
          </node>
          <node TEXT="Nutri-West Southern California">
            <node TEXT="Contact details and state served: California."/>
          </node>
          <node TEXT="Nutri-West Kansas">
            <node TEXT="Contact details and states served: Kansas, Missouri."/>
          </node>
          <node TEXT="Nutri-West Northern California Hawaii">
            <node TEXT="Contact details and state served: California."/>
          </node>
          <node TEXT="Nutri-West Mid-Atlantic">
            <node TEXT="Contact details and states served: DE, MD, NJ, PA, VA."/>
          </node>
        </node>
      </node>
      <node TEXT="Made with pride in Wyoming">
        <node TEXT="Business is still done on a handshake and dedication to service and support."/>
      </node>
    </node>
  </node>