<node TEXT="products">
    <node TEXT="Main Content">
      <node TEXT="Browse Online Catalog">
        <node TEXT="Product Search Form">
          <node TEXT="Product Category Dropdown"/>
          <node TEXT="Index of Common Applications Group Field"/>
          <node TEXT="Product Name Field"/>
          <node TEXT="Ingredient Field"/>
          <node TEXT="Apply"/>
        </node>
      </node>
      <node TEXT="Product Listings">
        <node TEXT="#1 - AD (Tincture)" LINK="https://nutriwest.com/products/1-ad-tincture">
          <node TEXT="Herbal Tincture Products"/>
        </node>
        <node TEXT="#12 UR-KID (Herbal)" LINK="https://nutriwest.com/products/12-ur-kid-herbal">
          <node TEXT="Nutri-West Products"/>
        </node>
        <node TEXT="#14 LB-CLN (Herbal)" LINK="https://nutriwest.com/products/14-lb-cln-herbal">
          <node TEXT="Nutri-West Products"/>
        </node>
        <node TEXT="#2 - CF (Tincture)" LINK="https://nutriwest.com/products/2-cf-tincture">
          <node TEXT="Herbal Tincture Products"/>
        </node>
      </node>
      <node TEXT="Pride in Wyoming">
        <node TEXT="Business is still done on a handshake and products are made with pride in Wyoming."/>
        <node TEXT="Our dedication to health care providers is absolute, with a focus on personal best in service and support."/>
      </node>
    </node>
  </node>