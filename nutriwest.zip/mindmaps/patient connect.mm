<node TEXT="patient connect">
    <node TEXT="Patient Connect">
      <node TEXT="Main Content">
        <node TEXT="Patient Connect Section">
          <node TEXT="Request a Patient Connect Account by submitting an application; provider will verify and activate upon approval."/>
          <node TEXT="Create Patient Connect" LINK="https://nutriwest.com/patient-connect/code"/>
          <node TEXT="Already Connected?" LINK="https://nutriwest.com/patient-connect/signin"/>
        </node>
        <node TEXT="No Nutri-West Healthcare Provider?">
          <node TEXT="Distributors can refer you to healthcare providers who carry Nutri-West products."/>
          <node TEXT="Click Here To Connect With The Nutri-West Distributor For Your State or Country." LINK="https://nutriwest.com/distributors"/>
        </node>
        <node TEXT="Made with pride in Wyoming">
          <node TEXT="Business is still done on a handshake."/>
        </node>
        <node TEXT="Dedication Statement">
          <node TEXT="Our dedication to you, the health care provider, is absolute. You deserve our personal best in service and support."/>
        </node>
      </node>
    </node>
  </node>