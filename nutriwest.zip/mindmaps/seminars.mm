<node TEXT="seminars">
    <node TEXT="Main Content">
      <node TEXT="Introduction">
        <node TEXT="Nutri-West sponsors professional seminars and webinars on nutritional support for healthcare practices."/>
      </node>
      <node TEXT="October 2025">
        <node TEXT="Georgia Chiropractic Association Annual Fall Conference">
          <node TEXT="Speaker: Brandon Lundell, DC"/>
          <node TEXT="Distributor: Nutri-West Coastal Plains"/>
          <node TEXT="Location: Atlanta, GA"/>
          <node TEXT="Telephone: 770-723-1100"/>
          <node TEXT="View More" LINK="https://nutriwest.com/seminars/georgia-chiropractic-association-annual-fall-conference"/>
        </node>
        <node TEXT="Colorado Chiropractic Association 91st Annual Fall Convention">
          <node TEXT="Speaker: Dan Murphy, DC and Various Speakers"/>
          <node TEXT="Distributor: NUTRI-WEST CORPORATE OFFICE"/>
          <node TEXT="Location: Aurora, CO"/>
          <node TEXT="Telephone: 303-755-9011"/>
          <node TEXT="View More" LINK="https://nutriwest.com/seminars/colorado-chiropractic-association-91st-annual-fall-convention"/>
        </node>
      </node>
      <node TEXT="November 2025">
        <node TEXT="Macomb County Chiropractic Association Seminar">
          <node TEXT="Speaker: Dan Murphy, DC"/>
          <node TEXT="Distributor: Nutri-West Upper Midwest"/>
          <node TEXT="Location: Warren (Detroit), MI"/>
          <node TEXT="Telephone: 586-795-3366"/>
          <node TEXT="View More" LINK="https://nutriwest.com/seminars/macomb-county-chiropractic-association-seminar"/>
        </node>
      </node>
      <node TEXT="Wyoming Pride Section">
        <node TEXT="Nutri-West is proud of its Wyoming roots and commitment to service and support for healthcare providers."/>
      </node>
    </node>
  </node>