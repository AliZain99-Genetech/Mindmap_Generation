<node TEXT="select language">
    <node TEXT="Main Content">
      <node TEXT="Hero Section">
        <node TEXT="A company dedicated to healthy patients, focusing on patient well-being and provider education."/>
        <node TEXT="Read More" LINK="https://nutriwest.com/about-nutriwest"/>
      </node>
      <node TEXT="Upcoming Seminars">
        <node TEXT="Macomb County Chiropractic Association Seminar">
          <node TEXT="Nov 8-9, 2025, Warren (Detroit), MI. Speaker: Dan Murphy, DC."/>
          <node TEXT="View More" LINK="https://nutriwest.com/seminars/macomb-county-chiropractic-association-seminar"/>
        </node>
        <node TEXT="WEBINAR - Cornerstone Nutrient Support">
          <node TEXT="Dec 13, 2025, Webinar. Speaker: Jared Allomong, DC."/>
          <node TEXT="View More" LINK="https://nutriwest.com/seminars/webinar-cornerstone-nutrient-support-for-thriving-functional-medicine-and-chiropractic-practice"/>
        </node>
      </node>
      <node TEXT="Quick Access Tiles">
        <node TEXT="Distributors">
          <node TEXT="View Our Distributors" LINK="https://nutriwest.com/distributors"/>
        </node>
        <node TEXT="Seminars">
          <node TEXT="View Upcoming Seminars" LINK="https://nutriwest.com/seminars"/>
        </node>
        <node TEXT="Employment">
          <node TEXT="Check Current Openings" LINK="https://nutriwest.com/employment"/>
        </node>
        <node TEXT="About Us">
          <node TEXT="Know More About Us" LINK="https://nutriwest.com/about-nutriwest"/>
        </node>
      </node>
      <node TEXT="Nutri-West Products">
        <node TEXT="Industry-leading standards for quality, purity, and potency in nutritional supplements."/>
        <node TEXT="#12 UR-KID (Herbal)">
          <node TEXT="100 tablets per bottle" LINK="https://nutriwest.com/products/12-ur-kid-herbal"/>
        </node>
        <node TEXT="#14 LB-CLN (Herbal)">
          <node TEXT="100 tablets per bottle" LINK="https://nutriwest.com/products/14-lb-cln-herbal"/>
        </node>
        <node TEXT="5-MTH Folate***">
          <node TEXT="90 tablets per bottle" LINK="https://nutriwest.com/products/5-mth-folate"/>
        </node>
        <node TEXT="Adenosyl B-12 Lozenge">
          <node TEXT="90 lozenge tablets per bottle" LINK="https://nutriwest.com/products/adenosyl-b-12-lozenge"/>
        </node>
        <node TEXT="BROWSE ONLINE CATALOG" LINK="https://nutriwest.com/products"/>
        <node TEXT="HOW TO ORDER"/>
      </node>
      <node TEXT="Wyoming Pride Section">
        <node TEXT="Made with pride in Wyoming, where business is still done on a handshake."/>
        <node TEXT="Dedication to healthcare providers with personal best in service and support."/>
      </node>
    </node>
  </node>