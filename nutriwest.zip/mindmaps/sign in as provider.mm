<node TEXT="sign in as provider">
    <node TEXT="Main Content">
      <node TEXT="Sign In Healthcare Provider"/>
      <node TEXT="Sign In Form">
        <node TEXT="Email Address Field"/>
        <node TEXT="Password Field"/>
        <node TEXT="Remember Me Checkbox"/>
        <node TEXT="Sign In" LINK="https://nutriwest.com/provider-account/signin"/>
        <node TEXT="Did you forget your username or password?" LINK="https://nutriwest.com/provider-account/forgot-password"/>
      </node>
      <node TEXT="Sign Up For Professional Account">
        <node TEXT="Licensed and Certified Providers can access free webinar, fact sheets, training materials and more."/>
        <node TEXT="Sign Up" LINK="https://nutriwest.com/provider-account"/>
      </node>
      <node TEXT="Made with pride in Wyoming">
        <node TEXT="Business is still done on a handshake."/>
      </node>
      <node TEXT="Provider Dedication">
        <node TEXT="Our dedication to you, the health care provider, is absolute. You deserve our personal best in service and support."/>
      </node>
    </node>
  </node>