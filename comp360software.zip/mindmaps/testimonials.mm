<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="testimonials">
    <node TEXT="Real stories from companies transforming their sales organizations">
      <node TEXT="Customer testimonials and success stories summary" />
    </node>
    <node TEXT="Customer Feedback Highlights">
      <node TEXT="Engineering project incentive management (Wasay Siddiqui)" />
      <node TEXT="Sales team commission management and tracking (Jaffer Bhaila)" />
    </node>
    <node TEXT="Ready to Simplify Sales Compensation and Forecast Smarter?">
      <node TEXT="AI-powered platform for commission, quota, and reporting overview" />
      <node TEXT="Request a Demo">
        <node TEXT="Request a Demo" LINK="https://comp360software.com/request-a-demo/" />
      </node>
      <node TEXT="See Pricing">
        <node TEXT="See Pricing" LINK="https://comp360software.com/pricing/" />
      </node>
    </node>
  </node>
</map>