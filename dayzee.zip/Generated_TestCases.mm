<map version="1.0.1">
<node TEXT="Test Cases" POSITION="left" FOLDED="true">
    <node TEXT="ABOUT US Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the ABOUT US link in the header navigates the user to the About Us page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The About Us page displays the company mission and vision statements." FOLDED="true" POSITION="left" />
            <node TEXT="3. The About Us page loads all major initiatives and impact sections without errors." FOLDED="true" POSITION="left" />
            <node TEXT="4. The contact form on the About Us page accepts valid user input and submits successfully." FOLDED="true" POSITION="left" />
            <node TEXT="5. The About Us page displays images and graphics correctly." FOLDED="true" POSITION="left" />
            <node TEXT="6. The About Us page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
            <node TEXT="7. The About Us page displays the organization's history and timeline." FOLDED="true" POSITION="left" />
            <node TEXT="8. The About Us page provides working links to related sections or external resources." FOLDED="true" POSITION="left" />
            <node TEXT="9. The About Us page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
            <node TEXT="10. The About Us page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
            <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
            <node TEXT="3. Attempting to access the About Us page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
            <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
            <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
            <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
            <node TEXT="7. Disabling JavaScript and clicking the ABOUT US link does not navigate to the page." FOLDED="true" POSITION="left" />
            <node TEXT="8. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
            <node TEXT="9. Trying to access the About Us page while logged out (if authentication is required) redirects to login." FOLDED="true" POSITION="left" />
            <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The About Us page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="2. The About Us page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
            <node TEXT="3. The About Us page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="4. The About Us page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
            <node TEXT="5. The About Us page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
            <node TEXT="6. The About Us page content is protected from unauthorized editing." FOLDED="true" POSITION="left" />
            <node TEXT="7. The About Us page images are optimized for fast loading." FOLDED="true" POSITION="left" />
            <node TEXT="8. The About Us page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
            <node TEXT="9. The About Us page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
            <node TEXT="10. The About Us page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
        </node>
    </node>
    <node TEXT="LIVESTOCK Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the LIVESTOCK link in the header navigates the user to the Livestock page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Livestock page displays information about available livestock genetics and services." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Livestock page provides working links to request semen or embryo services." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Livestock page contact form accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Livestock page displays images of livestock and related programs." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Livestock page allows users to book consultations via provided links." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Livestock page lists all available livestock breeds with descriptions." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Livestock page provides downloadable catalogues for each breed." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Livestock page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Livestock page content is accessible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
            <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
            <node TEXT="3. Attempting to access the Livestock page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
            <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
            <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
            <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
            <node TEXT="7. Clicking on a broken catalogue link displays an error or missing file message." FOLDED="true" POSITION="left" />
            <node TEXT="8. Disabling JavaScript and clicking the LIVESTOCK link does not navigate to the page." FOLDED="true" POSITION="left" />
            <node TEXT="9. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
            <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The Livestock page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Livestock page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Livestock page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Livestock page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Livestock page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Livestock page images are optimized for fast loading." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Livestock page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Livestock page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Livestock page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Livestock page downloadable catalogues are under 10MB for quick access." FOLDED="true" POSITION="left" />
        </node>
    </node>
    <node TEXT="AGRICULTURE Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the AGRICULTURE link in the header navigates the user to the Agriculture page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Agriculture page displays information about land transformation and farming technology." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Agriculture page lists all available products and services with descriptions." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Agriculture page displays images and graphics related to agricultural projects." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Agriculture page contact form accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Agriculture page provides working links to partner organizations." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Agriculture page displays a timeline of major agricultural milestones." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Agriculture page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Agriculture page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Agriculture page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
            <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
            <node TEXT="3. Attempting to access the Agriculture page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
            <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
            <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
            <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
            <node TEXT="7. Disabling JavaScript and clicking the AGRICULTURE link does not navigate to the page." FOLDED="true" POSITION="left" />
            <node TEXT="8. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
            <node TEXT="9. Trying to access the Agriculture page while logged out (if authentication is required) redirects to login." FOLDED="true" POSITION="left" />
            <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The Agriculture page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Agriculture page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Agriculture page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Agriculture page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Agriculture page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Agriculture page images are optimized for fast loading." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Agriculture page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Agriculture page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Agriculture page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Agriculture page content is readable under high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
        </node>
    </node>
    <node TEXT="RENEWABLE ENERGY Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the RENEWABLE ENERGY link in the header navigates the user to the Renewable Energy page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Renewable Energy page displays information about solar and biogas initiatives." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Renewable Energy page lists all renewable energy projects with descriptions." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Renewable Energy page displays images and graphics related to energy infrastructure." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Renewable Energy page contact form accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Renewable Energy page provides working links to CSR and partner organizations." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Renewable Energy page displays statistics about energy output and impact." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Renewable Energy page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Renewable Energy page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Renewable Energy page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
            <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
            <node TEXT="3. Attempting to access the Renewable Energy page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
            <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
            <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
            <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
            <node TEXT="7. Disabling JavaScript and clicking the RENEWABLE ENERGY link does not navigate to the page." FOLDED="true" POSITION="left" />
            <node TEXT="8. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
            <node TEXT="9. Trying to access the Renewable Energy page while logged out (if authentication is required) redirects to login." FOLDED="true" POSITION="left" />
            <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The Renewable Energy page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Renewable Energy page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Renewable Energy page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Renewable Energy page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Renewable Energy page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Renewable Energy page images are optimized for fast loading." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Renewable Energy page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Renewable Energy page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Renewable Energy page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Renewable Energy page content is readable under high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
        </node>
    </node>
    <node TEXT="GALLERY Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the GALLERY link in the header navigates the user to the Gallery page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Gallery page displays a grid or list of event and project images." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Gallery page allows users to click on images to view them in a larger format." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Gallery page provides working links to event-specific galleries." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Gallery page displays image captions and event descriptions." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Gallery page contact form accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Gallery page allows users to filter or search images by event or category." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Gallery page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Gallery page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Gallery page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
            <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
            <node TEXT="3. Attempting to access the Gallery page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
            <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
            <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
            <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
            <node TEXT="7. Clicking on a broken image link displays a missing image icon or error." FOLDED="true" POSITION="left" />
            <node TEXT="8. Disabling JavaScript and clicking the GALLERY link does not navigate to the page." FOLDED="true" POSITION="left" />
            <node TEXT="9. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
            <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The Gallery page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Gallery page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Gallery page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Gallery page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Gallery page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Gallery page images are optimized for fast loading and minimal bandwidth usage." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Gallery page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Gallery page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Gallery page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Gallery page content is readable under high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
        </node>
    </node>
    <node TEXT="CONTACT US Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the CONTACT US link in the header navigates the user to the Contact Us page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Contact Us page displays the company's office address, phone numbers, and email." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Contact Us page provides a working Google Maps link to the office location." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Contact Us page contact form accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Contact Us page displays a dropdown for city selection with Karachi as default." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Contact Us page displays all required contact fields and labels." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Contact Us page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Contact Us page allows users to call or email directly via clickable links." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Contact Us page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Contact Us page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
            <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
            <node TEXT="3. Attempting to access the Contact Us page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
            <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
            <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
            <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
            <node TEXT="7. Selecting an invalid city from the dropdown displays a validation error." FOLDED="true" POSITION="left" />
            <node TEXT="8. Disabling JavaScript and clicking the CONTACT US link does not navigate to the page." FOLDED="true" POSITION="left" />
            <node TEXT="9. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
            <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The Contact Us page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Contact Us page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Contact Us page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Contact Us page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Contact Us page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Contact Us page images and maps are optimized for fast loading." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Contact Us page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Contact Us page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Contact Us page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Contact Us page content is readable under high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
        </node>
    </node>
    <node TEXT="Home Page Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the Home Page link in the header navigates the user to the main landing page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Home Page displays the hero section with title, subtitle, and background image." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Home Page displays sections for Livestock, Agriculture, and Renewable Energy." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Home Page provides working 'Learn More' buttons for each main section." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Home Page displays a contact form that accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Home Page displays benefits and program information for each business area." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Home Page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Home Page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Home Page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Home Page displays footer information and links correctly." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
            <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
            <node TEXT="3. Attempting to access the Home Page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
            <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
            <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
            <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
            <node TEXT="7. Clicking on a broken 'Learn More' button displays an error or does not navigate." FOLDED="true" POSITION="left" />
            <node TEXT="8. Disabling JavaScript and clicking the Home Page link does not navigate to the page." FOLDED="true" POSITION="left" />
            <node TEXT="9. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
            <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The Home Page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="2. The Home Page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
            <node TEXT="3. The Home Page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="4. The Home Page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
            <node TEXT="5. The Home Page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
            <node TEXT="6. The Home Page images and graphics are optimized for fast loading." FOLDED="true" POSITION="left" />
            <node TEXT="7. The Home Page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
            <node TEXT="8. The Home Page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
            <node TEXT="9. The Home Page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
            <node TEXT="10. The Home Page content is readable under high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
        </node>
    </node>
</node>
</map>