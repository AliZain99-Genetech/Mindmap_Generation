<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Dayzee">
    <node TEXT="Header">
      <node TEXT="Logo">
        <node TEXT="DayZee" LINK="https://dayzee.com/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Navigation">
        <node TEXT="About Us" LINK="https://dayzee.com/about/">
          <node TEXT="Introduction   Vision">
            <node TEXT="DayZee Farms Began with a Bold Idea" />
            <node TEXT="Genetics was just the start" />
          </node>
          <node TEXT="Key Achievements   Initiatives">
            <node TEXT="We launched DayZee Livestock" />
            <node TEXT="DayZee Agriculture" />
            <node TEXT="Solar installation" />
            <node TEXT="Intersection of science and soil" />
          </node>
          <node TEXT="UN Sustainable Development Goals Impact">
            <node TEXT="SDG 2 – Zero Hunger" />
            <node TEXT="SDG 7 – Affordable and Clean Energy" />
            <node TEXT="SDG 9 – Industry, Innovation and Infrastructure" />
            <node TEXT="SDG 12 – Responsible Consumption and Production" />
            <node TEXT="SDG 13 – Climate Action" />
          </node>
          <node TEXT="Contact   Inquiry Form">
            <node TEXT="First Name" />
            <node TEXT="Last Name" />
            <node TEXT="Email" />
            <node TEXT="Mobile Number" />
            <node TEXT="Company Name" />
            <node TEXT="Country" />
            <node TEXT="Interested In" />
            <node TEXT="Message" />
            <node TEXT="SUBMIT" />
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Livestock" LINK="https://dayzee.com/live-stock/">
          <node TEXT="Superior Genetics For Tomorrow">
            <node TEXT="Request Semen/Embryo">
              <node TEXT="tel:+923314476666" />
            </node>
            <node TEXT="Book a Consultation">
              <node TEXT="tel:+923314431111" />
            </node>
            <node TEXT="Book OPU of your cow now">
              <node TEXT="tel:+923314431111" />
            </node>
          </node>
          <node TEXT="About Our Genetics">
            <node TEXT="Slick Gene Frisien - Special Heat-Resistant, 40+ L Milk" />
            <node TEXT="Brahman - 300+ kg at 7 Months, Beef   Bragging Rights!" />
            <node TEXT="Beefmaster - Fertility, Gain   Premium Production" />
            <node TEXT="Red Angus - Fertility, Calving   Premium Beef" />
          </node>
          <node TEXT="Our Services">
            <node TEXT="Semen Availability - Climate-adapted, top performing bulls" />
            <node TEXT="Embryo Transfer Pregnancies - Elite embryos for local recipients" />
            <node TEXT="Pregnant Heifers for Sale - Health certified   pregnancy-verified" />
            <node TEXT="Genetics Consultation - Sire selection to embryo strategy" />
          </node>
          <node TEXT="Elite Calves Promotion">
            <node TEXT="Want 20+ calves from one elite donor cow?" />
            <node TEXT="Book OPU Now">
              <node TEXT="tel:+92314431111" />
            </node>
          </node>
          <node TEXT="Explore Our Genetic Catalogue">
            <node TEXT="Brahman Catalogue">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_American-Brahmans.pdf.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Slick-Gene Friesian Catalogue">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Slick-Gene.pdf.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Beefmaster Catalogue">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Beef-Master.pdf.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Red Angus Catalogue">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Red-Angus.pdf.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Our Global Partners" />
          <node TEXT="Get in Touch - Let’s Get Started">
            <node TEXT="Contact Form">
              <node TEXT="First Name" />
              <node TEXT="Last Name" />
              <node TEXT="Email" />
              <node TEXT="Mobile Number" />
              <node TEXT="Company Name" />
              <node TEXT="City (dropdown)" />
              <node TEXT="Country" />
              <node TEXT="Interested In" />
              <node TEXT="Message" />
              <node TEXT="Submit" />
            </node>
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Agriculture" LINK="https://dayzee.com/agriculture/">
          <node TEXT="Intro: 4,200 Acres Sustainable Agricultural Hub" />
          <node TEXT="A New Era of Desert Farming">
            <node TEXT="Desert transformation and innovation summary" />
          </node>
          <node TEXT="Barren Land Visual Timeline">
            <node TEXT="April-2024, March-2025, May-2025 photos" />
          </node>
          <node TEXT="Technology In Agriculture">
            <node TEXT="Irrigation Systems: Central Pivot technology overview" />
            <node TEXT="Mechanized Farm Machinery: Modern equipment" />
            <node TEXT="Solar Power Plant: 6MW Solar installation" />
          </node>
          <node TEXT="Our Products">
            <node TEXT="Alfalfa: Forage crop for dairy and beef cattle" />
            <node TEXT="Rhodes Grass: Drought-resistant grass for livestock" />
          </node>
          <node TEXT="Our Services">
            <node TEXT="Land Development: Transforming barren land" />
            <node TEXT="Center Pivot Irrigation Systems: Full service and maintenance" />
            <node TEXT="Farm Operations: Precision crop cycle operations" />
            <node TEXT="Integrated Farm Management: Planning and execution" />
            <node TEXT="Irrigation   Infrastructure Consultancy: Expert solutions" />
          </node>
          <node TEXT="Our Global Partners">
            <node TEXT="Logos of international agricultural partners" />
          </node>
          <node TEXT="Get in touch Let’s Get Started">
            <node TEXT="Contact Form">
              <node TEXT="First Name*" />
              <node TEXT="Last Name*" />
              <node TEXT="Email*" />
              <node TEXT="Mobile Number*" />
              <node TEXT="Company Name" />
              <node TEXT="Country" />
              <node TEXT="Interested In" />
              <node TEXT="Message" />
              <node TEXT="SUBMIT" />
            </node>
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Renewable Energy" LINK="https://dayzee.com/renewable-energy/">
          <node TEXT="Hero Section">
            <node TEXT="Reducing Carbon Emissions Today – Building A 100% Clean Energy Future" />
          </node>
          <node TEXT="Solar Panel Infrastructure">
            <node TEXT="Summary: 6MW solar panel system for efficient and sustainable farm energy." />
          </node>
          <node TEXT="Our Biogas Plant">
            <node TEXT="Summary: Converts organic farm waste to biogas for energy and waste reduction." />
          </node>
          <node TEXT="Key Stats">
            <node TEXT="500 Delivered Packages" />
            <node TEXT="500 Global Shipping" />
            <node TEXT="500 Air Freight" />
            <node TEXT="500 Happy Customers" />
          </node>
          <node TEXT="Corporate Social Responsibility (CSR)">
            <node TEXT="Empowering Rural Communities - 150+ jobs created, livelihoods uplifted" />
            <node TEXT="Farmer Development - Awareness sessions for modern farming" />
            <node TEXT="Environmental Stewardship - Solar and biogas projects for sustainability" />
            <node TEXT="Animal Ethics   Welfare - Focus on care, nutrition, ethical practices" />
          </node>
          <node TEXT="Get in touch – Let’s Get Started">
            <node TEXT="Contact Form">
              <node TEXT="First Name*" />
              <node TEXT="Last Name*" />
              <node TEXT="Email*" />
              <node TEXT="Mobile Number*" />
              <node TEXT="Company Name" />
              <node TEXT="Location (Dropdown: Karachi)" />
              <node TEXT="Country" />
              <node TEXT="Interested In" />
              <node TEXT="Message" />
              <node TEXT="Submit" />
            </node>
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/">
          <node TEXT="Image Gallery Section">
            <node TEXT="Featured Event: DayZee at International Livestock, Dairy, Poultry and Agri Expo 2025">
              <node TEXT="Gallery Link" LINK="https://dayzee.com/gallery/dayzee-at-ildpa2025/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery_dayzee-at-ildpa2025.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Featured Visit: Chinese Delegation at DayZee (Private) Limited">
              <node TEXT="Gallery Link" LINK="https://dayzee.com/gallery/chinese-delegation/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery_chinese-delegation.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Get In Touch Section">
            <node TEXT="Contact and Inquiry Form">
              <node TEXT="First Name*" />
              <node TEXT="Last Name*" />
              <node TEXT="Email*" />
              <node TEXT="Mobile Number*" />
              <node TEXT="Company Name" />
              <node TEXT="City Dropdown (e.g. Karachi)" />
              <node TEXT="Country" />
              <node TEXT="Interested In" />
              <node TEXT="Message" />
              <node TEXT="SUBMIT button" />
            </node>
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/">
          <node TEXT="Contact Information">
            <node TEXT="Our Office">
              <node TEXT="DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur.">
                <node TEXT="View on Map">
                  <node TEXT="https://maps.app.goo.gl/WstmNjesSmVKyyB66" LINK="https://maps.app.goo.gl/WstmNjesSmVKyyB66"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_WstmNjesSmVKyyB66.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                </node>
              </node>
            </node>
            <node TEXT="Call Us">
              <node TEXT="0331-443 1111">
                <node TEXT="tel:0331 443 1111" />
              </node>
              <node TEXT="0331-447 6666">
                <node TEXT="tel:0331 447 66 66" />
              </node>
            </node>
            <node TEXT="Email Address">
              <node TEXT="info@dayzee.com">
                <node TEXT="mailto:info@dayzee.com" LINK="mailto:info@dayzee.com" />
              </node>
            </node>
          </node>
          <node TEXT="Contact Location Map">
            <node TEXT="Embedded map showing DayZee Farms location" />
          </node>
          <node TEXT="Get in Touch Form">
            <node TEXT="First Name (input)" />
            <node TEXT="Last Name (input)" />
            <node TEXT="Email (input)" />
            <node TEXT="Mobile Number (input)" />
            <node TEXT="Company Name (input)" />
            <node TEXT="City (dropdown)" />
            <node TEXT="Country (input)" />
            <node TEXT="Interested In (input)" />
            <node TEXT="Message (textarea)" />
            <node TEXT="Submit Button">
              <node TEXT="SUBMIT" />
            </node>
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Skip to content" LINK="https://dayzee.com/#content"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_content.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Home Page">
      <node TEXT="Hero Section">
        <node TEXT="Background Image" />
        <node TEXT="Title: AGRICULTURE" />
        <node TEXT="Subtitle: Innovating Modern Farming" />
      </node>
      <node TEXT="Livestock Section">
        <node TEXT="Title: LIVESTOCK" />
        <node TEXT="Subtitle: In Elite Genetics for Unmatched Livestock Performance" />
        <node TEXT="Description" />
        <node TEXT="Learn More Button" LINK="https://dayzee.com/live-stock/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Programs">
          <node TEXT="Invitro Fertilization Program" />
          <node TEXT="Artificial Insemination Program" />
          <node TEXT="Genetics Lab" />
        </node>
      </node>
      <node TEXT="Benefits Section">
        <node TEXT="Heat Tolerance" />
        <node TEXT="Fertility   Productivity" />
        <node TEXT="Long-Term Profitability" />
      </node>
      <node TEXT="Agriculture Section">
        <node TEXT="Title: Agriculture" />
        <node TEXT="Subtitle: Turning Barren Land into Agricultural Gold" />
        <node TEXT="Description" />
        <node TEXT="Learn More Button" LINK="https://dayzee.com/agriculture/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Programs">
          <node TEXT="Pivot Irrigation" />
          <node TEXT="Mechanized Farming" />
          <node TEXT="Premium Animal Fodder" />
        </node>
      </node>
      <node TEXT="Renewable Energy Section">
        <node TEXT="Title: Renewable Energy" />
        <node TEXT="Subtitle: Sustainable and Smart Agriculture" />
        <node TEXT="Explore Our Sustainability Button" LINK="https://dayzee.com/renewable-energy/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Programs">
          <node TEXT="Solar Powered Future" />
          <node TEXT="Biogas To Energy" />
        </node>
      </node>
      <node TEXT="Contact Section">
        <node TEXT="Get in touch Let’s Get Started" />
        <node TEXT="Contact Form">
          <node TEXT="First Name*" />
          <node TEXT="Last Name*" />
          <node TEXT="Email*" />
          <node TEXT="Mobile Number*" />
          <node TEXT="Company Name" />
          <node TEXT="City (Dropdown, e.g., Karachi)" />
          <node TEXT="Country" />
          <node TEXT="Interested In" />
          <node TEXT="Message" />
          <node TEXT="Submit Button" />
        </node>
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="About Company">
        <node TEXT="Company Description" />
      </node>
      <node TEXT="Company Links">
        <node TEXT="Home" LINK="https://dayzee.com/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Services" LINK="https://dayzee.com/service/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_service.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Quick Links">
        <node TEXT="About Us" LINK="https://dayzee.com/about/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="FAQs" LINK="https://dayzee.com/faqs"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_faqs.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Follow us at">
        <node TEXT="Facebook" LINK="https://www.facebook.com/dayzeepvtltd"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.facebook.com_dayzeepvtltd.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Tik Tok" LINK="https://www.tiktok.com/@dayzee.pvt.ltd"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.tiktok.com_dayzee.pvt.ltd.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Instagram" LINK="https://www.instagram.com/dayzee_pvt_ltd/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.instagram.com_dayzee_pvt_ltd.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Youtube" LINK="https://www.youtube.com/@DayZee_Pvt_Ltd"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.youtube.com_DayZee_Pvt_Ltd.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Copyright">
        <node TEXT="Copyright © 2025 DayZee. All Rights Reserved" />
      </node>
    </node>
  </node>
</map>