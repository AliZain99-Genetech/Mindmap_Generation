<map version="1.0.1">
<node TEXT="Test Cases" POSITION="left" FOLDED="true">
    <node TEXT="ABOUT US Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Verify that clicking the ABOUT US link in the header navigates the user to the About Us page."/>
            <node TEXT="2. Confirm that the About Us page loads all main sections, including Introduction, Vision, and Key Achievements."/>
            <node TEXT="3. Ensure that the UN Sustainable Development Goals Impact section is visible and displays all listed SDGs."/>
            <node TEXT="4. Validate that the Contact &amp; Inquiry Form is present and all input fields are displayed correctly."/>
            <node TEXT="5. Test that submitting the Contact &amp; Inquiry Form with valid data shows a success message."/>
            <node TEXT="6. Check that the page title and meta description are relevant to About Us."/>
            <node TEXT="7. Ensure that all images and graphics on the About Us page load without errors."/>
            <node TEXT="8. Verify that the navigation menu remains accessible after navigating to the About Us page."/>
            <node TEXT="9. Confirm that the About Us page is accessible via direct URL entry in the browser."/>
            <node TEXT="10. Test that the browser back button returns the user to the previous page from About Us."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempt to submit the Contact &amp; Inquiry Form with empty required fields and verify that validation errors are shown."/>
            <node TEXT="2. Enter an invalid email address in the form and ensure an appropriate error message is displayed."/>
            <node TEXT="3. Input special characters in the First Name field and check for validation errors."/>
            <node TEXT="4. Submit the form with an excessively long message and verify that the form handles it gracefully."/>
            <node TEXT="5. Try to access the About Us page with a malformed URL and confirm a 404 or error page is shown."/>
            <node TEXT="6. Attempt to upload a file in the message field (if not supported) and ensure the form rejects it."/>
            <node TEXT="7. Submit the form with a missing country selection and verify that an error is displayed."/>
            <node TEXT="8. Test form submission with a script injection attempt and ensure it is sanitized."/>
            <node TEXT="9. Try to submit the form multiple times rapidly and check for duplicate prevention."/>
            <node TEXT="10. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Measure the load time of the About Us page to ensure it loads within 2 seconds on a standard connection."/>
            <node TEXT="2. Verify that the About Us page is responsive and displays correctly on mobile devices."/>
            <node TEXT="3. Check that all text on the About Us page is readable with sufficient color contrast."/>
            <node TEXT="4. Test the accessibility of the About Us page using a screen reader."/>
            <node TEXT="5. Confirm that the About Us page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="6. Simulate a slow network and ensure the About Us page content remains usable."/>
            <node TEXT="7. Test the About Us page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency."/>
            <node TEXT="8. Verify that the About Us page does not have broken links or missing images."/>
            <node TEXT="9. Check that the Contact &amp; Inquiry Form is protected against spam submissions (e.g., CAPTCHA or rate limiting)."/>
            <node TEXT="10. Ensure that the About Us page is indexed by search engines and appears in search results."/>
        </node>
    </node>
    <node TEXT="LIVESTOCK Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Verify that clicking the LIVESTOCK link in the header navigates to the Livestock page."/>
            <node TEXT="2. Confirm that the Livestock page displays the Superior Genetics For Tomorrow section."/>
            <node TEXT="3. Ensure that the Request Semen/Embryo and Book a Consultation phone links are clickable and initiate a call."/>
            <node TEXT="4. Validate that the Explore Our Genetic Catalogue section lists all available catalogues with working links."/>
            <node TEXT="5. Test that the Get in Touch form is present and all fields are visible."/>
            <node TEXT="6. Submit the Get in Touch form with valid data and verify a success message is shown."/>
            <node TEXT="7. Check that the Our Services section lists all services with correct descriptions."/>
            <node TEXT="8. Ensure that the Elite Calves Promotion section is visible and the Book OPU Now link works."/>
            <node TEXT="9. Verify that the Livestock page is accessible via direct URL entry."/>
            <node TEXT="10. Confirm that the navigation menu remains functional after navigating to the Livestock page."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempt to submit the Get in Touch form with empty required fields and verify validation errors are shown."/>
            <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed."/>
            <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors."/>
            <node TEXT="4. Submit the form with an excessively long company name and verify proper handling."/>
            <node TEXT="5. Try to access a non-existent catalogue link and confirm a 404 or error page is shown."/>
            <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized."/>
            <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention."/>
            <node TEXT="8. Try to click the phone links on a desktop browser and verify appropriate behavior."/>
            <node TEXT="9. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided."/>
            <node TEXT="10. Attempt to submit the form with a missing city selection and verify an error is displayed."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Measure the load time of the Livestock page to ensure it loads within 2 seconds on a standard connection."/>
            <node TEXT="2. Verify that the Livestock page is responsive and displays correctly on mobile devices."/>
            <node TEXT="3. Check that all text and buttons on the Livestock page are readable with sufficient color contrast."/>
            <node TEXT="4. Test the accessibility of the Livestock page using a screen reader."/>
            <node TEXT="5. Confirm that the Livestock page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="6. Simulate a slow network and ensure the Livestock page content remains usable."/>
            <node TEXT="7. Test the Livestock page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency."/>
            <node TEXT="8. Verify that all catalogue PDF links are downloadable and not broken."/>
            <node TEXT="9. Check that the Get in Touch form is protected against spam submissions (e.g., CAPTCHA or rate limiting)."/>
            <node TEXT="10. Ensure that the Livestock page is indexed by search engines and appears in search results."/>
        </node>
    </node>
    <node TEXT="AGRICULTURE Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Verify that clicking the AGRICULTURE link in the header navigates to the Agriculture page."/>
            <node TEXT="2. Confirm that the Agriculture page displays the Intro and A New Era of Desert Farming sections."/>
            <node TEXT="3. Ensure that the Barren Land Visual Timeline is visible and shows all listed photos."/>
            <node TEXT="4. Validate that the Technology In Agriculture section lists all technologies with descriptions."/>
            <node TEXT="5. Test that the Our Products section displays Alfalfa and Rhodes Grass with details."/>
            <node TEXT="6. Check that the Our Services section lists all services with correct descriptions."/>
            <node TEXT="7. Ensure that the Our Global Partners section displays partner logos."/>
            <node TEXT="8. Verify that the Get in Touch form is present and all fields are visible."/>
            <node TEXT="9. Submit the Get in Touch form with valid data and verify a success message is shown."/>
            <node TEXT="10. Confirm that the navigation menu remains functional after navigating to the Agriculture page."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempt to submit the Get in Touch form with empty required fields and verify validation errors are shown."/>
            <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed."/>
            <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors."/>
            <node TEXT="4. Submit the form with an excessively long message and verify proper handling."/>
            <node TEXT="5. Try to access a non-existent product link and confirm a 404 or error page is shown."/>
            <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized."/>
            <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention."/>
            <node TEXT="8. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided."/>
            <node TEXT="9. Attempt to submit the form with a missing country selection and verify an error is displayed."/>
            <node TEXT="10. Try to upload a file in the message field (if not supported) and ensure the form rejects it."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Measure the load time of the Agriculture page to ensure it loads within 2 seconds on a standard connection."/>
            <node TEXT="2. Verify that the Agriculture page is responsive and displays correctly on mobile devices."/>
            <node TEXT="3. Check that all text and images on the Agriculture page are readable with sufficient color contrast."/>
            <node TEXT="4. Test the accessibility of the Agriculture page using a screen reader."/>
            <node TEXT="5. Confirm that the Agriculture page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="6. Simulate a slow network and ensure the Agriculture page content remains usable."/>
            <node TEXT="7. Test the Agriculture page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency."/>
            <node TEXT="8. Verify that all product and service links are not broken."/>
            <node TEXT="9. Check that the Get in Touch form is protected against spam submissions (e.g., CAPTCHA or rate limiting)."/>
            <node TEXT="10. Ensure that the Agriculture page is indexed by search engines and appears in search results."/>
        </node>
    </node>
    <node TEXT="RENEWABLE ENERGY Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Verify that clicking the RENEWABLE ENERGY link in the header navigates to the Renewable Energy page."/>
            <node TEXT="2. Confirm that the Hero Section displays the correct title and subtitle."/>
            <node TEXT="3. Ensure that the Solar Panel Infrastructure section is visible and contains the summary."/>
            <node TEXT="4. Validate that the Our Biogas Plant section is present and displays the correct information."/>
            <node TEXT="5. Check that the Key Stats section lists all statistics accurately."/>
            <node TEXT="6. Ensure that the Corporate Social Responsibility section lists all initiatives."/>
            <node TEXT="7. Verify that the Get in Touch form is present and all fields are visible."/>
            <node TEXT="8. Submit the Get in Touch form with valid data and verify a success message is shown."/>
            <node TEXT="9. Confirm that the navigation menu remains functional after navigating to the Renewable Energy page."/>
            <node TEXT="10. Verify that the Renewable Energy page is accessible via direct URL entry."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempt to submit the Get in Touch form with empty required fields and verify validation errors are shown."/>
            <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed."/>
            <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors."/>
            <node TEXT="4. Submit the form with an excessively long message and verify proper handling."/>
            <node TEXT="5. Try to access a non-existent section link and confirm a 404 or error page is shown."/>
            <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized."/>
            <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention."/>
            <node TEXT="8. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided."/>
            <node TEXT="9. Attempt to submit the form with a missing location selection and verify an error is displayed."/>
            <node TEXT="10. Try to upload a file in the message field (if not supported) and ensure the form rejects it."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Measure the load time of the Renewable Energy page to ensure it loads within 2 seconds on a standard connection."/>
            <node TEXT="2. Verify that the Renewable Energy page is responsive and displays correctly on mobile devices."/>
            <node TEXT="3. Check that all text and images on the Renewable Energy page are readable with sufficient color contrast."/>
            <node TEXT="4. Test the accessibility of the Renewable Energy page using a screen reader."/>
            <node TEXT="5. Confirm that the Renewable Energy page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="6. Simulate a slow network and ensure the Renewable Energy page content remains usable."/>
            <node TEXT="7. Test the Renewable Energy page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency."/>
            <node TEXT="8. Verify that all section links are not broken."/>
            <node TEXT="9. Check that the Get in Touch form is protected against spam submissions (e.g., CAPTCHA or rate limiting)."/>
            <node TEXT="10. Ensure that the Renewable Energy page is indexed by search engines and appears in search results."/>
        </node>
    </node>
    <node TEXT="GALLERY Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Verify that clicking the GALLERY link in the header navigates to the Gallery page."/>
            <node TEXT="2. Confirm that the Image Gallery Section displays featured events and visits."/>
            <node TEXT="3. Ensure that the gallery images are visible and load correctly."/>
            <node TEXT="4. Validate that clicking on a gallery image opens it in a larger view or lightbox."/>
            <node TEXT="5. Check that the Gallery Link for each featured event navigates to the correct gallery page."/>
            <node TEXT="6. Ensure that the Get In Touch Section is present and all form fields are visible."/>
            <node TEXT="7. Submit the Contact and Inquiry Form with valid data and verify a success message is shown."/>
            <node TEXT="8. Verify that the navigation menu remains functional after navigating to the Gallery page."/>
            <node TEXT="9. Confirm that the Gallery page is accessible via direct URL entry."/>
            <node TEXT="10. Test that the browser back button returns the user to the previous page from Gallery."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempt to submit the Contact and Inquiry Form with empty required fields and verify validation errors are shown."/>
            <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed."/>
            <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors."/>
            <node TEXT="4. Submit the form with an excessively long message and verify proper handling."/>
            <node TEXT="5. Try to access a non-existent gallery link and confirm a 404 or error page is shown."/>
            <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized."/>
            <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention."/>
            <node TEXT="8. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided."/>
            <node TEXT="9. Attempt to submit the form with a missing city selection and verify an error is displayed."/>
            <node TEXT="10. Try to upload a file in the message field (if not supported) and ensure the form rejects it."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Measure the load time of the Gallery page to ensure it loads within 2 seconds on a standard connection."/>
            <node TEXT="2. Verify that the Gallery page is responsive and displays correctly on mobile devices."/>
            <node TEXT="3. Check that all images and text on the Gallery page are readable with sufficient color contrast."/>
            <node TEXT="4. Test the accessibility of the Gallery page using a screen reader."/>
            <node TEXT="5. Confirm that the Gallery page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="6. Simulate a slow network and ensure the Gallery page content remains usable."/>
            <node TEXT="7. Test the Gallery page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency."/>
            <node TEXT="8. Verify that all gallery image links are not broken."/>
            <node TEXT="9. Check that the Contact and Inquiry Form is protected against spam submissions (e.g., CAPTCHA or rate limiting)."/>
            <node TEXT="10. Ensure that the Gallery page is indexed by search engines and appears in search results."/>
        </node>
    </node>
    <node TEXT="CONTACT US Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Verify that clicking the CONTACT US link in the header navigates to the Contact Us page."/>
            <node TEXT="2. Confirm that the Contact Information section displays office address, phone numbers, and email."/>
            <node TEXT="3. Ensure that the View on Map link opens the correct location in a new tab or map application."/>
            <node TEXT="4. Validate that the Call Us phone numbers are clickable and initiate a call on mobile devices."/>
            <node TEXT="5. Check that the Email Address is a mailto link and opens the default email client."/>
            <node TEXT="6. Ensure that the Contact Location Map is visible and displays the correct location."/>
            <node TEXT="7. Verify that the Get in Touch Form is present and all fields are visible."/>
            <node TEXT="8. Submit the Get in Touch Form with valid data and verify a success message is shown."/>
            <node TEXT="9. Confirm that the navigation menu remains functional after navigating to the Contact Us page."/>
            <node TEXT="10. Verify that the Contact Us page is accessible via direct URL entry."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempt to submit the Get in Touch Form with empty required fields and verify validation errors are shown."/>
            <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed."/>
            <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors."/>
            <node TEXT="4. Submit the form with an excessively long message and verify proper handling."/>
            <node TEXT="5. Try to access a non-existent map link and confirm a 404 or error page is shown."/>
            <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized."/>
            <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention."/>
            <node TEXT="8. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided."/>
            <node TEXT="9. Attempt to submit the form with a missing city selection and verify an error is displayed."/>
            <node TEXT="10. Try to upload a file in the message field (if not supported) and ensure the form rejects it."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Measure the load time of the Contact Us page to ensure it loads within 2 seconds on a standard connection."/>
            <node TEXT="2. Verify that the Contact Us page is responsive and displays correctly on mobile devices."/>
            <node TEXT="3. Check that all text and map elements on the Contact Us page are readable with sufficient color contrast."/>
            <node TEXT="4. Test the accessibility of the Contact Us page using a screen reader."/>
            <node TEXT="5. Confirm that the Contact Us page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="6. Simulate a slow network and ensure the Contact Us page content remains usable."/>
            <node TEXT="7. Test the Contact Us page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency."/>
            <node TEXT="8. Verify that all contact links (phone, email, map) are not broken."/>
            <node TEXT="9. Check that the Get in Touch Form is protected against spam submissions (e.g., CAPTCHA or rate limiting)."/>
            <node TEXT="10. Ensure that the Contact Us page is indexed by search engines and appears in search results."/>
        </node>
    </node>
    <node TEXT="home Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Verify that clicking the home link in the header navigates to the Home page."/>
            <node TEXT="2. Confirm that the Hero Section displays the correct background image, title, and subtitle."/>
            <node TEXT="3. Ensure that the Livestock Section is visible and displays all relevant information."/>
            <node TEXT="4. Validate that the Learn More buttons in each section navigate to the correct pages."/>
            <node TEXT="5. Check that the Benefits Section lists all benefits with correct descriptions."/>
            <node TEXT="6. Ensure that the Agriculture Section is present and displays all programs."/>
            <node TEXT="7. Verify that the Renewable Energy Section is visible and the Explore Our Sustainability button works."/>
            <node TEXT="8. Confirm that the Contact Section is present and the Contact Form is visible."/>
            <node TEXT="9. Submit the Contact Form with valid data and verify a success message is shown."/>
            <node TEXT="10. Verify that the navigation menu remains functional after navigating to the Home page."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempt to submit the Contact Form with empty required fields and verify validation errors are shown."/>
            <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed."/>
            <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors."/>
            <node TEXT="4. Submit the form with an excessively long message and verify proper handling."/>
            <node TEXT="5. Try to access a non-existent section link and confirm a 404 or error page is shown."/>
            <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized."/>
            <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention."/>
            <node TEXT="8. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided."/>
            <node TEXT="9. Attempt to submit the form with a missing city selection and verify an error is displayed."/>
            <node TEXT="10. Try to upload a file in the message field (if not supported) and ensure the form rejects it."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Measure the load time of the Home page to ensure it loads within 2 seconds on a standard connection."/>
            <node TEXT="2. Verify that the Home page is responsive and displays correctly on mobile devices."/>
            <node TEXT="3. Check that all text and images on the Home page are readable with sufficient color contrast."/>
            <node TEXT="4. Test the accessibility of the Home page using a screen reader."/>
            <node TEXT="5. Confirm that the Home page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="6. Simulate a slow network and ensure the Home page content remains usable."/>
            <node TEXT="7. Test the Home page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency."/>
            <node TEXT="8. Verify that all section links and buttons are not broken."/>
            <node TEXT="9. Check that the Contact Form is protected against spam submissions (e.g., CAPTCHA or rate limiting)."/>
            <node TEXT="10. Ensure that the Home page is indexed by search engines and appears in search results."/>
        </node>
    </node>
</node>
</map>