<?xml version='1.0' encoding='UTF-8'?>
<map version="1.0.1">
  <node TEXT="Dayzee" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Logo" FOLDED="true">
        <node TEXT="DayZee" LINK="https://dayzee.com/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Navigation" FOLDED="true">
        <node TEXT="About Us" LINK="https://dayzee.com/about/" FOLDED="true">
          <node TEXT="Introduction   Vision" FOLDED="true">
            <node TEXT="DayZee Farms Began with a Bold Idea" FOLDED="true"/>
            <node TEXT="Genetics was just the start" FOLDED="true"/>
          </node>
          <node TEXT="Key Achievements   Initiatives" FOLDED="true">
            <node TEXT="We launched DayZee Livestock" FOLDED="true"/>
            <node TEXT="DayZee Agriculture" FOLDED="true"/>
            <node TEXT="Solar installation" FOLDED="true"/>
            <node TEXT="Intersection of science and soil" FOLDED="true"/>
          </node>
          <node TEXT="UN Sustainable Development Goals Impact" FOLDED="true">
            <node TEXT="SDG 2 – Zero Hunger" FOLDED="true"/>
            <node TEXT="SDG 7 – Affordable and Clean Energy" FOLDED="true"/>
            <node TEXT="SDG 9 – Industry, Innovation and Infrastructure" FOLDED="true"/>
            <node TEXT="SDG 12 – Responsible Consumption and Production" FOLDED="true"/>
            <node TEXT="SDG 13 – Climate Action" FOLDED="true"/>
          </node>
          <node TEXT="Contact   Inquiry Form" FOLDED="true">
            <node TEXT="First Name" FOLDED="true"/>
            <node TEXT="Last Name" FOLDED="true"/>
            <node TEXT="Email" FOLDED="true"/>
            <node TEXT="Mobile Number" FOLDED="true"/>
            <node TEXT="Company Name" FOLDED="true"/>
            <node TEXT="Country" FOLDED="true"/>
            <node TEXT="Interested In" FOLDED="true"/>
            <node TEXT="Message" FOLDED="true"/>
            <node TEXT="SUBMIT" FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Livestock" LINK="https://dayzee.com/live-stock/" FOLDED="true">
          <node TEXT="Superior Genetics For Tomorrow" FOLDED="true">
            <node TEXT="Request Semen/Embryo" FOLDED="true">
              <node TEXT="tel:+923314476666" FOLDED="true"/>
            </node>
            <node TEXT="Book a Consultation" FOLDED="true">
              <node TEXT="tel:+923314431111" FOLDED="true"/>
            </node>
            <node TEXT="Book OPU of your cow now" FOLDED="true">
              <node TEXT="tel:+923314431111" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="About Our Genetics" FOLDED="true">
            <node TEXT="Slick Gene Frisien - Special Heat-Resistant, 40+ L Milk" FOLDED="true"/>
            <node TEXT="Brahman - 300+ kg at 7 Months, Beef   Bragging Rights!" FOLDED="true"/>
            <node TEXT="Beefmaster - Fertility, Gain   Premium Production" FOLDED="true"/>
            <node TEXT="Red Angus - Fertility, Calving   Premium Beef" FOLDED="true"/>
          </node>
          <node TEXT="Our Services" FOLDED="true">
            <node TEXT="Semen Availability - Climate-adapted, top performing bulls" FOLDED="true"/>
            <node TEXT="Embryo Transfer Pregnancies - Elite embryos for local recipients" FOLDED="true"/>
            <node TEXT="Pregnant Heifers for Sale - Health certified   pregnancy-verified" FOLDED="true"/>
            <node TEXT="Genetics Consultation - Sire selection to embryo strategy" FOLDED="true"/>
          </node>
          <node TEXT="Elite Calves Promotion" FOLDED="true">
            <node TEXT="Want 20+ calves from one elite donor cow?" FOLDED="true"/>
            <node TEXT="Book OPU Now" FOLDED="true">
              <node TEXT="tel:+92314431111" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Explore Our Genetic Catalogue" FOLDED="true">
            <node TEXT="Brahman Catalogue" FOLDED="true">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_American-Brahmans.pdf.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Slick-Gene Friesian Catalogue" FOLDED="true">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Slick-Gene.pdf.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Beefmaster Catalogue" FOLDED="true">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Beef-Master.pdf.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Red Angus Catalogue" FOLDED="true">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Red-Angus.pdf.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Our Global Partners" FOLDED="true"/>
          <node TEXT="Get in Touch - Let’s Get Started" FOLDED="true">
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="First Name" FOLDED="true"/>
              <node TEXT="Last Name" FOLDED="true"/>
              <node TEXT="Email" FOLDED="true"/>
              <node TEXT="Mobile Number" FOLDED="true"/>
              <node TEXT="Company Name" FOLDED="true"/>
              <node TEXT="City (dropdown)" FOLDED="true"/>
              <node TEXT="Country" FOLDED="true"/>
              <node TEXT="Interested In" FOLDED="true"/>
              <node TEXT="Message" FOLDED="true"/>
              <node TEXT="Submit" FOLDED="true"/>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Agriculture" LINK="https://dayzee.com/agriculture/" FOLDED="true">
          <node TEXT="Intro: 4,200 Acres Sustainable Agricultural Hub" FOLDED="true"/>
          <node TEXT="A New Era of Desert Farming" FOLDED="true">
            <node TEXT="Desert transformation and innovation summary" FOLDED="true"/>
          </node>
          <node TEXT="Barren Land Visual Timeline" FOLDED="true">
            <node TEXT="April-2024, March-2025, May-2025 photos" FOLDED="true"/>
          </node>
          <node TEXT="Technology In Agriculture" FOLDED="true">
            <node TEXT="Irrigation Systems: Central Pivot technology overview" FOLDED="true"/>
            <node TEXT="Mechanized Farm Machinery: Modern equipment" FOLDED="true"/>
            <node TEXT="Solar Power Plant: 6MW Solar installation" FOLDED="true"/>
          </node>
          <node TEXT="Our Products" FOLDED="true">
            <node TEXT="Alfalfa: Forage crop for dairy and beef cattle" FOLDED="true"/>
            <node TEXT="Rhodes Grass: Drought-resistant grass for livestock" FOLDED="true"/>
          </node>
          <node TEXT="Our Services" FOLDED="true">
            <node TEXT="Land Development: Transforming barren land" FOLDED="true"/>
            <node TEXT="Center Pivot Irrigation Systems: Full service and maintenance" FOLDED="true"/>
            <node TEXT="Farm Operations: Precision crop cycle operations" FOLDED="true"/>
            <node TEXT="Integrated Farm Management: Planning and execution" FOLDED="true"/>
            <node TEXT="Irrigation   Infrastructure Consultancy: Expert solutions" FOLDED="true"/>
          </node>
          <node TEXT="Our Global Partners" FOLDED="true">
            <node TEXT="Logos of international agricultural partners" FOLDED="true"/>
          </node>
          <node TEXT="Get in touch Let’s Get Started" FOLDED="true">
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="First Name*" FOLDED="true"/>
              <node TEXT="Last Name*" FOLDED="true"/>
              <node TEXT="Email*" FOLDED="true"/>
              <node TEXT="Mobile Number*" FOLDED="true"/>
              <node TEXT="Company Name" FOLDED="true"/>
              <node TEXT="Country" FOLDED="true"/>
              <node TEXT="Interested In" FOLDED="true"/>
              <node TEXT="Message" FOLDED="true"/>
              <node TEXT="SUBMIT" FOLDED="true"/>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Renewable Energy" LINK="https://dayzee.com/renewable-energy/" FOLDED="true">
          <node TEXT="Hero Section" FOLDED="true">
            <node TEXT="Reducing Carbon Emissions Today – Building A 100% Clean Energy Future" FOLDED="true"/>
          </node>
          <node TEXT="Solar Panel Infrastructure" FOLDED="true">
            <node TEXT="Summary: 6MW solar panel system for efficient and sustainable farm energy." FOLDED="true"/>
          </node>
          <node TEXT="Our Biogas Plant" FOLDED="true">
            <node TEXT="Summary: Converts organic farm waste to biogas for energy and waste reduction." FOLDED="true"/>
          </node>
          <node TEXT="Key Stats" FOLDED="true">
            <node TEXT="500 Delivered Packages" FOLDED="true"/>
            <node TEXT="500 Global Shipping" FOLDED="true"/>
            <node TEXT="500 Air Freight" FOLDED="true"/>
            <node TEXT="500 Happy Customers" FOLDED="true"/>
          </node>
          <node TEXT="Corporate Social Responsibility (CSR)" FOLDED="true">
            <node TEXT="Empowering Rural Communities - 150+ jobs created, livelihoods uplifted" FOLDED="true"/>
            <node TEXT="Farmer Development - Awareness sessions for modern farming" FOLDED="true"/>
            <node TEXT="Environmental Stewardship - Solar and biogas projects for sustainability" FOLDED="true"/>
            <node TEXT="Animal Ethics   Welfare - Focus on care, nutrition, ethical practices" FOLDED="true"/>
          </node>
          <node TEXT="Get in touch – Let’s Get Started" FOLDED="true">
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="First Name*" FOLDED="true"/>
              <node TEXT="Last Name*" FOLDED="true"/>
              <node TEXT="Email*" FOLDED="true"/>
              <node TEXT="Mobile Number*" FOLDED="true"/>
              <node TEXT="Company Name" FOLDED="true"/>
              <node TEXT="Location (Dropdown: Karachi)" FOLDED="true"/>
              <node TEXT="Country" FOLDED="true"/>
              <node TEXT="Interested In" FOLDED="true"/>
              <node TEXT="Message" FOLDED="true"/>
              <node TEXT="Submit" FOLDED="true"/>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" FOLDED="true">
          <node TEXT="Image Gallery Section" FOLDED="true">
            <node TEXT="Featured Event: DayZee at International Livestock, Dairy, Poultry and Agri Expo 2025" FOLDED="true">
              <node TEXT="Gallery Link" LINK="https://dayzee.com/gallery/dayzee-at-ildpa2025/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery_dayzee-at-ildpa2025.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Featured Visit: Chinese Delegation at DayZee (Private) Limited" FOLDED="true">
              <node TEXT="Gallery Link" LINK="https://dayzee.com/gallery/chinese-delegation/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery_chinese-delegation.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Get In Touch Section" FOLDED="true">
            <node TEXT="Contact and Inquiry Form" FOLDED="true">
              <node TEXT="First Name*" FOLDED="true"/>
              <node TEXT="Last Name*" FOLDED="true"/>
              <node TEXT="Email*" FOLDED="true"/>
              <node TEXT="Mobile Number*" FOLDED="true"/>
              <node TEXT="Company Name" FOLDED="true"/>
              <node TEXT="City Dropdown (e.g. Karachi)" FOLDED="true"/>
              <node TEXT="Country" FOLDED="true"/>
              <node TEXT="Interested In" FOLDED="true"/>
              <node TEXT="Message" FOLDED="true"/>
              <node TEXT="SUBMIT button" FOLDED="true"/>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" FOLDED="true">
          <node TEXT="Contact Information" FOLDED="true">
            <node TEXT="Our Office" FOLDED="true">
              <node TEXT="DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur." FOLDED="true">
                <node TEXT="View on Map" FOLDED="true">
                  <node TEXT="https://maps.app.goo.gl/WstmNjesSmVKyyB66" LINK="https://maps.app.goo.gl/WstmNjesSmVKyyB66" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_WstmNjesSmVKyyB66.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                </node>
              </node>
            </node>
            <node TEXT="Call Us" FOLDED="true">
              <node TEXT="0331-443 1111" FOLDED="true">
                <node TEXT="tel:0331 443 1111" FOLDED="true"/>
              </node>
              <node TEXT="0331-447 6666" FOLDED="true">
                <node TEXT="tel:0331 447 66 66" FOLDED="true"/>
              </node>
            </node>
            <node TEXT="Email Address" FOLDED="true">
              <node TEXT="info@dayzee.com" FOLDED="true">
                <node TEXT="mailto:info@dayzee.com" LINK="mailto:info@dayzee.com" FOLDED="true"/>
              </node>
            </node>
          </node>
          <node TEXT="Contact Location Map" FOLDED="true">
            <node TEXT="Embedded map showing DayZee Farms location" FOLDED="true"/>
          </node>
          <node TEXT="Get in Touch Form" FOLDED="true">
            <node TEXT="First Name (input)" FOLDED="true"/>
            <node TEXT="Last Name (input)" FOLDED="true"/>
            <node TEXT="Email (input)" FOLDED="true"/>
            <node TEXT="Mobile Number (input)" FOLDED="true"/>
            <node TEXT="Company Name (input)" FOLDED="true"/>
            <node TEXT="City (dropdown)" FOLDED="true"/>
            <node TEXT="Country (input)" FOLDED="true"/>
            <node TEXT="Interested In (input)" FOLDED="true"/>
            <node TEXT="Message (textarea)" FOLDED="true"/>
            <node TEXT="Submit Button" FOLDED="true">
              <node TEXT="SUBMIT" FOLDED="true"/>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Skip to content" LINK="https://dayzee.com/#content" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_content.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Home Page" FOLDED="true">
      <node TEXT="Hero Section" FOLDED="true">
        <node TEXT="Background Image" FOLDED="true"/>
        <node TEXT="Title: AGRICULTURE" FOLDED="true"/>
        <node TEXT="Subtitle: Innovating Modern Farming" FOLDED="true"/>
      </node>
      <node TEXT="Livestock Section" FOLDED="true">
        <node TEXT="Title: LIVESTOCK" FOLDED="true"/>
        <node TEXT="Subtitle: In Elite Genetics for Unmatched Livestock Performance" FOLDED="true"/>
        <node TEXT="Description" FOLDED="true"/>
        <node TEXT="Learn More Button" LINK="https://dayzee.com/live-stock/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Programs" FOLDED="true">
          <node TEXT="Invitro Fertilization Program" FOLDED="true"/>
          <node TEXT="Artificial Insemination Program" FOLDED="true"/>
          <node TEXT="Genetics Lab" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="Benefits Section" FOLDED="true">
        <node TEXT="Heat Tolerance" FOLDED="true"/>
        <node TEXT="Fertility   Productivity" FOLDED="true"/>
        <node TEXT="Long-Term Profitability" FOLDED="true"/>
      </node>
      <node TEXT="Agriculture Section" FOLDED="true">
        <node TEXT="Title: Agriculture" FOLDED="true"/>
        <node TEXT="Subtitle: Turning Barren Land into Agricultural Gold" FOLDED="true"/>
        <node TEXT="Description" FOLDED="true"/>
        <node TEXT="Learn More Button" LINK="https://dayzee.com/agriculture/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Programs" FOLDED="true">
          <node TEXT="Pivot Irrigation" FOLDED="true"/>
          <node TEXT="Mechanized Farming" FOLDED="true"/>
          <node TEXT="Premium Animal Fodder" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="Renewable Energy Section" FOLDED="true">
        <node TEXT="Title: Renewable Energy" FOLDED="true"/>
        <node TEXT="Subtitle: Sustainable and Smart Agriculture" FOLDED="true"/>
        <node TEXT="Explore Our Sustainability Button" LINK="https://dayzee.com/renewable-energy/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Programs" FOLDED="true">
          <node TEXT="Solar Powered Future" FOLDED="true"/>
          <node TEXT="Biogas To Energy" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="Contact Section" FOLDED="true">
        <node TEXT="Get in touch Let’s Get Started" FOLDED="true"/>
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="First Name*" FOLDED="true"/>
          <node TEXT="Last Name*" FOLDED="true"/>
          <node TEXT="Email*" FOLDED="true"/>
          <node TEXT="Mobile Number*" FOLDED="true"/>
          <node TEXT="Company Name" FOLDED="true"/>
          <node TEXT="City (Dropdown, e.g., Karachi)" FOLDED="true"/>
          <node TEXT="Country" FOLDED="true"/>
          <node TEXT="Interested In" FOLDED="true"/>
          <node TEXT="Message" FOLDED="true"/>
          <node TEXT="Submit Button" FOLDED="true"/>
        </node>
      </node>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="About Company" FOLDED="true">
        <node TEXT="Company Description" FOLDED="true"/>
      </node>
      <node TEXT="Company Links" FOLDED="true">
        <node TEXT="Home" LINK="https://dayzee.com/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Services" LINK="https://dayzee.com/service/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_service.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Quick Links" FOLDED="true">
        <node TEXT="About Us" LINK="https://dayzee.com/about/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="FAQs" LINK="https://dayzee.com/faqs" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_dayzee.com_faqs.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Follow us at" FOLDED="true">
        <node TEXT="Facebook" LINK="https://www.facebook.com/dayzeepvtltd" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.facebook.com_dayzeepvtltd.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Tik Tok" LINK="https://www.tiktok.com/@dayzee.pvt.ltd" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.tiktok.com_dayzee.pvt.ltd.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Instagram" LINK="https://www.instagram.com/dayzee_pvt_ltd/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.instagram.com_dayzee_pvt_ltd.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Youtube" LINK="https://www.youtube.com/@DayZee_Pvt_Ltd" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.youtube.com_DayZee_Pvt_Ltd.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Copyright" FOLDED="true">
        <node TEXT="Copyright © 2025 DayZee. All Rights Reserved" FOLDED="true"/>
      </node>
    </node>
  </node>
</map>
