<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="agriculture">
    <node TEXT="Hero Section">
      <node TEXT="Transforming 4,200 Barren Acres Into An Agricultural Hub" />
    </node>
    <node TEXT="A New Era of Desert Farming">
      <node TEXT="Timeline: April-2024, March-2025, May-2025" />
      <node TEXT="Desert innovation: Sustainable livestock and fodder production" />
    </node>
    <node TEXT="Barren Land Visual" />
    <node TEXT="Technology In Agriculture">
      <node TEXT="Irrigation Systems: 10 pivot systems operating, 17 more planned" />
      <node TEXT="Mechanized Farm Machinery: State-of-the-art technology" />
      <node TEXT="Solar Power Plant: 6MW plant powering farm" />
    </node>
    <node TEXT="Our Products">
      <node TEXT="Alfalfa: Forage crop for dairy and beef cattle" />
      <node TEXT="Rhodes Grass: Drought-resistant, nutritious grass for livestock" />
    </node>
    <node TEXT="Our Services">
      <node TEXT="Land Development: Transforming land for agriculture" />
      <node TEXT="Center Pivot Irrigation Systems: Full design and maintenance services" />
      <node TEXT="Farm Operations: Complete crop cycle and management" />
      <node TEXT="Integrated Farm Management: Full-spectrum services" />
      <node TEXT="Irrigation   Infrastructure Consultancy: Large-scale and solar-powered solutions" />
    </node>
    <node TEXT="Our Global Partners">
      <node TEXT="Livestock Science Backing by Global Leaders" />
    </node>
    <node TEXT="Get in touch Let’s Get Started">
      <node TEXT="Contact Form">
        <node TEXT="First Name" />
        <node TEXT="Last Name" />
        <node TEXT="Email" />
        <node TEXT="Mobile Number" />
        <node TEXT="Company Name" />
        <node TEXT="Country" />
        <node TEXT="Interested In" />
        <node TEXT="Message" />
        <node TEXT="SUBMIT" />
      </node>
    </node>
  </node>
</map>