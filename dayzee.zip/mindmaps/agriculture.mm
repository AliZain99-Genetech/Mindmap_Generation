<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="agriculture">
    <node TEXT="Hero Section: Transforming 4,200 Acres Into Sustainable Agricultural Hub" />
    <node TEXT="A New Era of Desert Farming">
      <node TEXT="Timeline   Images: Land Development Progress" />
      <node TEXT="Innovative desert farming with irrigation and high-protein crops" />
    </node>
    <node TEXT="Technology In Agriculture">
      <node TEXT="Irrigation Systems: 10 systems running, 17 to be installed" />
      <node TEXT="Mechanized Farm Machinery: State-of-the-art equipment" />
      <node TEXT="Solar Power Plant: 6MW for farm operations" />
    </node>
    <node TEXT="Our Products">
      <node TEXT="Alfalfa: High-nutrition forage for dairy and beef cattle" />
      <node TEXT="Rhodes Grass: Digestible, drought-resistant livestock grass" />
    </node>
    <node TEXT="Our Services">
      <node TEXT="Land Development: Transforming underutilized land" />
      <node TEXT="Center Pivot Irrigation Systems: Design and maintenance" />
      <node TEXT="Farm Operations: Machinery and skilled workforce" />
      <node TEXT="Integrated Farm Management: Full-spectrum planning and monitoring" />
      <node TEXT="Irrigation   Infrastructure Consultancy: Precision water and solar solutions" />
    </node>
    <node TEXT="Our Global Partners">
      <node TEXT="Partners: Global leaders in livestock science and breeding" />
    </node>
    <node TEXT="Get in touch – Let's Get Started (Form)">
      <node TEXT="First Name" />
      <node TEXT="Last Name" />
      <node TEXT="Email" />
      <node TEXT="Mobile Number" />
      <node TEXT="Company Name" />
      <node TEXT="Country" />
      <node TEXT="Interested In" />
      <node TEXT="Message" />
      <node TEXT="SUBMIT (Button)" />
    </node>
    <node TEXT="Relevant Links">
      <node TEXT="Read more" LINK="https://dayzee.com/textipsum-is-simply-dummy-text-of-the-printing-and-typesetting-industry/" />
    </node>
  </node>
</map>