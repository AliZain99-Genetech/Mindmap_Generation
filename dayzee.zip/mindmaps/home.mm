<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Dayzee">
    <node TEXT="Header">
      <node TEXT="Logo">
        <node TEXT="DayZee" LINK="https://dayzee.com/" />
      </node>
      <node TEXT="Navigation Links">
        <node TEXT="About Us" LINK="https://dayzee.com/about/" />
        <node TEXT="Livestock" LINK="https://dayzee.com/live-stock/" />
        <node TEXT="Agriculture" LINK="https://dayzee.com/agriculture/" />
        <node TEXT="Renewable Energy" LINK="https://dayzee.com/renewable-energy/" />
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" />
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" />
      </node>
      <node TEXT="Skip to content" LINK="https://dayzee.com/#content" />
    </node>
    <node TEXT="Home Page">
      <node TEXT="Hero Section">
        <node TEXT="Image: Livestock background" />
        <node TEXT="Title: EMBRYO   SEMEN PRODUCTION UNITS" />
        <node TEXT="Subtitle: Revolutionizing Livestock Genetics" />
      </node>
      <node TEXT="Livestock Section">
        <node TEXT="Section Title: LIVESTOCK" />
        <node TEXT="Section Subtitle: In Elite Genetics for Unmatched Livestock Performance" />
        <node TEXT="Description" />
        <node TEXT="Learn More Button" LINK="https://dayzee.com/live-stock/" />
        <node TEXT="Programs">
          <node TEXT="Invitro Fertilization Program">
            <node TEXT="Image: IVF Lab" />
            <node TEXT="Description" />
          </node>
          <node TEXT="Artificial Insemination Program">
            <node TEXT="Image: AI Program" />
            <node TEXT="Description" />
          </node>
          <node TEXT="Genetics Lab">
            <node TEXT="Image: Genetics Lab" />
            <node TEXT="Description" />
          </node>
        </node>
      </node>
      <node TEXT="Benefits">
        <node TEXT="Heat Tolerance">
          <node TEXT="Perfect for Pakistan’s climate" />
        </node>
        <node TEXT="Fertility   Productivity">
          <node TEXT="Maximize your herd’s potential" />
        </node>
        <node TEXT="Long-Term Profitability">
          <node TEXT="Higher quality offspring with market-leading traits" />
        </node>
      </node>
      <node TEXT="Agriculture Section">
        <node TEXT="Section Title: Agriculture" />
        <node TEXT="Section Subtitle: Turning Barren Land into Agricultural Gold" />
        <node TEXT="Description" />
        <node TEXT="Learn More Button" LINK="https://dayzee.com/agriculture/" />
        <node TEXT="Programs">
          <node TEXT="Pivot Irrigation">
            <node TEXT="Image: Pivot Irrigation" />
            <node TEXT="Description" />
          </node>
          <node TEXT="Mechanized Farming">
            <node TEXT="Image: Mechanized Farming" />
            <node TEXT="Description" />
          </node>
          <node TEXT="Premium Animal Fodder">
            <node TEXT="Image: Animal Fodder" />
            <node TEXT="Description" />
          </node>
        </node>
      </node>
      <node TEXT="Renewable Energy Section">
        <node TEXT="Section Title: Renewable Energy" />
        <node TEXT="Section Subtitle: Sustainable and Smart Agriculture" />
        <node TEXT="Explore Our Sustainability Button" LINK="https://dayzee.com/renewable-energy/" />
        <node TEXT="Programs">
          <node TEXT="Solar Powered Future">
            <node TEXT="Image: Solar Power" />
            <node TEXT="6.6 MW Clean Energy" />
            <node TEXT="Description" />
          </node>
          <node TEXT="Biogas To Energy">
            <node TEXT="Image: Biogas" />
            <node TEXT="2.2 MW from Organic Waste" />
            <node TEXT="Description" />
          </node>
        </node>
      </node>
      <node TEXT="Contact Section">
        <node TEXT="Get in touch Let’s Get Started" />
        <node TEXT="Contact Form">
          <node TEXT="First Name*" />
          <node TEXT="Last Name*" />
          <node TEXT="Email*" />
          <node TEXT="Mobile Number*" />
          <node TEXT="Company Name" />
          <node TEXT="City (Dropdown: Karachi)" />
          <node TEXT="Country" />
          <node TEXT="Interested In" />
          <node TEXT="Message" />
          <node TEXT="Submit Button" />
        </node>
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Company Description" />
      <node TEXT="Company Links">
        <node TEXT="Home" LINK="https://dayzee.com/" />
        <node TEXT="Services" LINK="https://dayzee.com/service/" />
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" />
      </node>
      <node TEXT="Quick Links">
        <node TEXT="About Us" LINK="https://dayzee.com/about/" />
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" />
        <node TEXT="FAQs" LINK="https://dayzee.com/faqs" />
      </node>
      <node TEXT="Social Media">
        <node TEXT="Facebook" LINK="https://www.facebook.com/dayzeepvtltd" />
        <node TEXT="Tik Tok" LINK="https://www.tiktok.com/@dayzee.pvt.ltd" />
        <node TEXT="Instagram" LINK="https://www.instagram.com/dayzee_pvt_ltd/" />
        <node TEXT="Youtube" LINK="https://www.youtube.com/@DayZee_Pvt_Ltd" />
      </node>
      <node TEXT="Copyright © 2025 DayZee. All Rights Reserved" />
    </node>
  </node>
</map>