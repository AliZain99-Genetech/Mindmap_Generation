<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="gallery">
    <node TEXT="Image Gallery Section">
      <node TEXT="Featured Event: DayZee at International Livestock, Dairy, Poultry and Agri Expo 2025">
        <node TEXT="Gallery Link" LINK="https://dayzee.com/gallery/dayzee-at-ildpa2025/" />
      </node>
      <node TEXT="Featured Visit: Chinese Delegation at DayZee (Private) Limited">
        <node TEXT="Gallery Link" LINK="https://dayzee.com/gallery/chinese-delegation/" />
      </node>
    </node>
    <node TEXT="Get In Touch Section">
      <node TEXT="Contact and Inquiry Form">
        <node TEXT="First Name*" />
        <node TEXT="Last Name*" />
        <node TEXT="Email*" />
        <node TEXT="Mobile Number*" />
        <node TEXT="Company Name" />
        <node TEXT="City Dropdown (e.g. Karachi)" />
        <node TEXT="Country" />
        <node TEXT="Interested In" />
        <node TEXT="Message" />
        <node TEXT="SUBMIT button" />
      </node>
    </node>
  </node>
</map>