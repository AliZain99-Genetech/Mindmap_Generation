<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="livestock">
    <node TEXT="Superior Genetics for Tomorrow">
      <node TEXT="REQUEST SEMEN/EMBRYO">
        <node TEXT="Request Semen/Embryo" LINK="tel:+923314476666" />
      </node>
      <node TEXT="BOOK A CONSULTATION">
        <node TEXT="Book a Consultation" LINK="tel:+923314431111" />
      </node>
      <node TEXT="BOOK OPU OF YOUR COW NOW">
        <node TEXT="Book OPU of your cow now" LINK="tel:+923314431111" />
      </node>
    </node>
    <node TEXT="About Our Genetics">
      <node TEXT="Slick Gene Frisien - Imported Friesian, high milk yield, heat resistant" />
      <node TEXT="Brahman - Imported JDH line, beef breed" />
      <node TEXT="Beefmaster - Fertility, rapid weight gain, quality beef" />
      <node TEXT="Red Angus - High fertility, premium beef quality" />
    </node>
    <node TEXT="Our Services">
      <node TEXT="Semen Availability - High-performing, climate-adapted bulls" />
      <node TEXT="Embryo Transfer Pregnancies - IVF elite embryos for recipient cows" />
      <node TEXT="Pregnant Heifers for Sale - Elite embryo transfers, verified heifers" />
      <node TEXT="Genetics Consultation - Strategy for selecting right farm genetics" />
    </node>
    <node TEXT="OPU Session Promotion">
      <node TEXT="Want 20+ calves from one elite donor cow?" />
      <node TEXT="Book OPU Now">
        <node TEXT="Book OPU Now" LINK="tel:+92314431111" />
      </node>
    </node>
    <node TEXT="Explore Our Genetic Catalogue">
      <node TEXT="Brahman Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" />
      <node TEXT="Slick-Gene Friesian Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" />
      <node TEXT="Beefmaster Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" />
      <node TEXT="Red Angus Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" />
    </node>
    <node TEXT="Our Global Partners">
      <node TEXT="World leaders in livestock genetics and breeding" />
    </node>
    <node TEXT="Get in touch - Contact Form">
      <node TEXT="First Name" />
      <node TEXT="Last Name" />
      <node TEXT="Email" />
      <node TEXT="Mobile Number" />
      <node TEXT="Company Name" />
      <node TEXT="Country" />
      <node TEXT="Interested In" />
      <node TEXT="Message" />
      <node TEXT="SUBMIT" />
    </node>
  </node>
</map>