<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="livestock">
    <node TEXT="Superior Genetics For Tomorrow">
      <node TEXT="Request Semen/Embryo">
        <node TEXT="tel:+923314476666" />
      </node>
      <node TEXT="Book a Consultation">
        <node TEXT="tel:+923314431111" />
      </node>
      <node TEXT="Book OPU of your cow now">
        <node TEXT="tel:+923314431111" />
      </node>
    </node>
    <node TEXT="About Our Genetics">
      <node TEXT="Slick Gene Frisien - Special Heat-Resistant, 40+ L Milk" />
      <node TEXT="Brahman - 300+ kg at 7 Months, Beef   Bragging Rights!" />
      <node TEXT="Beefmaster - Fertility, Gain   Premium Production" />
      <node TEXT="Red Angus - Fertility, Calving   Premium Beef" />
    </node>
    <node TEXT="Our Services">
      <node TEXT="Semen Availability - Climate-adapted, top performing bulls" />
      <node TEXT="Embryo Transfer Pregnancies - Elite embryos for local recipients" />
      <node TEXT="Pregnant Heifers for Sale - Health certified   pregnancy-verified" />
      <node TEXT="Genetics Consultation - Sire selection to embryo strategy" />
    </node>
    <node TEXT="Elite Calves Promotion">
      <node TEXT="Want 20+ calves from one elite donor cow?" />
      <node TEXT="Book OPU Now">
        <node TEXT="tel:+92314431111" />
      </node>
    </node>
    <node TEXT="Explore Our Genetic Catalogue">
      <node TEXT="Brahman Catalogue">
        <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" />
      </node>
      <node TEXT="Slick-Gene Friesian Catalogue">
        <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" />
      </node>
      <node TEXT="Beefmaster Catalogue">
        <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" />
      </node>
      <node TEXT="Red Angus Catalogue">
        <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" />
      </node>
    </node>
    <node TEXT="Our Global Partners" />
    <node TEXT="Get in Touch - Let #39;s Get Started">
      <node TEXT="Contact Form">
        <node TEXT="First Name" />
        <node TEXT="Last Name" />
        <node TEXT="Email" />
        <node TEXT="Mobile Number" />
        <node TEXT="Company Name" />
        <node TEXT="City (dropdown)" />
        <node TEXT="Country" />
        <node TEXT="Interested In" />
        <node TEXT="Message" />
        <node TEXT="Submit" />
      </node>
    </node>
  </node>
</map>