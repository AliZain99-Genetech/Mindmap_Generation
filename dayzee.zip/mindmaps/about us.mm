<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="about us">
    <node TEXT="DayZee Farms Began with a Bold Idea">
      <node TEXT="Genetics was just the start - global expertise and local innovation" />
      <node TEXT="We launched DayZee Livestock" />
      <node TEXT="DayZee Agriculture" />
      <node TEXT="Solar installation" />
      <node TEXT="Intersection of science and soil" />
    </node>
    <node TEXT="Impact on the UN Sustainable Development Goals (SDGs)">
      <node TEXT="SDG 2 – Zero Hunger" />
      <node TEXT="SDG 7 – Affordable and Clean Energy" />
      <node TEXT="SDG 9 – Industry, Innovation and Infrastructure" />
      <node TEXT="SDG 12 – Responsible Consumption and Production" />
      <node TEXT="SDG 13 – Climate Action" />
    </node>
    <node TEXT="Get in touch – Let’s Get Started">
      <node TEXT="Contact form">
        <node TEXT="First Name" />
        <node TEXT="Last Name" />
        <node TEXT="Email" />
        <node TEXT="Mobile Number" />
        <node TEXT="Company Name" />
        <node TEXT="City" />
        <node TEXT="Country" />
        <node TEXT="Interested In" />
        <node TEXT="Message" />
        <node TEXT="Submit" />
      </node>
    </node>
    <node TEXT="About DayZee summary">
      <node TEXT="Elite livestock genetics, sustainable farming   turnkey solutions" />
    </node>
  </node>
</map>