<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="about us">
    <node TEXT="DayZee Farms Began with a Bold Idea">
      <node TEXT="Overview">What if one project could contribute to the future of farming in Pakistan?</node>
      <node TEXT="Major Initiatives">
        <node TEXT="We launched DayZee Livestock">Elite genetics, IVF Lab, progressive dairy and beef solutions.</node>
        <node TEXT="DayZee Agriculture">Reclaiming land, modern irrigation, premium fodder.</node>
        <node TEXT="Solar installation">6MW solar power for farming sustainability.</node>
        <node TEXT="Intersection of science and soil">World-class solutions with a local heart.</node>
      </node>
    </node>
    <node TEXT="Our Impact on the UN Sustainable Development Goals">
      <node TEXT="SDG 2 – Zero Hunger">Improve livestock and crop yields for food supply.</node>
      <node TEXT="SDG 7 – Affordable and Clean Energy">Renewable energy powers sustainable farming.</node>
      <node TEXT="SDG 9 – Industry, Innovation and Infrastructure">Modern agricultural infrastructure through innovation.</node>
      <node TEXT="SDG 12 – Responsible Consumption and Production">Promote sustainable use and resource efficiency.</node>
      <node TEXT="SDG 13 – Climate Action">Climate-resilient farming and carbon footprint reduction.</node>
    </node>
    <node TEXT="Get in touch – Let’s Get Started">
      <node TEXT="Contact Form">
        <node TEXT="First Name" />
        <node TEXT="Last Name" />
        <node TEXT="Email" />
        <node TEXT="Mobile Number" />
        <node TEXT="Company Name" />
        <node TEXT="Country" />
        <node TEXT="Interested In" />
        <node TEXT="Message" />
        <node TEXT="SUBMIT" />
      </node>
    </node>
  </node>
</map>