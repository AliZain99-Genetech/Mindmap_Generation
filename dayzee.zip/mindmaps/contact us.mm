<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="contact us">
    <node TEXT="Contact Information">
      <node TEXT="Our Office">
        <node TEXT="DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur.">
          <node TEXT="Location on Google Maps" LINK="https://maps.app.goo.gl/WstmNjesSmVKyyB66" />
        </node>
      </node>
      <node TEXT="Call Us">
        <node TEXT="0331-443 1111" LINK="tel:0331 443 1111" />
        <node TEXT="0331-447 6666" LINK="tel:0331 447 66 66" />
      </node>
      <node TEXT="Email Address">
        <node TEXT="info@dayzee.com" LINK="mailto:info@dayzee.com" />
      </node>
    </node>
    <node TEXT="Get in touch form">
      <node TEXT="First Name" />
      <node TEXT="Last Name" />
      <node TEXT="Email" />
      <node TEXT="Mobile Number" />
      <node TEXT="Company Name" />
      <node TEXT="City (Dropdown, default: Karachi)" />
      <node TEXT="Country" />
      <node TEXT="Interested In" />
      <node TEXT="Message" />
      <node TEXT="SUBMIT button" />
    </node>
  </node>
</map>