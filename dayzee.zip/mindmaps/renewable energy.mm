<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="renewable energy">
    <node TEXT="Page Banner">
      <node TEXT="Reducing Carbon Emissions Today – Building A 100% Clean Energy Future" />
    </node>
    <node TEXT="Solar Panel Infrastructure">
      <node TEXT="6MW solar panels power farm operations and reduce carbon emissions" />
    </node>
    <node TEXT="Our Biogas Plant">
      <node TEXT="Biogas from farm waste powers processes, lowers emissions, and supports a circular economy" />
    </node>
    <node TEXT="The Precision Agriculture">
      <node TEXT="Delivered Packages: 500" />
      <node TEXT="Global Shipping: 500" />
      <node TEXT="Air Freight: 500" />
      <node TEXT="Happy Customers: 500" />
    </node>
    <node TEXT="Corporate Social Responsibility (CSR)">
      <node TEXT="Empowering Rural Communities: 150+ jobs created" />
      <node TEXT="Farmer Development: Awareness for modern farming and animal husbandry" />
      <node TEXT="Environmental Stewardship: Projects reduce emissions" />
      <node TEXT="Animal Ethics   Welfare: Focus on nutrition, care, and ethical practices" />
    </node>
    <node TEXT="Get in touch - Let’s Get Started">
      <node TEXT="Contact Form">
        <node TEXT="First Name*" />
        <node TEXT="Last Name*" />
        <node TEXT="Email*" />
        <node TEXT="Mobile Number*" />
        <node TEXT="Company Name" />
        <node TEXT="Country" />
        <node TEXT="Interested In" />
        <node TEXT="Message" />
        <node TEXT="SUBMIT" />
      </node>
    </node>
  </node>
</map>