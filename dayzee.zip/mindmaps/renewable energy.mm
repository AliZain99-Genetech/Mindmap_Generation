<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="renewable energy">
    <node TEXT="Hero Section">
      <node TEXT="Reducing Carbon Emissions Today – Building A 100% Clean Energy Future" />
    </node>
    <node TEXT="Solar Panel Infrastructure">
      <node TEXT="Summary: 6MW solar panel system for efficient and sustainable farm energy." />
    </node>
    <node TEXT="Our Biogas Plant">
      <node TEXT="Summary: Converts organic farm waste to biogas for energy and waste reduction." />
    </node>
    <node TEXT="Key Stats">
      <node TEXT="500 Delivered Packages" />
      <node TEXT="500 Global Shipping" />
      <node TEXT="500 Air Freight" />
      <node TEXT="500 Happy Customers" />
    </node>
    <node TEXT="Corporate Social Responsibility (CSR)">
      <node TEXT="Empowering Rural Communities - 150+ jobs created, livelihoods uplifted" />
      <node TEXT="Farmer Development - Awareness sessions for modern farming" />
      <node TEXT="Environmental Stewardship - Solar and biogas projects for sustainability" />
      <node TEXT="Animal Ethics   Welfare - Focus on care, nutrition, ethical practices" />
    </node>
    <node TEXT="Get in touch – Let’s Get Started">
      <node TEXT="Contact Form">
        <node TEXT="First Name*" />
        <node TEXT="Last Name*" />
        <node TEXT="Email*" />
        <node TEXT="Mobile Number*" />
        <node TEXT="Company Name" />
        <node TEXT="Location (Dropdown: Karachi)" />
        <node TEXT="Country" />
        <node TEXT="Interested In" />
        <node TEXT="Message" />
        <node TEXT="Submit" />
      </node>
    </node>
  </node>
</map>