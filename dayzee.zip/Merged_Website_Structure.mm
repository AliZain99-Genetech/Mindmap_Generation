<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Dayzee">
    <node TEXT="Header">
      <node TEXT="Logo">
        <node TEXT="DayZee" LINK="https://dayzee.com/" />
      </node>
      <node TEXT="Navigation Links">
        <node TEXT="About Us" LINK="https://dayzee.com/about/">
          <node TEXT="DayZee Farms Began with a Bold Idea">
            <node TEXT="Overview">What if one project could contribute to the future of farming in Pakistan?</node>
            <node TEXT="Major Initiatives">
              <node TEXT="We launched DayZee Livestock">Elite genetics, IVF Lab, progressive dairy and beef solutions.</node>
              <node TEXT="DayZee Agriculture">Reclaiming land, modern irrigation, premium fodder.</node>
              <node TEXT="Solar installation">6MW solar power for farming sustainability.</node>
              <node TEXT="Intersection of science and soil">World-class solutions with a local heart.</node>
            </node>
          </node>
          <node TEXT="Our Impact on the UN Sustainable Development Goals">
            <node TEXT="SDG 2 – Zero Hunger">Improve livestock and crop yields for food supply.</node>
            <node TEXT="SDG 7 – Affordable and Clean Energy">Renewable energy powers sustainable farming.</node>
            <node TEXT="SDG 9 – Industry, Innovation and Infrastructure">Modern agricultural infrastructure through innovation.</node>
            <node TEXT="SDG 12 – Responsible Consumption and Production">Promote sustainable use and resource efficiency.</node>
            <node TEXT="SDG 13 – Climate Action">Climate-resilient farming and carbon footprint reduction.</node>
          </node>
          <node TEXT="Get in touch – Let’s Get Started">
            <node TEXT="Contact Form">
              <node TEXT="First Name" />
              <node TEXT="Last Name" />
              <node TEXT="Email" />
              <node TEXT="Mobile Number" />
              <node TEXT="Company Name" />
              <node TEXT="Country" />
              <node TEXT="Interested In" />
              <node TEXT="Message" />
              <node TEXT="SUBMIT" />
            </node>
          </node>
        </node>
        <node TEXT="Livestock" LINK="https://dayzee.com/live-stock/">
          <node TEXT="Superior Genetics for Tomorrow">
            <node TEXT="REQUEST SEMEN/EMBRYO">
              <node TEXT="Request Semen/Embryo" LINK="tel:+923314476666" />
            </node>
            <node TEXT="BOOK A CONSULTATION">
              <node TEXT="Book a Consultation" LINK="tel:+923314431111" />
            </node>
            <node TEXT="BOOK OPU OF YOUR COW NOW">
              <node TEXT="Book OPU of your cow now" LINK="tel:+923314431111" />
            </node>
          </node>
          <node TEXT="About Our Genetics">
            <node TEXT="Slick Gene Frisien - Imported Friesian, high milk yield, heat resistant" />
            <node TEXT="Brahman - Imported JDH line, beef breed" />
            <node TEXT="Beefmaster - Fertility, rapid weight gain, quality beef" />
            <node TEXT="Red Angus - High fertility, premium beef quality" />
          </node>
          <node TEXT="Our Services">
            <node TEXT="Semen Availability - High-performing, climate-adapted bulls" />
            <node TEXT="Embryo Transfer Pregnancies - IVF elite embryos for recipient cows" />
            <node TEXT="Pregnant Heifers for Sale - Elite embryo transfers, verified heifers" />
            <node TEXT="Genetics Consultation - Strategy for selecting right farm genetics" />
          </node>
          <node TEXT="OPU Session Promotion">
            <node TEXT="Want 20+ calves from one elite donor cow?" />
            <node TEXT="Book OPU Now">
              <node TEXT="Book OPU Now" LINK="tel:+92314431111" />
            </node>
          </node>
          <node TEXT="Explore Our Genetic Catalogue">
            <node TEXT="Brahman Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" />
            <node TEXT="Slick-Gene Friesian Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" />
            <node TEXT="Beefmaster Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" />
            <node TEXT="Red Angus Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" />
          </node>
          <node TEXT="Our Global Partners">
            <node TEXT="World leaders in livestock genetics and breeding" />
          </node>
          <node TEXT="Get in touch - Contact Form">
            <node TEXT="First Name" />
            <node TEXT="Last Name" />
            <node TEXT="Email" />
            <node TEXT="Mobile Number" />
            <node TEXT="Company Name" />
            <node TEXT="Country" />
            <node TEXT="Interested In" />
            <node TEXT="Message" />
            <node TEXT="SUBMIT" />
          </node>
        </node>
        <node TEXT="Agriculture" LINK="https://dayzee.com/agriculture/">
          <node TEXT="Hero Section">
            <node TEXT="Transforming 4,200 Barren Acres Into An Agricultural Hub" />
          </node>
          <node TEXT="A New Era of Desert Farming">
            <node TEXT="Timeline: April-2024, March-2025, May-2025" />
            <node TEXT="Desert innovation: Sustainable livestock and fodder production" />
          </node>
          <node TEXT="Barren Land Visual" />
          <node TEXT="Technology In Agriculture">
            <node TEXT="Irrigation Systems: 10 pivot systems operating, 17 more planned" />
            <node TEXT="Mechanized Farm Machinery: State-of-the-art technology" />
            <node TEXT="Solar Power Plant: 6MW plant powering farm" />
          </node>
          <node TEXT="Our Products">
            <node TEXT="Alfalfa: Forage crop for dairy and beef cattle" />
            <node TEXT="Rhodes Grass: Drought-resistant, nutritious grass for livestock" />
          </node>
          <node TEXT="Our Services">
            <node TEXT="Land Development: Transforming land for agriculture" />
            <node TEXT="Center Pivot Irrigation Systems: Full design and maintenance services" />
            <node TEXT="Farm Operations: Complete crop cycle and management" />
            <node TEXT="Integrated Farm Management: Full-spectrum services" />
            <node TEXT="Irrigation   Infrastructure Consultancy: Large-scale and solar-powered solutions" />
          </node>
          <node TEXT="Our Global Partners">
            <node TEXT="Livestock Science Backing by Global Leaders" />
          </node>
          <node TEXT="Get in touch Let’s Get Started">
            <node TEXT="Contact Form">
              <node TEXT="First Name" />
              <node TEXT="Last Name" />
              <node TEXT="Email" />
              <node TEXT="Mobile Number" />
              <node TEXT="Company Name" />
              <node TEXT="Country" />
              <node TEXT="Interested In" />
              <node TEXT="Message" />
              <node TEXT="SUBMIT" />
            </node>
          </node>
        </node>
        <node TEXT="Renewable Energy" LINK="https://dayzee.com/renewable-energy/">
          <node TEXT="Page Banner">
            <node TEXT="Reducing Carbon Emissions Today – Building A 100% Clean Energy Future" />
          </node>
          <node TEXT="Solar Panel Infrastructure">
            <node TEXT="6MW solar panels power farm operations and reduce carbon emissions" />
          </node>
          <node TEXT="Our Biogas Plant">
            <node TEXT="Biogas from farm waste powers processes, lowers emissions, and supports a circular economy" />
          </node>
          <node TEXT="The Precision Agriculture">
            <node TEXT="Delivered Packages: 500" />
            <node TEXT="Global Shipping: 500" />
            <node TEXT="Air Freight: 500" />
            <node TEXT="Happy Customers: 500" />
          </node>
          <node TEXT="Corporate Social Responsibility (CSR)">
            <node TEXT="Empowering Rural Communities: 150+ jobs created" />
            <node TEXT="Farmer Development: Awareness for modern farming and animal husbandry" />
            <node TEXT="Environmental Stewardship: Projects reduce emissions" />
            <node TEXT="Animal Ethics   Welfare: Focus on nutrition, care, and ethical practices" />
          </node>
          <node TEXT="Get in touch - Let’s Get Started">
            <node TEXT="Contact Form">
              <node TEXT="First Name*" />
              <node TEXT="Last Name*" />
              <node TEXT="Email*" />
              <node TEXT="Mobile Number*" />
              <node TEXT="Company Name" />
              <node TEXT="Country" />
              <node TEXT="Interested In" />
              <node TEXT="Message" />
              <node TEXT="SUBMIT" />
            </node>
          </node>
        </node>
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/">
          <node TEXT="Image Gallery Section">
            <node TEXT="DayZee at International Livestock, Dairy, Poultry and Agri Expo 2025">
              <node TEXT="Event Gallery Link" LINK="https://dayzee.com/gallery/dayzee-at-ildpa2025/" />
            </node>
            <node TEXT="Chinese Delegation at DayZee (Private) Limited">
              <node TEXT="Delegation Gallery Link" LINK="https://dayzee.com/gallery/chinese-delegation/" />
            </node>
          </node>
          <node TEXT="Contact and Inquiry Section">
            <node TEXT="Get in touch   Let #39;s Get Started summary" />
            <node TEXT="Contact Form">
              <node TEXT="First Name" />
              <node TEXT="Last Name" />
              <node TEXT="Email" />
              <node TEXT="Mobile Number" />
              <node TEXT="Company Name" />
              <node TEXT="Country" />
              <node TEXT="Interested In" />
              <node TEXT="Message" />
              <node TEXT="SUBMIT Button" />
            </node>
          </node>
        </node>
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/">
          <node TEXT="Contact Information">
            <node TEXT="Our Office">
              <node TEXT="DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur.">
                <node TEXT="Location on Google Maps" LINK="https://maps.app.goo.gl/WstmNjesSmVKyyB66" />
              </node>
            </node>
            <node TEXT="Call Us">
              <node TEXT="0331-443 1111" LINK="tel:0331 443 1111" />
              <node TEXT="0331-447 6666" LINK="tel:0331 447 66 66" />
            </node>
            <node TEXT="Email Address">
              <node TEXT="info@dayzee.com" LINK="mailto:info@dayzee.com" />
            </node>
          </node>
          <node TEXT="Get in touch form">
            <node TEXT="First Name" />
            <node TEXT="Last Name" />
            <node TEXT="Email" />
            <node TEXT="Mobile Number" />
            <node TEXT="Company Name" />
            <node TEXT="City (Dropdown, default: Karachi)" />
            <node TEXT="Country" />
            <node TEXT="Interested In" />
            <node TEXT="Message" />
            <node TEXT="SUBMIT button" />
          </node>
        </node>
      </node>
      <node TEXT="Skip to content" LINK="https://dayzee.com/#content" />
    </node>
    <node TEXT="Home Page">
      <node TEXT="Hero Section">
        <node TEXT="Image: Livestock background" />
        <node TEXT="Title: EMBRYO   SEMEN PRODUCTION UNITS" />
        <node TEXT="Subtitle: Revolutionizing Livestock Genetics" />
      </node>
      <node TEXT="Livestock Section">
        <node TEXT="Section Title: LIVESTOCK" />
        <node TEXT="Section Subtitle: In Elite Genetics for Unmatched Livestock Performance" />
        <node TEXT="Description" />
        <node TEXT="Learn More Button" LINK="https://dayzee.com/live-stock/" />
        <node TEXT="Programs">
          <node TEXT="Invitro Fertilization Program">
            <node TEXT="Image: IVF Lab" />
            <node TEXT="Description" />
          </node>
          <node TEXT="Artificial Insemination Program">
            <node TEXT="Image: AI Program" />
            <node TEXT="Description" />
          </node>
          <node TEXT="Genetics Lab">
            <node TEXT="Image: Genetics Lab" />
            <node TEXT="Description" />
          </node>
        </node>
      </node>
      <node TEXT="Benefits">
        <node TEXT="Heat Tolerance">
          <node TEXT="Perfect for Pakistan’s climate" />
        </node>
        <node TEXT="Fertility   Productivity">
          <node TEXT="Maximize your herd’s potential" />
        </node>
        <node TEXT="Long-Term Profitability">
          <node TEXT="Higher quality offspring with market-leading traits" />
        </node>
      </node>
      <node TEXT="Agriculture Section">
        <node TEXT="Section Title: Agriculture" />
        <node TEXT="Section Subtitle: Turning Barren Land into Agricultural Gold" />
        <node TEXT="Description" />
        <node TEXT="Learn More Button" LINK="https://dayzee.com/agriculture/" />
        <node TEXT="Programs">
          <node TEXT="Pivot Irrigation">
            <node TEXT="Image: Pivot Irrigation" />
            <node TEXT="Description" />
          </node>
          <node TEXT="Mechanized Farming">
            <node TEXT="Image: Mechanized Farming" />
            <node TEXT="Description" />
          </node>
          <node TEXT="Premium Animal Fodder">
            <node TEXT="Image: Animal Fodder" />
            <node TEXT="Description" />
          </node>
        </node>
      </node>
      <node TEXT="Renewable Energy Section">
        <node TEXT="Section Title: Renewable Energy" />
        <node TEXT="Section Subtitle: Sustainable and Smart Agriculture" />
        <node TEXT="Explore Our Sustainability Button" LINK="https://dayzee.com/renewable-energy/" />
        <node TEXT="Programs">
          <node TEXT="Solar Powered Future">
            <node TEXT="Image: Solar Power" />
            <node TEXT="6.6 MW Clean Energy" />
            <node TEXT="Description" />
          </node>
          <node TEXT="Biogas To Energy">
            <node TEXT="Image: Biogas" />
            <node TEXT="2.2 MW from Organic Waste" />
            <node TEXT="Description" />
          </node>
        </node>
      </node>
      <node TEXT="Contact Section">
        <node TEXT="Get in touch Let’s Get Started" />
        <node TEXT="Contact Form">
          <node TEXT="First Name*" />
          <node TEXT="Last Name*" />
          <node TEXT="Email*" />
          <node TEXT="Mobile Number*" />
          <node TEXT="Company Name" />
          <node TEXT="City (Dropdown: Karachi)" />
          <node TEXT="Country" />
          <node TEXT="Interested In" />
          <node TEXT="Message" />
          <node TEXT="Submit Button" />
        </node>
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Company Description" />
      <node TEXT="Company Links">
        <node TEXT="Home" LINK="https://dayzee.com/" />
        <node TEXT="Services" LINK="https://dayzee.com/service/" />
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" />
      </node>
      <node TEXT="Quick Links">
        <node TEXT="About Us" LINK="https://dayzee.com/about/" />
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" />
        <node TEXT="FAQs" LINK="https://dayzee.com/faqs" />
      </node>
      <node TEXT="Social Media">
        <node TEXT="Facebook" LINK="https://www.facebook.com/dayzeepvtltd" />
        <node TEXT="Tik Tok" LINK="https://www.tiktok.com/@dayzee.pvt.ltd" />
        <node TEXT="Instagram" LINK="https://www.instagram.com/dayzee_pvt_ltd/" />
        <node TEXT="Youtube" LINK="https://www.youtube.com/@DayZee_Pvt_Ltd" />
      </node>
      <node TEXT="Copyright © 2025 DayZee. All Rights Reserved" />
    </node>
  </node>
</map>