<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Dayzee" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Logo" FOLDED="true">
        <node TEXT="DayZee" LINK="https://dayzee.com/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Navigation Links" FOLDED="true">
        <node TEXT="About Us" LINK="https://dayzee.com/about/" FOLDED="true">
          <node TEXT="DayZee Farms Began with a Bold Idea" FOLDED="true">
            <node TEXT="Overview" FOLDED="true">What if one project could contribute to the future of farming in Pakistan?</node>
            <node TEXT="Major Initiatives" FOLDED="true">
              <node TEXT="We launched DayZee Livestock" FOLDED="true">Elite genetics, IVF Lab, progressive dairy and beef solutions.</node>
              <node TEXT="DayZee Agriculture" FOLDED="true">Reclaiming land, modern irrigation, premium fodder.</node>
              <node TEXT="Solar installation" FOLDED="true">6MW solar power for farming sustainability.</node>
              <node TEXT="Intersection of science and soil" FOLDED="true">World-class solutions with a local heart.</node>
              </node>
            </node>
          <node TEXT="Our Impact on the UN Sustainable Development Goals" FOLDED="true">
            <node TEXT="SDG 2 – Zero Hunger" FOLDED="true">Improve livestock and crop yields for food supply.</node>
            <node TEXT="SDG 7 – Affordable and Clean Energy" FOLDED="true">Renewable energy powers sustainable farming.</node>
            <node TEXT="SDG 9 – Industry, Innovation and Infrastructure" FOLDED="true">Modern agricultural infrastructure through innovation.</node>
            <node TEXT="SDG 12 – Responsible Consumption and Production" FOLDED="true">Promote sustainable use and resource efficiency.</node>
            <node TEXT="SDG 13 – Climate Action" FOLDED="true">Climate-resilient farming and carbon footprint reduction.</node>
            </node>
          <node TEXT="Get in touch – Let’s Get Started" FOLDED="true">
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="First Name" FOLDED="true" />
              <node TEXT="Last Name" FOLDED="true" />
              <node TEXT="Email" FOLDED="true" />
              <node TEXT="Mobile Number" FOLDED="true" />
              <node TEXT="Company Name" FOLDED="true" />
              <node TEXT="Country" FOLDED="true" />
              <node TEXT="Interested In" FOLDED="true" />
              <node TEXT="Message" FOLDED="true">
                <node TEXT="Opens a direct message or chat box." FOLDED="true" />
                </node>
              <node TEXT="SUBMIT" FOLDED="true">
                <node TEXT="Sends form data to the server." FOLDED="true" />
                </node>
              <node TEXT="Opens contact form or company contact details." FOLDED="true">
                <node TEXT="Opens contact form or company contact details." FOLDED="true" />
                </node>
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          <node TEXT="Displays information about the organization or product." FOLDED="true">
            <node TEXT="Displays information about the organization or product." FOLDED="true" />
            </node>
          </node>
        <node TEXT="Livestock" LINK="https://dayzee.com/live-stock/" FOLDED="true">
          <node TEXT="Superior Genetics for Tomorrow" FOLDED="true">
            <node TEXT="REQUEST SEMEN/EMBRYO" FOLDED="true">
              <node TEXT="Request Semen/Embryo" LINK="tel:+923314476666" FOLDED="true" />
              </node>
            <node TEXT="BOOK A CONSULTATION" FOLDED="true">
              <node TEXT="Book a Consultation" LINK="tel:+923314431111" FOLDED="true" />
              </node>
            <node TEXT="BOOK OPU OF YOUR COW NOW" FOLDED="true">
              <node TEXT="Book OPU of your cow now" LINK="tel:+923314431111" FOLDED="true" />
              </node>
            </node>
          <node TEXT="About Our Genetics" FOLDED="true">
            <node TEXT="Slick Gene Frisien - Imported Friesian, high milk yield, heat resistant" FOLDED="true" />
            <node TEXT="Brahman - Imported JDH line, beef breed" FOLDED="true" />
            <node TEXT="Beefmaster - Fertility, rapid weight gain, quality beef" FOLDED="true" />
            <node TEXT="Red Angus - High fertility, premium beef quality" FOLDED="true" />
            <node TEXT="Displays information about the organization or product." FOLDED="true">
              <node TEXT="Displays information about the organization or product." FOLDED="true" />
              </node>
            </node>
          <node TEXT="Our Services" FOLDED="true">
            <node TEXT="Semen Availability - High-performing, climate-adapted bulls" FOLDED="true" />
            <node TEXT="Embryo Transfer Pregnancies - IVF elite embryos for recipient cows" FOLDED="true" />
            <node TEXT="Pregnant Heifers for Sale - Elite embryo transfers, verified heifers" FOLDED="true" />
            <node TEXT="Genetics Consultation - Strategy for selecting right farm genetics" FOLDED="true" />
            </node>
          <node TEXT="OPU Session Promotion" FOLDED="true">
            <node TEXT="Want 20+ calves from one elite donor cow?" FOLDED="true" />
            <node TEXT="Book OPU Now" FOLDED="true">
              <node TEXT="Book OPU Now" LINK="tel:+92314431111" FOLDED="true" />
              </node>
            </node>
          <node TEXT="Explore Our Genetic Catalogue" FOLDED="true">
            <node TEXT="Brahman Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" FOLDED="true">
              <node TEXT="Screenshot Example" FOLDED="true">
                <richcontent TYPE="NODE">
                  <html>
                    <body>
                      <p>
                        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_American-Brahmans.pdf.png" width="500" height="250" />
                        </p>
                      </body>
                    </html>
                  </richcontent>
                </node>
              </node>
            <node TEXT="Slick-Gene Friesian Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" FOLDED="true">
              <node TEXT="Screenshot Example" FOLDED="true">
                <richcontent TYPE="NODE">
                  <html>
                    <body>
                      <p>
                        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Slick-Gene.pdf.png" width="500" height="250" />
                        </p>
                      </body>
                    </html>
                  </richcontent>
                </node>
              </node>
            <node TEXT="Beefmaster Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" FOLDED="true">
              <node TEXT="Screenshot Example" FOLDED="true">
                <richcontent TYPE="NODE">
                  <html>
                    <body>
                      <p>
                        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Beef-Master.pdf.png" width="500" height="250" />
                        </p>
                      </body>
                    </html>
                  </richcontent>
                </node>
              </node>
            <node TEXT="Red Angus Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" FOLDED="true">
              <node TEXT="Screenshot Example" FOLDED="true">
                <richcontent TYPE="NODE">
                  <html>
                    <body>
                      <p>
                        <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Red-Angus.pdf.png" width="500" height="250" />
                        </p>
                      </body>
                    </html>
                  </richcontent>
                </node>
              </node>
            </node>
          <node TEXT="Our Global Partners" FOLDED="true">
            <node TEXT="World leaders in livestock genetics and breeding" FOLDED="true" />
            </node>
          <node TEXT="Get in touch - Contact Form" FOLDED="true">
            <node TEXT="First Name" FOLDED="true" />
            <node TEXT="Last Name" FOLDED="true" />
            <node TEXT="Email" FOLDED="true" />
            <node TEXT="Mobile Number" FOLDED="true" />
            <node TEXT="Company Name" FOLDED="true" />
            <node TEXT="Country" FOLDED="true" />
            <node TEXT="Interested In" FOLDED="true" />
            <node TEXT="Message" FOLDED="true">
              <node TEXT="Opens a direct message or chat box." FOLDED="true" />
              </node>
            <node TEXT="SUBMIT" FOLDED="true">
              <node TEXT="Sends form data to the server." FOLDED="true" />
              </node>
            <node TEXT="Opens contact form or company contact details." FOLDED="true">
              <node TEXT="Opens contact form or company contact details." FOLDED="true" />
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Agriculture" LINK="https://dayzee.com/agriculture/" FOLDED="true">
          <node TEXT="Hero Section" FOLDED="true">
            <node TEXT="Transforming 4,200 Barren Acres Into An Agricultural Hub" FOLDED="true" />
            </node>
          <node TEXT="A New Era of Desert Farming" FOLDED="true">
            <node TEXT="Timeline: April-2024, March-2025, May-2025" FOLDED="true" />
            <node TEXT="Desert innovation: Sustainable livestock and fodder production" FOLDED="true" />
            </node>
          <node TEXT="Barren Land Visual" FOLDED="true" />
          <node TEXT="Technology In Agriculture" FOLDED="true">
            <node TEXT="Irrigation Systems: 10 pivot systems operating, 17 more planned" FOLDED="true" />
            <node TEXT="Mechanized Farm Machinery: State-of-the-art technology" FOLDED="true" />
            <node TEXT="Solar Power Plant: 6MW plant powering farm" FOLDED="true" />
            </node>
          <node TEXT="Our Products" FOLDED="true">
            <node TEXT="Alfalfa: Forage crop for dairy and beef cattle" FOLDED="true" />
            <node TEXT="Rhodes Grass: Drought-resistant, nutritious grass for livestock" FOLDED="true" />
            </node>
          <node TEXT="Our Services" FOLDED="true">
            <node TEXT="Land Development: Transforming land for agriculture" FOLDED="true" />
            <node TEXT="Center Pivot Irrigation Systems: Full design and maintenance services" FOLDED="true" />
            <node TEXT="Farm Operations: Complete crop cycle and management" FOLDED="true" />
            <node TEXT="Integrated Farm Management: Full-spectrum services" FOLDED="true" />
            <node TEXT="Irrigation   Infrastructure Consultancy: Large-scale and solar-powered solutions" FOLDED="true" />
            </node>
          <node TEXT="Our Global Partners" FOLDED="true">
            <node TEXT="Livestock Science Backing by Global Leaders" FOLDED="true" />
            </node>
          <node TEXT="Get in touch Let’s Get Started" FOLDED="true">
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="First Name" FOLDED="true" />
              <node TEXT="Last Name" FOLDED="true" />
              <node TEXT="Email" FOLDED="true" />
              <node TEXT="Mobile Number" FOLDED="true" />
              <node TEXT="Company Name" FOLDED="true" />
              <node TEXT="Country" FOLDED="true" />
              <node TEXT="Interested In" FOLDED="true" />
              <node TEXT="Message" FOLDED="true">
                <node TEXT="Opens a direct message or chat box." FOLDED="true" />
                </node>
              <node TEXT="SUBMIT" FOLDED="true">
                <node TEXT="Sends form data to the server." FOLDED="true" />
                </node>
              <node TEXT="Opens contact form or company contact details." FOLDED="true">
                <node TEXT="Opens contact form or company contact details." FOLDED="true" />
                </node>
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Renewable Energy" LINK="https://dayzee.com/renewable-energy/" FOLDED="true">
          <node TEXT="Page Banner" FOLDED="true">
            <node TEXT="Reducing Carbon Emissions Today – Building A 100% Clean Energy Future" FOLDED="true" />
            </node>
          <node TEXT="Solar Panel Infrastructure" FOLDED="true">
            <node TEXT="6MW solar panels power farm operations and reduce carbon emissions" FOLDED="true" />
            </node>
          <node TEXT="Our Biogas Plant" FOLDED="true">
            <node TEXT="Biogas from farm waste powers processes, lowers emissions, and supports a circular economy" FOLDED="true" />
            </node>
          <node TEXT="The Precision Agriculture" FOLDED="true">
            <node TEXT="Delivered Packages: 500" FOLDED="true" />
            <node TEXT="Global Shipping: 500" FOLDED="true" />
            <node TEXT="Air Freight: 500" FOLDED="true" />
            <node TEXT="Happy Customers: 500" FOLDED="true" />
            </node>
          <node TEXT="Corporate Social Responsibility (CSR)" FOLDED="true">
            <node TEXT="Empowering Rural Communities: 150+ jobs created" FOLDED="true" />
            <node TEXT="Farmer Development: Awareness for modern farming and animal husbandry" FOLDED="true" />
            <node TEXT="Environmental Stewardship: Projects reduce emissions" FOLDED="true" />
            <node TEXT="Animal Ethics   Welfare: Focus on nutrition, care, and ethical practices" FOLDED="true" />
            </node>
          <node TEXT="Get in touch - Let’s Get Started" FOLDED="true">
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="First Name*" FOLDED="true" />
              <node TEXT="Last Name*" FOLDED="true" />
              <node TEXT="Email*" FOLDED="true" />
              <node TEXT="Mobile Number*" FOLDED="true" />
              <node TEXT="Company Name" FOLDED="true" />
              <node TEXT="Country" FOLDED="true" />
              <node TEXT="Interested In" FOLDED="true" />
              <node TEXT="Message" FOLDED="true">
                <node TEXT="Opens a direct message or chat box." FOLDED="true" />
                </node>
              <node TEXT="SUBMIT" FOLDED="true">
                <node TEXT="Sends form data to the server." FOLDED="true" />
                </node>
              <node TEXT="Opens contact form or company contact details." FOLDED="true">
                <node TEXT="Opens contact form or company contact details." FOLDED="true" />
                </node>
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" FOLDED="true">
          <node TEXT="Image Gallery Section" FOLDED="true">
            <node TEXT="DayZee at International Livestock, Dairy, Poultry and Agri Expo 2025" FOLDED="true">
              <node TEXT="Event Gallery Link" LINK="https://dayzee.com/gallery/dayzee-at-ildpa2025/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_dayzee.com_gallery_dayzee-at-ildpa2025.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Chinese Delegation at DayZee (Private) Limited" FOLDED="true">
              <node TEXT="Delegation Gallery Link" LINK="https://dayzee.com/gallery/chinese-delegation/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_dayzee.com_gallery_chinese-delegation.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            </node>
          <node TEXT="Contact and Inquiry Section" FOLDED="true">
            <node TEXT="Get in touch   Let #39;s Get Started summary" FOLDED="true" />
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="First Name" FOLDED="true" />
              <node TEXT="Last Name" FOLDED="true" />
              <node TEXT="Email" FOLDED="true" />
              <node TEXT="Mobile Number" FOLDED="true" />
              <node TEXT="Company Name" FOLDED="true" />
              <node TEXT="Country" FOLDED="true" />
              <node TEXT="Interested In" FOLDED="true" />
              <node TEXT="Message" FOLDED="true">
                <node TEXT="Opens a direct message or chat box." FOLDED="true" />
                </node>
              <node TEXT="SUBMIT Button" FOLDED="true">
                <node TEXT="Sends form data to the server." FOLDED="true" />
                </node>
              <node TEXT="Opens contact form or company contact details." FOLDED="true">
                <node TEXT="Opens contact form or company contact details." FOLDED="true" />
                </node>
              </node>
            <node TEXT="Opens contact form or company contact details." FOLDED="true">
              <node TEXT="Opens contact form or company contact details." FOLDED="true" />
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" FOLDED="true">
          <node TEXT="Contact Information" FOLDED="true">
            <node TEXT="Our Office" FOLDED="true">
              <node TEXT="DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur." FOLDED="true">
                <node TEXT="Location on Google Maps" LINK="https://maps.app.goo.gl/WstmNjesSmVKyyB66" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_maps.app.goo.gl_WstmNjesSmVKyyB66.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              </node>
            <node TEXT="Call Us" FOLDED="true">
              <node TEXT="0331-443 1111" LINK="tel:0331 443 1111" FOLDED="true" />
              <node TEXT="0331-447 6666" LINK="tel:0331 447 66 66" FOLDED="true" />
              </node>
            <node TEXT="Email Address" FOLDED="true">
              <node TEXT="info@dayzee.com" LINK="mailto:info@dayzee.com" FOLDED="true" />
              </node>
            <node TEXT="Opens contact form or company contact details." FOLDED="true">
              <node TEXT="Opens contact form or company contact details." FOLDED="true" />
              </node>
            </node>
          <node TEXT="Get in touch form" FOLDED="true">
            <node TEXT="First Name" FOLDED="true" />
            <node TEXT="Last Name" FOLDED="true" />
            <node TEXT="Email" FOLDED="true" />
            <node TEXT="Mobile Number" FOLDED="true" />
            <node TEXT="Company Name" FOLDED="true" />
            <node TEXT="City (Dropdown, default: Karachi)" FOLDED="true" />
            <node TEXT="Country" FOLDED="true" />
            <node TEXT="Interested In" FOLDED="true" />
            <node TEXT="Message" FOLDED="true">
              <node TEXT="Opens a direct message or chat box." FOLDED="true" />
              </node>
            <node TEXT="SUBMIT button" FOLDED="true">
              <node TEXT="Sends form data to the server." FOLDED="true" />
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          <node TEXT="Opens contact form or company contact details." FOLDED="true">
            <node TEXT="Opens contact form or company contact details." FOLDED="true" />
            </node>
          </node>
        </node>
      <node TEXT="Skip to content" LINK="https://dayzee.com/#content" FOLDED="true">
        <node TEXT="Screenshot Example" FOLDED="true">
          <richcontent TYPE="NODE">
            <html>
              <body>
                <p>
                  <img src="hyperlink_screenshots/https_dayzee.com_content.png" width="500" height="250" />
                  </p>
                </body>
              </html>
            </richcontent>
          </node>
        </node>
      </node>
    <node TEXT="Home Page" FOLDED="true">
      <node TEXT="Hero Section" FOLDED="true">
        <node TEXT="Image: Livestock background" FOLDED="true" />
        <node TEXT="Title: EMBRYO   SEMEN PRODUCTION UNITS" FOLDED="true" />
        <node TEXT="Subtitle: Revolutionizing Livestock Genetics" FOLDED="true" />
        </node>
      <node TEXT="Livestock Section" FOLDED="true">
        <node TEXT="Section Title: LIVESTOCK" FOLDED="true" />
        <node TEXT="Section Subtitle: In Elite Genetics for Unmatched Livestock Performance" FOLDED="true" />
        <node TEXT="Description" FOLDED="true" />
        <node TEXT="Learn More Button" LINK="https://dayzee.com/live-stock/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Programs" FOLDED="true">
          <node TEXT="Invitro Fertilization Program" FOLDED="true">
            <node TEXT="Image: IVF Lab" FOLDED="true" />
            <node TEXT="Description" FOLDED="true" />
            </node>
          <node TEXT="Artificial Insemination Program" FOLDED="true">
            <node TEXT="Image: AI Program" FOLDED="true" />
            <node TEXT="Description" FOLDED="true" />
            </node>
          <node TEXT="Genetics Lab" FOLDED="true">
            <node TEXT="Image: Genetics Lab" FOLDED="true" />
            <node TEXT="Description" FOLDED="true" />
            </node>
          </node>
        </node>
      <node TEXT="Benefits" FOLDED="true">
        <node TEXT="Heat Tolerance" FOLDED="true">
          <node TEXT="Perfect for Pakistan’s climate" FOLDED="true" />
          </node>
        <node TEXT="Fertility   Productivity" FOLDED="true">
          <node TEXT="Maximize your herd’s potential" FOLDED="true" />
          </node>
        <node TEXT="Long-Term Profitability" FOLDED="true">
          <node TEXT="Higher quality offspring with market-leading traits" FOLDED="true" />
          </node>
        </node>
      <node TEXT="Agriculture Section" FOLDED="true">
        <node TEXT="Section Title: Agriculture" FOLDED="true" />
        <node TEXT="Section Subtitle: Turning Barren Land into Agricultural Gold" FOLDED="true" />
        <node TEXT="Description" FOLDED="true" />
        <node TEXT="Learn More Button" LINK="https://dayzee.com/agriculture/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Programs" FOLDED="true">
          <node TEXT="Pivot Irrigation" FOLDED="true">
            <node TEXT="Image: Pivot Irrigation" FOLDED="true" />
            <node TEXT="Description" FOLDED="true" />
            </node>
          <node TEXT="Mechanized Farming" FOLDED="true">
            <node TEXT="Image: Mechanized Farming" FOLDED="true" />
            <node TEXT="Description" FOLDED="true" />
            </node>
          <node TEXT="Premium Animal Fodder" FOLDED="true">
            <node TEXT="Image: Animal Fodder" FOLDED="true" />
            <node TEXT="Description" FOLDED="true" />
            </node>
          </node>
        </node>
      <node TEXT="Renewable Energy Section" FOLDED="true">
        <node TEXT="Section Title: Renewable Energy" FOLDED="true" />
        <node TEXT="Section Subtitle: Sustainable and Smart Agriculture" FOLDED="true" />
        <node TEXT="Explore Our Sustainability Button" LINK="https://dayzee.com/renewable-energy/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Programs" FOLDED="true">
          <node TEXT="Solar Powered Future" FOLDED="true">
            <node TEXT="Image: Solar Power" FOLDED="true" />
            <node TEXT="6.6 MW Clean Energy" FOLDED="true" />
            <node TEXT="Description" FOLDED="true" />
            </node>
          <node TEXT="Biogas To Energy" FOLDED="true">
            <node TEXT="Image: Biogas" FOLDED="true" />
            <node TEXT="2.2 MW from Organic Waste" FOLDED="true" />
            <node TEXT="Description" FOLDED="true" />
            </node>
          </node>
        </node>
      <node TEXT="Contact Section" FOLDED="true">
        <node TEXT="Get in touch Let’s Get Started" FOLDED="true" />
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="First Name*" FOLDED="true" />
          <node TEXT="Last Name*" FOLDED="true" />
          <node TEXT="Email*" FOLDED="true" />
          <node TEXT="Mobile Number*" FOLDED="true" />
          <node TEXT="Company Name" FOLDED="true" />
          <node TEXT="City (Dropdown: Karachi)" FOLDED="true" />
          <node TEXT="Country" FOLDED="true" />
          <node TEXT="Interested In" FOLDED="true" />
          <node TEXT="Message" FOLDED="true">
            <node TEXT="Opens a direct message or chat box." FOLDED="true" />
            </node>
          <node TEXT="Submit Button" FOLDED="true">
            <node TEXT="Sends form data to the server." FOLDED="true" />
            </node>
          <node TEXT="Opens contact form or company contact details." FOLDED="true">
            <node TEXT="Opens contact form or company contact details." FOLDED="true" />
            </node>
          </node>
        <node TEXT="Opens contact form or company contact details." FOLDED="true">
          <node TEXT="Opens contact form or company contact details." FOLDED="true" />
          </node>
        </node>
      <node TEXT="Navigates to the main landing page or dashboard." FOLDED="true">
        <node TEXT="Centralized area showing user stats and quick actions." FOLDED="true" />
        </node>
      </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Company Description" FOLDED="true" />
      <node TEXT="Company Links" FOLDED="true">
        <node TEXT="Home" LINK="https://dayzee.com/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          <node TEXT="Navigates to the main landing page or dashboard." FOLDED="true">
            <node TEXT="Centralized area showing user stats and quick actions." FOLDED="true" />
            </node>
          </node>
        <node TEXT="Services" LINK="https://dayzee.com/service/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_service.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Quick Links" FOLDED="true">
        <node TEXT="About Us" LINK="https://dayzee.com/about/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          <node TEXT="Displays information about the organization or product." FOLDED="true">
            <node TEXT="Displays information about the organization or product." FOLDED="true" />
            </node>
          </node>
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          <node TEXT="Opens contact form or company contact details." FOLDED="true">
            <node TEXT="Opens contact form or company contact details." FOLDED="true" />
            </node>
          </node>
        <node TEXT="FAQs" LINK="https://dayzee.com/faqs" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_faqs.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Social Media" FOLDED="true">
        <node TEXT="Facebook" LINK="https://www.facebook.com/dayzeepvtltd" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_www.facebook.com_dayzeepvtltd.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Tik Tok" LINK="https://www.tiktok.com/@dayzee.pvt.ltd" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_www.tiktok.com_dayzee.pvt.ltd.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Instagram" LINK="https://www.instagram.com/dayzee_pvt_ltd/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_www.instagram.com_dayzee_pvt_ltd.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Youtube" LINK="https://www.youtube.com/@DayZee_Pvt_Ltd" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_www.youtube.com_DayZee_Pvt_Ltd.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Copyright © 2025 DayZee. All Rights Reserved" FOLDED="true" />
      <node TEXT="Displays footer information and links." FOLDED="true">
        <node TEXT="Displays footer information and links." FOLDED="true" />
        </node>
      </node>
    <node TEXT="Test Cases" POSITION="left" FOLDED="true">
      <node TEXT="ABOUT US Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the ABOUT US link in the header navigates the user to the About Us page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The About Us page displays the company mission and vision statements." FOLDED="true" POSITION="left" />
          <node TEXT="3. The About Us page loads all major initiatives and impact sections without errors." FOLDED="true" POSITION="left" />
          <node TEXT="4. The contact form on the About Us page accepts valid user input and submits successfully." FOLDED="true" POSITION="left" />
          <node TEXT="5. The About Us page displays images and graphics correctly." FOLDED="true" POSITION="left" />
          <node TEXT="6. The About Us page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
          <node TEXT="7. The About Us page displays the organization's history and timeline." FOLDED="true" POSITION="left" />
          <node TEXT="8. The About Us page provides working links to related sections or external resources." FOLDED="true" POSITION="left" />
          <node TEXT="9. The About Us page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
          <node TEXT="10. The About Us page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
          <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
          <node TEXT="3. Attempting to access the About Us page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
          <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
          <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
          <node TEXT="7. Disabling JavaScript and clicking the ABOUT US link does not navigate to the page." FOLDED="true" POSITION="left" />
          <node TEXT="8. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
          <node TEXT="9. Trying to access the About Us page while logged out (if authentication is required) redirects to login." FOLDED="true" POSITION="left" />
          <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The About Us page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. The About Us page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
          <node TEXT="3. The About Us page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="4. The About Us page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
          <node TEXT="5. The About Us page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
          <node TEXT="6. The About Us page content is protected from unauthorized editing." FOLDED="true" POSITION="left" />
          <node TEXT="7. The About Us page images are optimized for fast loading." FOLDED="true" POSITION="left" />
          <node TEXT="8. The About Us page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
          <node TEXT="9. The About Us page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
          <node TEXT="10. The About Us page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="LIVESTOCK Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the LIVESTOCK link in the header navigates the user to the Livestock page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Livestock page displays information about available livestock genetics and services." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Livestock page provides working links to request semen or embryo services." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Livestock page contact form accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Livestock page displays images of livestock and related programs." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Livestock page allows users to book consultations via provided links." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Livestock page lists all available livestock breeds with descriptions." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Livestock page provides downloadable catalogues for each breed." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Livestock page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Livestock page content is accessible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
          <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
          <node TEXT="3. Attempting to access the Livestock page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
          <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
          <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
          <node TEXT="7. Clicking on a broken catalogue link displays an error or missing file message." FOLDED="true" POSITION="left" />
          <node TEXT="8. Disabling JavaScript and clicking the LIVESTOCK link does not navigate to the page." FOLDED="true" POSITION="left" />
          <node TEXT="9. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
          <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The Livestock page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Livestock page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Livestock page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Livestock page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Livestock page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Livestock page images are optimized for fast loading." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Livestock page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Livestock page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Livestock page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Livestock page downloadable catalogues are under 10MB for quick access." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="AGRICULTURE Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the AGRICULTURE link in the header navigates the user to the Agriculture page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Agriculture page displays information about land transformation and farming technology." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Agriculture page lists all available products and services with descriptions." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Agriculture page displays images and graphics related to agricultural projects." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Agriculture page contact form accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Agriculture page provides working links to partner organizations." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Agriculture page displays a timeline of major agricultural milestones." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Agriculture page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Agriculture page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Agriculture page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
          <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
          <node TEXT="3. Attempting to access the Agriculture page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
          <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
          <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
          <node TEXT="7. Disabling JavaScript and clicking the AGRICULTURE link does not navigate to the page." FOLDED="true" POSITION="left" />
          <node TEXT="8. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
          <node TEXT="9. Trying to access the Agriculture page while logged out (if authentication is required) redirects to login." FOLDED="true" POSITION="left" />
          <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The Agriculture page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Agriculture page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Agriculture page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Agriculture page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Agriculture page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Agriculture page images are optimized for fast loading." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Agriculture page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Agriculture page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Agriculture page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Agriculture page content is readable under high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="RENEWABLE ENERGY Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the RENEWABLE ENERGY link in the header navigates the user to the Renewable Energy page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Renewable Energy page displays information about solar and biogas initiatives." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Renewable Energy page lists all renewable energy projects with descriptions." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Renewable Energy page displays images and graphics related to energy infrastructure." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Renewable Energy page contact form accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Renewable Energy page provides working links to CSR and partner organizations." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Renewable Energy page displays statistics about energy output and impact." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Renewable Energy page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Renewable Energy page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Renewable Energy page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
          <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
          <node TEXT="3. Attempting to access the Renewable Energy page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
          <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
          <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
          <node TEXT="7. Disabling JavaScript and clicking the RENEWABLE ENERGY link does not navigate to the page." FOLDED="true" POSITION="left" />
          <node TEXT="8. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
          <node TEXT="9. Trying to access the Renewable Energy page while logged out (if authentication is required) redirects to login." FOLDED="true" POSITION="left" />
          <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The Renewable Energy page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Renewable Energy page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Renewable Energy page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Renewable Energy page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Renewable Energy page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Renewable Energy page images are optimized for fast loading." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Renewable Energy page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Renewable Energy page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Renewable Energy page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Renewable Energy page content is readable under high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="GALLERY Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the GALLERY link in the header navigates the user to the Gallery page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Gallery page displays a grid or list of event and project images." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Gallery page allows users to click on images to view them in a larger format." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Gallery page provides working links to event-specific galleries." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Gallery page displays image captions and event descriptions." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Gallery page contact form accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Gallery page allows users to filter or search images by event or category." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Gallery page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Gallery page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Gallery page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
          <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
          <node TEXT="3. Attempting to access the Gallery page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
          <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
          <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
          <node TEXT="7. Clicking on a broken image link displays a missing image icon or error." FOLDED="true" POSITION="left" />
          <node TEXT="8. Disabling JavaScript and clicking the GALLERY link does not navigate to the page." FOLDED="true" POSITION="left" />
          <node TEXT="9. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
          <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The Gallery page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Gallery page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Gallery page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Gallery page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Gallery page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Gallery page images are optimized for fast loading and minimal bandwidth usage." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Gallery page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Gallery page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Gallery page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Gallery page content is readable under high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="CONTACT US Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the CONTACT US link in the header navigates the user to the Contact Us page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Contact Us page displays the company's office address, phone numbers, and email." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Contact Us page provides a working Google Maps link to the office location." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Contact Us page contact form accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Contact Us page displays a dropdown for city selection with Karachi as default." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Contact Us page displays all required contact fields and labels." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Contact Us page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Contact Us page allows users to call or email directly via clickable links." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Contact Us page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Contact Us page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
          <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
          <node TEXT="3. Attempting to access the Contact Us page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
          <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
          <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
          <node TEXT="7. Selecting an invalid city from the dropdown displays a validation error." FOLDED="true" POSITION="left" />
          <node TEXT="8. Disabling JavaScript and clicking the CONTACT US link does not navigate to the page." FOLDED="true" POSITION="left" />
          <node TEXT="9. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
          <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The Contact Us page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Contact Us page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Contact Us page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Contact Us page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Contact Us page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Contact Us page images and maps are optimized for fast loading." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Contact Us page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Contact Us page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Contact Us page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Contact Us page content is readable under high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="Home Page Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the Home Page link in the header navigates the user to the main landing page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Home Page displays the hero section with title, subtitle, and background image." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Home Page displays sections for Livestock, Agriculture, and Renewable Energy." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Home Page provides working 'Learn More' buttons for each main section." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Home Page displays a contact form that accepts valid input and submits successfully." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Home Page displays benefits and program information for each business area." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Home Page contact form sends a confirmation message after successful submission." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Home Page is accessible from every other page via the header link." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Home Page content is visible and readable on both desktop and mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Home Page displays footer information and links correctly." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Submitting the contact form with empty required fields displays appropriate error messages." FOLDED="true" POSITION="left" />
          <node TEXT="2. Entering an invalid email address in the contact form prevents submission and shows an error." FOLDED="true" POSITION="left" />
          <node TEXT="3. Attempting to access the Home Page with a broken URL returns a 404 error page." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submitting the contact form with an excessively long message triggers a validation error." FOLDED="true" POSITION="left" />
          <node TEXT="5. Entering special characters in the name fields of the contact form displays a validation warning." FOLDED="true" POSITION="left" />
          <node TEXT="6. Submitting the contact form with an invalid phone number format shows an error message." FOLDED="true" POSITION="left" />
          <node TEXT="7. Clicking on a broken 'Learn More' button displays an error or does not navigate." FOLDED="true" POSITION="left" />
          <node TEXT="8. Disabling JavaScript and clicking the Home Page link does not navigate to the page." FOLDED="true" POSITION="left" />
          <node TEXT="9. Attempting to submit the contact form without accepting privacy terms (if required) blocks submission." FOLDED="true" POSITION="left" />
          <node TEXT="10. Submitting the contact form multiple times rapidly does not create duplicate entries." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The Home Page loads within 2 seconds on a standard broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. The Home Page is responsive and displays correctly on various screen sizes." FOLDED="true" POSITION="left" />
          <node TEXT="3. The Home Page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="4. The Home Page maintains consistent styling with the rest of the website." FOLDED="true" POSITION="left" />
          <node TEXT="5. The Home Page is available 99.9% of the time over a 30-day period." FOLDED="true" POSITION="left" />
          <node TEXT="6. The Home Page images and graphics are optimized for fast loading." FOLDED="true" POSITION="left" />
          <node TEXT="7. The Home Page contact form is protected against spam submissions." FOLDED="true" POSITION="left" />
          <node TEXT="8. The Home Page supports navigation via keyboard shortcuts." FOLDED="true" POSITION="left" />
          <node TEXT="9. The Home Page does not leak sensitive user information in the browser console." FOLDED="true" POSITION="left" />
          <node TEXT="10. The Home Page content is readable under high-contrast mode for accessibility." FOLDED="true" POSITION="left" />
          </node>
        </node>
      </node>
    <node TEXT="Error Page" CREATED="1766583477036" MODIFIED="1766583477036"><richcontent TYPE="NODE"><html><head /><body><img src="screenshot\404_screenshot.png" alt="404 Screenshot" width="500" height="250" /></body></html></richcontent></node></node>
  </map>