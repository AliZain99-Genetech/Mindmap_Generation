<?xml version='1.0' encoding='UTF-8'?>
<map version="1.0.1">
  <node TEXT="Dayzee" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Logo" FOLDED="true">
        <node TEXT="DayZee" LINK="https://dayzee.com/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Navigation" FOLDED="true">
        <node TEXT="About Us" LINK="https://dayzee.com/about/" FOLDED="true">
          <node TEXT="Introduction   Vision" FOLDED="true">
            <node TEXT="DayZee Farms Began with a Bold Idea" FOLDED="true" />
            <node TEXT="Genetics was just the start" FOLDED="true" />
            </node>
          <node TEXT="Key Achievements   Initiatives" FOLDED="true">
            <node TEXT="We launched DayZee Livestock" FOLDED="true" />
            <node TEXT="DayZee Agriculture" FOLDED="true" />
            <node TEXT="Solar installation" FOLDED="true" />
            <node TEXT="Intersection of science and soil" FOLDED="true" />
            </node>
          <node TEXT="UN Sustainable Development Goals Impact" FOLDED="true">
            <node TEXT="SDG 2 – Zero Hunger" FOLDED="true" />
            <node TEXT="SDG 7 – Affordable and Clean Energy" FOLDED="true" />
            <node TEXT="SDG 9 – Industry, Innovation and Infrastructure" FOLDED="true" />
            <node TEXT="SDG 12 – Responsible Consumption and Production" FOLDED="true" />
            <node TEXT="SDG 13 – Climate Action" FOLDED="true" />
            </node>
          <node TEXT="Contact   Inquiry Form" FOLDED="true">
            <node TEXT="First Name" FOLDED="true" />
            <node TEXT="Last Name" FOLDED="true" />
            <node TEXT="Email" FOLDED="true" />
            <node TEXT="Mobile Number" FOLDED="true" />
            <node TEXT="Company Name" FOLDED="true" />
            <node TEXT="Country" FOLDED="true" />
            <node TEXT="Interested In" FOLDED="true" />
            <node TEXT="Message" FOLDED="true" />
            <node TEXT="SUBMIT" FOLDED="true" />
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Livestock" LINK="https://dayzee.com/live-stock/" FOLDED="true">
          <node TEXT="Superior Genetics For Tomorrow" FOLDED="true">
            <node TEXT="Request Semen/Embryo" FOLDED="true">
              <node TEXT="tel:+923314476666" FOLDED="true" />
              </node>
            <node TEXT="Book a Consultation" FOLDED="true">
              <node TEXT="tel:+923314431111" FOLDED="true" />
              </node>
            <node TEXT="Book OPU of your cow now" FOLDED="true">
              <node TEXT="tel:+923314431111" FOLDED="true" />
              </node>
            </node>
          <node TEXT="About Our Genetics" FOLDED="true">
            <node TEXT="Slick Gene Frisien - Special Heat-Resistant, 40+ L Milk" FOLDED="true" />
            <node TEXT="Brahman - 300+ kg at 7 Months, Beef   Bragging Rights!" FOLDED="true" />
            <node TEXT="Beefmaster - Fertility, Gain   Premium Production" FOLDED="true" />
            <node TEXT="Red Angus - Fertility, Calving   Premium Beef" FOLDED="true" />
            </node>
          <node TEXT="Our Services" FOLDED="true">
            <node TEXT="Semen Availability - Climate-adapted, top performing bulls" FOLDED="true" />
            <node TEXT="Embryo Transfer Pregnancies - Elite embryos for local recipients" FOLDED="true" />
            <node TEXT="Pregnant Heifers for Sale - Health certified   pregnancy-verified" FOLDED="true" />
            <node TEXT="Genetics Consultation - Sire selection to embryo strategy" FOLDED="true" />
            </node>
          <node TEXT="Elite Calves Promotion" FOLDED="true">
            <node TEXT="Want 20+ calves from one elite donor cow?" FOLDED="true" />
            <node TEXT="Book OPU Now" FOLDED="true">
              <node TEXT="tel:+92314431111" FOLDED="true" />
              </node>
            </node>
          <node TEXT="Explore Our Genetic Catalogue" FOLDED="true">
            <node TEXT="Brahman Catalogue" FOLDED="true">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_American-Brahmans.pdf.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Slick-Gene Friesian Catalogue" FOLDED="true">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Slick-Gene.pdf.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Beefmaster Catalogue" FOLDED="true">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Beef-Master.pdf.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Red Angus Catalogue" FOLDED="true">
              <node TEXT="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" LINK="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_dayzee.com_wp-content_uploads_2025_09_Red-Angus.pdf.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            </node>
          <node TEXT="Our Global Partners" FOLDED="true" />
          <node TEXT="Get in Touch - Let’s Get Started" FOLDED="true">
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="First Name" FOLDED="true" />
              <node TEXT="Last Name" FOLDED="true" />
              <node TEXT="Email" FOLDED="true" />
              <node TEXT="Mobile Number" FOLDED="true" />
              <node TEXT="Company Name" FOLDED="true" />
              <node TEXT="City (dropdown)" FOLDED="true" />
              <node TEXT="Country" FOLDED="true" />
              <node TEXT="Interested In" FOLDED="true" />
              <node TEXT="Message" FOLDED="true" />
              <node TEXT="Submit" FOLDED="true" />
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Agriculture" LINK="https://dayzee.com/agriculture/" FOLDED="true">
          <node TEXT="Intro: 4,200 Acres Sustainable Agricultural Hub" FOLDED="true" />
          <node TEXT="A New Era of Desert Farming" FOLDED="true">
            <node TEXT="Desert transformation and innovation summary" FOLDED="true" />
            </node>
          <node TEXT="Barren Land Visual Timeline" FOLDED="true">
            <node TEXT="April-2024, March-2025, May-2025 photos" FOLDED="true" />
            </node>
          <node TEXT="Technology In Agriculture" FOLDED="true">
            <node TEXT="Irrigation Systems: Central Pivot technology overview" FOLDED="true" />
            <node TEXT="Mechanized Farm Machinery: Modern equipment" FOLDED="true" />
            <node TEXT="Solar Power Plant: 6MW Solar installation" FOLDED="true" />
            </node>
          <node TEXT="Our Products" FOLDED="true">
            <node TEXT="Alfalfa: Forage crop for dairy and beef cattle" FOLDED="true" />
            <node TEXT="Rhodes Grass: Drought-resistant grass for livestock" FOLDED="true" />
            </node>
          <node TEXT="Our Services" FOLDED="true">
            <node TEXT="Land Development: Transforming barren land" FOLDED="true" />
            <node TEXT="Center Pivot Irrigation Systems: Full service and maintenance" FOLDED="true" />
            <node TEXT="Farm Operations: Precision crop cycle operations" FOLDED="true" />
            <node TEXT="Integrated Farm Management: Planning and execution" FOLDED="true" />
            <node TEXT="Irrigation   Infrastructure Consultancy: Expert solutions" FOLDED="true" />
            </node>
          <node TEXT="Our Global Partners" FOLDED="true">
            <node TEXT="Logos of international agricultural partners" FOLDED="true" />
            </node>
          <node TEXT="Get in touch Let’s Get Started" FOLDED="true">
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="First Name*" FOLDED="true" />
              <node TEXT="Last Name*" FOLDED="true" />
              <node TEXT="Email*" FOLDED="true" />
              <node TEXT="Mobile Number*" FOLDED="true" />
              <node TEXT="Company Name" FOLDED="true" />
              <node TEXT="Country" FOLDED="true" />
              <node TEXT="Interested In" FOLDED="true" />
              <node TEXT="Message" FOLDED="true" />
              <node TEXT="SUBMIT" FOLDED="true" />
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Renewable Energy" LINK="https://dayzee.com/renewable-energy/" FOLDED="true">
          <node TEXT="Hero Section" FOLDED="true">
            <node TEXT="Reducing Carbon Emissions Today – Building A 100% Clean Energy Future" FOLDED="true" />
            </node>
          <node TEXT="Solar Panel Infrastructure" FOLDED="true">
            <node TEXT="Summary: 6MW solar panel system for efficient and sustainable farm energy." FOLDED="true" />
            </node>
          <node TEXT="Our Biogas Plant" FOLDED="true">
            <node TEXT="Summary: Converts organic farm waste to biogas for energy and waste reduction." FOLDED="true" />
            </node>
          <node TEXT="Key Stats" FOLDED="true">
            <node TEXT="500 Delivered Packages" FOLDED="true" />
            <node TEXT="500 Global Shipping" FOLDED="true" />
            <node TEXT="500 Air Freight" FOLDED="true" />
            <node TEXT="500 Happy Customers" FOLDED="true" />
            </node>
          <node TEXT="Corporate Social Responsibility (CSR)" FOLDED="true">
            <node TEXT="Empowering Rural Communities - 150+ jobs created, livelihoods uplifted" FOLDED="true" />
            <node TEXT="Farmer Development - Awareness sessions for modern farming" FOLDED="true" />
            <node TEXT="Environmental Stewardship - Solar and biogas projects for sustainability" FOLDED="true" />
            <node TEXT="Animal Ethics   Welfare - Focus on care, nutrition, ethical practices" FOLDED="true" />
            </node>
          <node TEXT="Get in touch – Let’s Get Started" FOLDED="true">
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="First Name*" FOLDED="true" />
              <node TEXT="Last Name*" FOLDED="true" />
              <node TEXT="Email*" FOLDED="true" />
              <node TEXT="Mobile Number*" FOLDED="true" />
              <node TEXT="Company Name" FOLDED="true" />
              <node TEXT="Location (Dropdown: Karachi)" FOLDED="true" />
              <node TEXT="Country" FOLDED="true" />
              <node TEXT="Interested In" FOLDED="true" />
              <node TEXT="Message" FOLDED="true" />
              <node TEXT="Submit" FOLDED="true" />
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" FOLDED="true">
          <node TEXT="Image Gallery Section" FOLDED="true">
            <node TEXT="Featured Event: DayZee at International Livestock, Dairy, Poultry and Agri Expo 2025" FOLDED="true">
              <node TEXT="Gallery Link" LINK="https://dayzee.com/gallery/dayzee-at-ildpa2025/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_dayzee.com_gallery_dayzee-at-ildpa2025.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Featured Visit: Chinese Delegation at DayZee (Private) Limited" FOLDED="true">
              <node TEXT="Gallery Link" LINK="https://dayzee.com/gallery/chinese-delegation/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_dayzee.com_gallery_chinese-delegation.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            </node>
          <node TEXT="Get In Touch Section" FOLDED="true">
            <node TEXT="Contact and Inquiry Form" FOLDED="true">
              <node TEXT="First Name*" FOLDED="true" />
              <node TEXT="Last Name*" FOLDED="true" />
              <node TEXT="Email*" FOLDED="true" />
              <node TEXT="Mobile Number*" FOLDED="true" />
              <node TEXT="Company Name" FOLDED="true" />
              <node TEXT="City Dropdown (e.g. Karachi)" FOLDED="true" />
              <node TEXT="Country" FOLDED="true" />
              <node TEXT="Interested In" FOLDED="true" />
              <node TEXT="Message" FOLDED="true" />
              <node TEXT="SUBMIT button" FOLDED="true" />
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" FOLDED="true">
          <node TEXT="Contact Information" FOLDED="true">
            <node TEXT="Our Office" FOLDED="true">
              <node TEXT="DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur." FOLDED="true">
                <node TEXT="View on Map" FOLDED="true">
                  <node TEXT="https://maps.app.goo.gl/WstmNjesSmVKyyB66" LINK="https://maps.app.goo.gl/WstmNjesSmVKyyB66" FOLDED="true">
                    <node TEXT="Screenshot Example" FOLDED="true">
                      <richcontent TYPE="NODE">
                        <html>
                          <body>
                            <p>
                              <img src="hyperlink_screenshots/https_maps.app.goo.gl_WstmNjesSmVKyyB66.png" width="500" height="250" />
                              </p>
                            </body>
                          </html>
                        </richcontent>
                      </node>
                    </node>
                  </node>
                </node>
              </node>
            <node TEXT="Call Us" FOLDED="true">
              <node TEXT="0331-443 1111" FOLDED="true">
                <node TEXT="tel:0331 443 1111" FOLDED="true" />
                </node>
              <node TEXT="0331-447 6666" FOLDED="true">
                <node TEXT="tel:0331 447 66 66" FOLDED="true" />
                </node>
              </node>
            <node TEXT="Email Address" FOLDED="true">
              <node TEXT="info@dayzee.com" FOLDED="true">
                <node TEXT="mailto:info@dayzee.com" LINK="mailto:info@dayzee.com" FOLDED="true" />
                </node>
              </node>
            </node>
          <node TEXT="Contact Location Map" FOLDED="true">
            <node TEXT="Embedded map showing DayZee Farms location" FOLDED="true" />
            </node>
          <node TEXT="Get in Touch Form" FOLDED="true">
            <node TEXT="First Name (input)" FOLDED="true" />
            <node TEXT="Last Name (input)" FOLDED="true" />
            <node TEXT="Email (input)" FOLDED="true" />
            <node TEXT="Mobile Number (input)" FOLDED="true" />
            <node TEXT="Company Name (input)" FOLDED="true" />
            <node TEXT="City (dropdown)" FOLDED="true" />
            <node TEXT="Country (input)" FOLDED="true" />
            <node TEXT="Interested In (input)" FOLDED="true" />
            <node TEXT="Message (textarea)" FOLDED="true" />
            <node TEXT="Submit Button" FOLDED="true">
              <node TEXT="SUBMIT" FOLDED="true" />
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Skip to content" LINK="https://dayzee.com/#content" FOLDED="true">
        <node TEXT="Screenshot Example" FOLDED="true">
          <richcontent TYPE="NODE">
            <html>
              <body>
                <p>
                  <img src="hyperlink_screenshots/https_dayzee.com_content.png" width="500" height="250" />
                  </p>
                </body>
              </html>
            </richcontent>
          </node>
        </node>
      </node>
    <node TEXT="Home Page" FOLDED="true">
      <node TEXT="Hero Section" FOLDED="true">
        <node TEXT="Background Image" FOLDED="true" />
        <node TEXT="Title: AGRICULTURE" FOLDED="true" />
        <node TEXT="Subtitle: Innovating Modern Farming" FOLDED="true" />
        </node>
      <node TEXT="Livestock Section" FOLDED="true">
        <node TEXT="Title: LIVESTOCK" FOLDED="true" />
        <node TEXT="Subtitle: In Elite Genetics for Unmatched Livestock Performance" FOLDED="true" />
        <node TEXT="Description" FOLDED="true" />
        <node TEXT="Learn More Button" LINK="https://dayzee.com/live-stock/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_live-stock.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Programs" FOLDED="true">
          <node TEXT="Invitro Fertilization Program" FOLDED="true" />
          <node TEXT="Artificial Insemination Program" FOLDED="true" />
          <node TEXT="Genetics Lab" FOLDED="true" />
          </node>
        </node>
      <node TEXT="Benefits Section" FOLDED="true">
        <node TEXT="Heat Tolerance" FOLDED="true" />
        <node TEXT="Fertility   Productivity" FOLDED="true" />
        <node TEXT="Long-Term Profitability" FOLDED="true" />
        </node>
      <node TEXT="Agriculture Section" FOLDED="true">
        <node TEXT="Title: Agriculture" FOLDED="true" />
        <node TEXT="Subtitle: Turning Barren Land into Agricultural Gold" FOLDED="true" />
        <node TEXT="Description" FOLDED="true" />
        <node TEXT="Learn More Button" LINK="https://dayzee.com/agriculture/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_agriculture.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Programs" FOLDED="true">
          <node TEXT="Pivot Irrigation" FOLDED="true" />
          <node TEXT="Mechanized Farming" FOLDED="true" />
          <node TEXT="Premium Animal Fodder" FOLDED="true" />
          </node>
        </node>
      <node TEXT="Renewable Energy Section" FOLDED="true">
        <node TEXT="Title: Renewable Energy" FOLDED="true" />
        <node TEXT="Subtitle: Sustainable and Smart Agriculture" FOLDED="true" />
        <node TEXT="Explore Our Sustainability Button" LINK="https://dayzee.com/renewable-energy/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_renewable-energy.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Programs" FOLDED="true">
          <node TEXT="Solar Powered Future" FOLDED="true" />
          <node TEXT="Biogas To Energy" FOLDED="true" />
          </node>
        </node>
      <node TEXT="Contact Section" FOLDED="true">
        <node TEXT="Get in touch Let’s Get Started" FOLDED="true" />
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="First Name*" FOLDED="true" />
          <node TEXT="Last Name*" FOLDED="true" />
          <node TEXT="Email*" FOLDED="true" />
          <node TEXT="Mobile Number*" FOLDED="true" />
          <node TEXT="Company Name" FOLDED="true" />
          <node TEXT="City (Dropdown, e.g., Karachi)" FOLDED="true" />
          <node TEXT="Country" FOLDED="true" />
          <node TEXT="Interested In" FOLDED="true" />
          <node TEXT="Message" FOLDED="true" />
          <node TEXT="Submit Button" FOLDED="true" />
          </node>
        </node>
      </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="About Company" FOLDED="true">
        <node TEXT="Company Description" FOLDED="true" />
        </node>
      <node TEXT="Company Links" FOLDED="true">
        <node TEXT="Home" LINK="https://dayzee.com/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Services" LINK="https://dayzee.com/service/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_service.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_gallery.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Quick Links" FOLDED="true">
        <node TEXT="About Us" LINK="https://dayzee.com/about/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_about.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_contact-us.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="FAQs" LINK="https://dayzee.com/faqs" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_dayzee.com_faqs.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Follow us at" FOLDED="true">
        <node TEXT="Facebook" LINK="https://www.facebook.com/dayzeepvtltd" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_www.facebook.com_dayzeepvtltd.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Tik Tok" LINK="https://www.tiktok.com/@dayzee.pvt.ltd" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_www.tiktok.com_dayzee.pvt.ltd.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Instagram" LINK="https://www.instagram.com/dayzee_pvt_ltd/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_www.instagram.com_dayzee_pvt_ltd.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Youtube" LINK="https://www.youtube.com/@DayZee_Pvt_Ltd" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_www.youtube.com_DayZee_Pvt_Ltd.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Copyright" FOLDED="true">
        <node TEXT="Copyright © 2025 DayZee. All Rights Reserved" FOLDED="true" />
        </node>
      </node>
    <node TEXT="Test Cases" POSITION="left" FOLDED="true">
      <node TEXT="ABOUT US Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Verify that clicking the ABOUT US link in the header navigates the user to the About Us page." FOLDED="true" POSITION="left" />
          <node TEXT="2. Confirm that the About Us page loads all main sections, including Introduction, Vision, and Key Achievements." FOLDED="true" POSITION="left" />
          <node TEXT="3. Ensure that the UN Sustainable Development Goals Impact section is visible and displays all listed SDGs." FOLDED="true" POSITION="left" />
          <node TEXT="4. Validate that the Contact &amp; Inquiry Form is present and all input fields are displayed correctly." FOLDED="true" POSITION="left" />
          <node TEXT="5. Test that submitting the Contact &amp; Inquiry Form with valid data shows a success message." FOLDED="true" POSITION="left" />
          <node TEXT="6. Check that the page title and meta description are relevant to About Us." FOLDED="true" POSITION="left" />
          <node TEXT="7. Ensure that all images and graphics on the About Us page load without errors." FOLDED="true" POSITION="left" />
          <node TEXT="8. Verify that the navigation menu remains accessible after navigating to the About Us page." FOLDED="true" POSITION="left" />
          <node TEXT="9. Confirm that the About Us page is accessible via direct URL entry in the browser." FOLDED="true" POSITION="left" />
          <node TEXT="10. Test that the browser back button returns the user to the previous page from About Us." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempt to submit the Contact &amp; Inquiry Form with empty required fields and verify that validation errors are shown." FOLDED="true" POSITION="left" />
          <node TEXT="2. Enter an invalid email address in the form and ensure an appropriate error message is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="3. Input special characters in the First Name field and check for validation errors." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submit the form with an excessively long message and verify that the form handles it gracefully." FOLDED="true" POSITION="left" />
          <node TEXT="5. Try to access the About Us page with a malformed URL and confirm a 404 or error page is shown." FOLDED="true" POSITION="left" />
          <node TEXT="6. Attempt to upload a file in the message field (if not supported) and ensure the form rejects it." FOLDED="true" POSITION="left" />
          <node TEXT="7. Submit the form with a missing country selection and verify that an error is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="8. Test form submission with a script injection attempt and ensure it is sanitized." FOLDED="true" POSITION="left" />
          <node TEXT="9. Try to submit the form multiple times rapidly and check for duplicate prevention." FOLDED="true" POSITION="left" />
          <node TEXT="10. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Measure the load time of the About Us page to ensure it loads within 2 seconds on a standard connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. Verify that the About Us page is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="3. Check that all text on the About Us page is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="4. Test the accessibility of the About Us page using a screen reader." FOLDED="true" POSITION="left" />
          <node TEXT="5. Confirm that the About Us page meets WCAG 2.1 AA accessibility standards." FOLDED="true" POSITION="left" />
          <node TEXT="6. Simulate a slow network and ensure the About Us page content remains usable." FOLDED="true" POSITION="left" />
          <node TEXT="7. Test the About Us page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency." FOLDED="true" POSITION="left" />
          <node TEXT="8. Verify that the About Us page does not have broken links or missing images." FOLDED="true" POSITION="left" />
          <node TEXT="9. Check that the Contact &amp; Inquiry Form is protected against spam submissions (e.g., CAPTCHA or rate limiting)." FOLDED="true" POSITION="left" />
          <node TEXT="10. Ensure that the About Us page is indexed by search engines and appears in search results." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="LIVESTOCK Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Verify that clicking the LIVESTOCK link in the header navigates to the Livestock page." FOLDED="true" POSITION="left" />
          <node TEXT="2. Confirm that the Livestock page displays the Superior Genetics For Tomorrow section." FOLDED="true" POSITION="left" />
          <node TEXT="3. Ensure that the Request Semen/Embryo and Book a Consultation phone links are clickable and initiate a call." FOLDED="true" POSITION="left" />
          <node TEXT="4. Validate that the Explore Our Genetic Catalogue section lists all available catalogues with working links." FOLDED="true" POSITION="left" />
          <node TEXT="5. Test that the Get in Touch form is present and all fields are visible." FOLDED="true" POSITION="left" />
          <node TEXT="6. Submit the Get in Touch form with valid data and verify a success message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="7. Check that the Our Services section lists all services with correct descriptions." FOLDED="true" POSITION="left" />
          <node TEXT="8. Ensure that the Elite Calves Promotion section is visible and the Book OPU Now link works." FOLDED="true" POSITION="left" />
          <node TEXT="9. Verify that the Livestock page is accessible via direct URL entry." FOLDED="true" POSITION="left" />
          <node TEXT="10. Confirm that the navigation menu remains functional after navigating to the Livestock page." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempt to submit the Get in Touch form with empty required fields and verify validation errors are shown." FOLDED="true" POSITION="left" />
          <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submit the form with an excessively long company name and verify proper handling." FOLDED="true" POSITION="left" />
          <node TEXT="5. Try to access a non-existent catalogue link and confirm a 404 or error page is shown." FOLDED="true" POSITION="left" />
          <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized." FOLDED="true" POSITION="left" />
          <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention." FOLDED="true" POSITION="left" />
          <node TEXT="8. Try to click the phone links on a desktop browser and verify appropriate behavior." FOLDED="true" POSITION="left" />
          <node TEXT="9. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided." FOLDED="true" POSITION="left" />
          <node TEXT="10. Attempt to submit the form with a missing city selection and verify an error is displayed." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Measure the load time of the Livestock page to ensure it loads within 2 seconds on a standard connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. Verify that the Livestock page is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="3. Check that all text and buttons on the Livestock page are readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="4. Test the accessibility of the Livestock page using a screen reader." FOLDED="true" POSITION="left" />
          <node TEXT="5. Confirm that the Livestock page meets WCAG 2.1 AA accessibility standards." FOLDED="true" POSITION="left" />
          <node TEXT="6. Simulate a slow network and ensure the Livestock page content remains usable." FOLDED="true" POSITION="left" />
          <node TEXT="7. Test the Livestock page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency." FOLDED="true" POSITION="left" />
          <node TEXT="8. Verify that all catalogue PDF links are downloadable and not broken." FOLDED="true" POSITION="left" />
          <node TEXT="9. Check that the Get in Touch form is protected against spam submissions (e.g., CAPTCHA or rate limiting)." FOLDED="true" POSITION="left" />
          <node TEXT="10. Ensure that the Livestock page is indexed by search engines and appears in search results." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="AGRICULTURE Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Verify that clicking the AGRICULTURE link in the header navigates to the Agriculture page." FOLDED="true" POSITION="left" />
          <node TEXT="2. Confirm that the Agriculture page displays the Intro and A New Era of Desert Farming sections." FOLDED="true" POSITION="left" />
          <node TEXT="3. Ensure that the Barren Land Visual Timeline is visible and shows all listed photos." FOLDED="true" POSITION="left" />
          <node TEXT="4. Validate that the Technology In Agriculture section lists all technologies with descriptions." FOLDED="true" POSITION="left" />
          <node TEXT="5. Test that the Our Products section displays Alfalfa and Rhodes Grass with details." FOLDED="true" POSITION="left" />
          <node TEXT="6. Check that the Our Services section lists all services with correct descriptions." FOLDED="true" POSITION="left" />
          <node TEXT="7. Ensure that the Our Global Partners section displays partner logos." FOLDED="true" POSITION="left" />
          <node TEXT="8. Verify that the Get in Touch form is present and all fields are visible." FOLDED="true" POSITION="left" />
          <node TEXT="9. Submit the Get in Touch form with valid data and verify a success message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="10. Confirm that the navigation menu remains functional after navigating to the Agriculture page." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempt to submit the Get in Touch form with empty required fields and verify validation errors are shown." FOLDED="true" POSITION="left" />
          <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submit the form with an excessively long message and verify proper handling." FOLDED="true" POSITION="left" />
          <node TEXT="5. Try to access a non-existent product link and confirm a 404 or error page is shown." FOLDED="true" POSITION="left" />
          <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized." FOLDED="true" POSITION="left" />
          <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention." FOLDED="true" POSITION="left" />
          <node TEXT="8. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided." FOLDED="true" POSITION="left" />
          <node TEXT="9. Attempt to submit the form with a missing country selection and verify an error is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="10. Try to upload a file in the message field (if not supported) and ensure the form rejects it." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Measure the load time of the Agriculture page to ensure it loads within 2 seconds on a standard connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. Verify that the Agriculture page is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="3. Check that all text and images on the Agriculture page are readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="4. Test the accessibility of the Agriculture page using a screen reader." FOLDED="true" POSITION="left" />
          <node TEXT="5. Confirm that the Agriculture page meets WCAG 2.1 AA accessibility standards." FOLDED="true" POSITION="left" />
          <node TEXT="6. Simulate a slow network and ensure the Agriculture page content remains usable." FOLDED="true" POSITION="left" />
          <node TEXT="7. Test the Agriculture page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency." FOLDED="true" POSITION="left" />
          <node TEXT="8. Verify that all product and service links are not broken." FOLDED="true" POSITION="left" />
          <node TEXT="9. Check that the Get in Touch form is protected against spam submissions (e.g., CAPTCHA or rate limiting)." FOLDED="true" POSITION="left" />
          <node TEXT="10. Ensure that the Agriculture page is indexed by search engines and appears in search results." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="RENEWABLE ENERGY Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Verify that clicking the RENEWABLE ENERGY link in the header navigates to the Renewable Energy page." FOLDED="true" POSITION="left" />
          <node TEXT="2. Confirm that the Hero Section displays the correct title and subtitle." FOLDED="true" POSITION="left" />
          <node TEXT="3. Ensure that the Solar Panel Infrastructure section is visible and contains the summary." FOLDED="true" POSITION="left" />
          <node TEXT="4. Validate that the Our Biogas Plant section is present and displays the correct information." FOLDED="true" POSITION="left" />
          <node TEXT="5. Check that the Key Stats section lists all statistics accurately." FOLDED="true" POSITION="left" />
          <node TEXT="6. Ensure that the Corporate Social Responsibility section lists all initiatives." FOLDED="true" POSITION="left" />
          <node TEXT="7. Verify that the Get in Touch form is present and all fields are visible." FOLDED="true" POSITION="left" />
          <node TEXT="8. Submit the Get in Touch form with valid data and verify a success message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="9. Confirm that the navigation menu remains functional after navigating to the Renewable Energy page." FOLDED="true" POSITION="left" />
          <node TEXT="10. Verify that the Renewable Energy page is accessible via direct URL entry." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempt to submit the Get in Touch form with empty required fields and verify validation errors are shown." FOLDED="true" POSITION="left" />
          <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submit the form with an excessively long message and verify proper handling." FOLDED="true" POSITION="left" />
          <node TEXT="5. Try to access a non-existent section link and confirm a 404 or error page is shown." FOLDED="true" POSITION="left" />
          <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized." FOLDED="true" POSITION="left" />
          <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention." FOLDED="true" POSITION="left" />
          <node TEXT="8. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided." FOLDED="true" POSITION="left" />
          <node TEXT="9. Attempt to submit the form with a missing location selection and verify an error is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="10. Try to upload a file in the message field (if not supported) and ensure the form rejects it." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Measure the load time of the Renewable Energy page to ensure it loads within 2 seconds on a standard connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. Verify that the Renewable Energy page is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="3. Check that all text and images on the Renewable Energy page are readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="4. Test the accessibility of the Renewable Energy page using a screen reader." FOLDED="true" POSITION="left" />
          <node TEXT="5. Confirm that the Renewable Energy page meets WCAG 2.1 AA accessibility standards." FOLDED="true" POSITION="left" />
          <node TEXT="6. Simulate a slow network and ensure the Renewable Energy page content remains usable." FOLDED="true" POSITION="left" />
          <node TEXT="7. Test the Renewable Energy page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency." FOLDED="true" POSITION="left" />
          <node TEXT="8. Verify that all section links are not broken." FOLDED="true" POSITION="left" />
          <node TEXT="9. Check that the Get in Touch form is protected against spam submissions (e.g., CAPTCHA or rate limiting)." FOLDED="true" POSITION="left" />
          <node TEXT="10. Ensure that the Renewable Energy page is indexed by search engines and appears in search results." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="GALLERY Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Verify that clicking the GALLERY link in the header navigates to the Gallery page." FOLDED="true" POSITION="left" />
          <node TEXT="2. Confirm that the Image Gallery Section displays featured events and visits." FOLDED="true" POSITION="left" />
          <node TEXT="3. Ensure that the gallery images are visible and load correctly." FOLDED="true" POSITION="left" />
          <node TEXT="4. Validate that clicking on a gallery image opens it in a larger view or lightbox." FOLDED="true" POSITION="left" />
          <node TEXT="5. Check that the Gallery Link for each featured event navigates to the correct gallery page." FOLDED="true" POSITION="left" />
          <node TEXT="6. Ensure that the Get In Touch Section is present and all form fields are visible." FOLDED="true" POSITION="left" />
          <node TEXT="7. Submit the Contact and Inquiry Form with valid data and verify a success message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="8. Verify that the navigation menu remains functional after navigating to the Gallery page." FOLDED="true" POSITION="left" />
          <node TEXT="9. Confirm that the Gallery page is accessible via direct URL entry." FOLDED="true" POSITION="left" />
          <node TEXT="10. Test that the browser back button returns the user to the previous page from Gallery." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempt to submit the Contact and Inquiry Form with empty required fields and verify validation errors are shown." FOLDED="true" POSITION="left" />
          <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submit the form with an excessively long message and verify proper handling." FOLDED="true" POSITION="left" />
          <node TEXT="5. Try to access a non-existent gallery link and confirm a 404 or error page is shown." FOLDED="true" POSITION="left" />
          <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized." FOLDED="true" POSITION="left" />
          <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention." FOLDED="true" POSITION="left" />
          <node TEXT="8. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided." FOLDED="true" POSITION="left" />
          <node TEXT="9. Attempt to submit the form with a missing city selection and verify an error is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="10. Try to upload a file in the message field (if not supported) and ensure the form rejects it." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Measure the load time of the Gallery page to ensure it loads within 2 seconds on a standard connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. Verify that the Gallery page is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="3. Check that all images and text on the Gallery page are readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="4. Test the accessibility of the Gallery page using a screen reader." FOLDED="true" POSITION="left" />
          <node TEXT="5. Confirm that the Gallery page meets WCAG 2.1 AA accessibility standards." FOLDED="true" POSITION="left" />
          <node TEXT="6. Simulate a slow network and ensure the Gallery page content remains usable." FOLDED="true" POSITION="left" />
          <node TEXT="7. Test the Gallery page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency." FOLDED="true" POSITION="left" />
          <node TEXT="8. Verify that all gallery image links are not broken." FOLDED="true" POSITION="left" />
          <node TEXT="9. Check that the Contact and Inquiry Form is protected against spam submissions (e.g., CAPTCHA or rate limiting)." FOLDED="true" POSITION="left" />
          <node TEXT="10. Ensure that the Gallery page is indexed by search engines and appears in search results." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="CONTACT US Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Verify that clicking the CONTACT US link in the header navigates to the Contact Us page." FOLDED="true" POSITION="left" />
          <node TEXT="2. Confirm that the Contact Information section displays office address, phone numbers, and email." FOLDED="true" POSITION="left" />
          <node TEXT="3. Ensure that the View on Map link opens the correct location in a new tab or map application." FOLDED="true" POSITION="left" />
          <node TEXT="4. Validate that the Call Us phone numbers are clickable and initiate a call on mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="5. Check that the Email Address is a mailto link and opens the default email client." FOLDED="true" POSITION="left" />
          <node TEXT="6. Ensure that the Contact Location Map is visible and displays the correct location." FOLDED="true" POSITION="left" />
          <node TEXT="7. Verify that the Get in Touch Form is present and all fields are visible." FOLDED="true" POSITION="left" />
          <node TEXT="8. Submit the Get in Touch Form with valid data and verify a success message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="9. Confirm that the navigation menu remains functional after navigating to the Contact Us page." FOLDED="true" POSITION="left" />
          <node TEXT="10. Verify that the Contact Us page is accessible via direct URL entry." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempt to submit the Get in Touch Form with empty required fields and verify validation errors are shown." FOLDED="true" POSITION="left" />
          <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submit the form with an excessively long message and verify proper handling." FOLDED="true" POSITION="left" />
          <node TEXT="5. Try to access a non-existent map link and confirm a 404 or error page is shown." FOLDED="true" POSITION="left" />
          <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized." FOLDED="true" POSITION="left" />
          <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention." FOLDED="true" POSITION="left" />
          <node TEXT="8. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided." FOLDED="true" POSITION="left" />
          <node TEXT="9. Attempt to submit the form with a missing city selection and verify an error is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="10. Try to upload a file in the message field (if not supported) and ensure the form rejects it." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Measure the load time of the Contact Us page to ensure it loads within 2 seconds on a standard connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. Verify that the Contact Us page is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="3. Check that all text and map elements on the Contact Us page are readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="4. Test the accessibility of the Contact Us page using a screen reader." FOLDED="true" POSITION="left" />
          <node TEXT="5. Confirm that the Contact Us page meets WCAG 2.1 AA accessibility standards." FOLDED="true" POSITION="left" />
          <node TEXT="6. Simulate a slow network and ensure the Contact Us page content remains usable." FOLDED="true" POSITION="left" />
          <node TEXT="7. Test the Contact Us page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency." FOLDED="true" POSITION="left" />
          <node TEXT="8. Verify that all contact links (phone, email, map) are not broken." FOLDED="true" POSITION="left" />
          <node TEXT="9. Check that the Get in Touch Form is protected against spam submissions (e.g., CAPTCHA or rate limiting)." FOLDED="true" POSITION="left" />
          <node TEXT="10. Ensure that the Contact Us page is indexed by search engines and appears in search results." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="home Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Verify that clicking the home link in the header navigates to the Home page." FOLDED="true" POSITION="left" />
          <node TEXT="2. Confirm that the Hero Section displays the correct background image, title, and subtitle." FOLDED="true" POSITION="left" />
          <node TEXT="3. Ensure that the Livestock Section is visible and displays all relevant information." FOLDED="true" POSITION="left" />
          <node TEXT="4. Validate that the Learn More buttons in each section navigate to the correct pages." FOLDED="true" POSITION="left" />
          <node TEXT="5. Check that the Benefits Section lists all benefits with correct descriptions." FOLDED="true" POSITION="left" />
          <node TEXT="6. Ensure that the Agriculture Section is present and displays all programs." FOLDED="true" POSITION="left" />
          <node TEXT="7. Verify that the Renewable Energy Section is visible and the Explore Our Sustainability button works." FOLDED="true" POSITION="left" />
          <node TEXT="8. Confirm that the Contact Section is present and the Contact Form is visible." FOLDED="true" POSITION="left" />
          <node TEXT="9. Submit the Contact Form with valid data and verify a success message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="10. Verify that the navigation menu remains functional after navigating to the Home page." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempt to submit the Contact Form with empty required fields and verify validation errors are shown." FOLDED="true" POSITION="left" />
          <node TEXT="2. Enter an invalid email address in the form and ensure an error message is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="3. Input non-numeric characters in the Mobile Number field and check for validation errors." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submit the form with an excessively long message and verify proper handling." FOLDED="true" POSITION="left" />
          <node TEXT="5. Try to access a non-existent section link and confirm a 404 or error page is shown." FOLDED="true" POSITION="left" />
          <node TEXT="6. Attempt to submit the form with a script injection in the message field and ensure it is sanitized." FOLDED="true" POSITION="left" />
          <node TEXT="7. Submit the form multiple times rapidly and check for duplicate prevention." FOLDED="true" POSITION="left" />
          <node TEXT="8. Disable JavaScript and attempt to use the form, verifying that a warning or fallback is provided." FOLDED="true" POSITION="left" />
          <node TEXT="9. Attempt to submit the form with a missing city selection and verify an error is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="10. Try to upload a file in the message field (if not supported) and ensure the form rejects it." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Measure the load time of the Home page to ensure it loads within 2 seconds on a standard connection." FOLDED="true" POSITION="left" />
          <node TEXT="2. Verify that the Home page is responsive and displays correctly on mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="3. Check that all text and images on the Home page are readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="4. Test the accessibility of the Home page using a screen reader." FOLDED="true" POSITION="left" />
          <node TEXT="5. Confirm that the Home page meets WCAG 2.1 AA accessibility standards." FOLDED="true" POSITION="left" />
          <node TEXT="6. Simulate a slow network and ensure the Home page content remains usable." FOLDED="true" POSITION="left" />
          <node TEXT="7. Test the Home page in multiple browsers (Chrome, Firefox, Safari, Edge) for consistency." FOLDED="true" POSITION="left" />
          <node TEXT="8. Verify that all section links and buttons are not broken." FOLDED="true" POSITION="left" />
          <node TEXT="9. Check that the Contact Form is protected against spam submissions (e.g., CAPTCHA or rate limiting)." FOLDED="true" POSITION="left" />
          <node TEXT="10. Ensure that the Home page is indexed by search engines and appears in search results." FOLDED="true" POSITION="left" />
          </node>
        </node>
      </node>
    </node>
  </map>
