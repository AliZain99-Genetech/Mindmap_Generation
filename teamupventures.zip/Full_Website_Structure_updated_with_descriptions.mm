<?xml version='1.0' encoding='UTF-8'?>
<map version="1.0.1">
  <node TEXT="Home - Teamup Ventures" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Navigation Links" FOLDED="true">
        <node TEXT="Home" LINK="https://teamupventures.com/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="The Pakistan Story" LINK="https://teamupventures.com/pakistan-story/" FOLDED="true">
          <node TEXT="Key Economic Facts" FOLDED="true">
            <node TEXT="Population: 5th largest, 225M (132.6M below 30)" FOLDED="true"/>
            <node TEXT="Nominal GDP (2021): $297B" FOLDED="true"/>
            <node TEXT="Net Exports (2020): $22.5B" FOLDED="true"/>
            <node TEXT="Inflation: 8.2%" FOLDED="true"/>
            <node TEXT="Real GDP Growth Rate (2021F): 4.7%" FOLDED="true"/>
            <node TEXT="Unemployment Rate: 4.5%" FOLDED="true"/>
            <node TEXT="Remittances (2021): $29.4B" FOLDED="true"/>
            <node TEXT="GDP per Capita, PPP (2021F): $5230" FOLDED="true"/>
          </node>
          <node TEXT="Demographic Facts" FOLDED="true">
            <node TEXT="Population Growth: 1980-2030 trend, 78M to 262M" FOLDED="true"/>
            <node TEXT="GDP Growth: 1980-2030 trend, $31B to $776B" FOLDED="true"/>
          </node>
          <node TEXT="Startup Ecosystem Overview" FOLDED="true">
            <node TEXT="Startup funding and deals in Pakistan (2015-2021)" FOLDED="true"/>
            <node TEXT="Facts about Pakistan’s startup ecosystem" FOLDED="true">
              <node TEXT="$578M+ raised by Pakistani startups since 2015" FOLDED="true"/>
              <node TEXT="$259M+ funding raised in 2021" FOLDED="true"/>
              <node TEXT="700+ startups launched till date" FOLDED="true"/>
              <node TEXT="83 incubators and accelerators" FOLDED="true"/>
              <node TEXT="Up 28 places in World Bank’s ease of doing business (2020)" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Rapidly Growing Digital Infrastructure" FOLDED="true">
            <node TEXT="Growth in internet connectivity offers startup opportunities" FOLDED="true"/>
            <node TEXT="Notes on digital transformation and inclusion" FOLDED="true"/>
            <node TEXT="Exponential connectivity growth: 103M broadband subscribers" FOLDED="true"/>
            <node TEXT="98% of households own a mobile phone" FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_pakistan-story.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Our Team" LINK="https://teamupventures.com/#our-team" FOLDED="true">
          <node TEXT="The Pakistan Story" FOLDED="true">
            <node TEXT="Section summary: Pakistanapos;s digital era and investment opportunity" FOLDED="true"/>
            <node TEXT="READ MORE" FOLDED="true">
              <node TEXT="Link" LINK="https://teamupventures.com/pakistan-story/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_pakistan-story.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Scrapboard - Blog   News Highlights" FOLDED="true">
            <node TEXT="The Era of VCs and Boom of Startups" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/the-era-of-vcs-and-boom-of-start-ups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_the-era-of-vcs-and-boom-of-start-ups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="To Survive Pakistanapos;s COVID Pandemic, Grocery Stores Go Online" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/to-survive-pakistans-covid-pandemic-grocery-stores-go-online/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_to-survive-pakistans-covid-pandemic-grocery-stores-go-online.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Clicky.pk attracts $700,000 in pre-series A funding round" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/clicky-pk-attracts-700000-in-pre-series-a-funding-round/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_clicky-pk-attracts-700000-in-pre-series-a-funding-round.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Sehat Kahani Raises $1 Million Pre-Series A for Telemedicine Network" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-sehat-kahani-raises-1-million-pre-series-a-to-grow-its-telemedicine-network/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-sehat-kahani-raises-1-million-pre-series-a-to-grow-its-telemedicine-network.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Startup Challenges: The Way Out" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/startup-challenges-the-way-out/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_startup-challenges-the-way-out.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Remotebase Raises $1.4 Million Led by Indus Valley Capital" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pak-tech-startup-remotebase-raises-1-4-million-led-by-indus-valley-capital/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pak-tech-startup-remotebase-raises-1-4-million-led-by-indus-valley-capital.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Shopsy Introduces Voice Search for Customers" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/islamabad-based-startup-called-shopsy-introduces-voice-search-for-its-customers/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_islamabad-based-startup-called-shopsy-introduces-voice-search-for-its-customers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="PayPro Receives a Grant of Rs 7.4 Million from USAID and SMEA" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-fintech-startup-called-paypro-receives-a-grant-of-rs-7-4-million-from-usaid-and-smea/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-fintech-startup-called-paypro-receives-a-grant-of-rs-7-4-million-from-usaid-and-smea.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Local Startup Using AI to Detect COVID-19" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/local-startup-is-using-ai-to-detect-covid-19/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_local-startup-is-using-ai-to-detect-covid-19.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="HumWell: All-Inclusive Telehealth Service" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/humwell-comes-to-rescue-with-an-all-inclusive-telehealth-service/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_humwell-comes-to-rescue-with-an-all-inclusive-telehealth-service.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="E-commerce Marketing Tool Launched by Pakistani Entrepreneur" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-first-e-commerce-marketing-tool-launched-by-pakistani-entrepreneur-to-make-e-commerce-more-competitive/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-first-e-commerce-marketing-tool-launched-by-pakistani-entrepreneur-to-make-e-commerce-more-competitive.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Pakistani Startups Break Records in 2020 Despite Economic Slowdown" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-startups-break-records-in-2020-despite-global-economic-slowdown/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-startups-break-records-in-2020-despite-global-economic-slowdown.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Truck It In Raises $1.5 Million Pre-Seed for Trucking Marketplace" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-truck-it-in-raises-1-5-million-pre-seed-for-its-trucking-marketplace/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-truck-it-in-raises-1-5-million-pre-seed-for-its-trucking-marketplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Edkasa Raises $320,000 Pre-Seed for Exam Prep App" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-edtech-startup-edkasa-raises-320000-pre-seed-by-launching-an-exam-prep-app-for-students/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-edtech-startup-edkasa-raises-320000-pre-seed-by-launching-an-exam-prep-app-for-students.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Pakistan Launches Growth Funds for Startups" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistan-launches-growth-funds-for-startups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistan-launches-growth-funds-for-startups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Bayfikr – User-Friendly Fin-Tech App for Overseas Pakistanis" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/bayfikr-a-user-friendly-fin-tech-app-making-payments-in-pakistan-easier-for-overseas-pakistanis/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_bayfikr-a-user-friendly-fin-tech-app-making-payments-in-pakistan-easier-for-overseas-pakistanis.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Fintech SadaPay Raises $7.2 Million Seed Round" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/exclusive-pakistani-fintech-sadapay-raises-7-2-million-in-countrys-largest-seed-round/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_exclusive-pakistani-fintech-sadapay-raises-7-2-million-in-countrys-largest-seed-round.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Pakistani Startups Best Year Yet With Over $65 Million in Funding" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/despite-a-pandemic-pakistani-startups-had-their-best-year-yet-with-over-65-million-in-funding/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_despite-a-pandemic-pakistani-startups-had-their-best-year-yet-with-over-65-million-in-funding.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="NIC Welcomes Its 10th Cohort of Startups" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/nic-welcomes-its-10th-cohort-of-startups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_nic-welcomes-its-10th-cohort-of-startups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="For a successful startup ecosystem, Pakistan needs to learn to celebrate failure" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/for-a-successful-startup-ecosystem-pakistan-needs-to-learn-to-celebrate-failure/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_for-a-successful-startup-ecosystem-pakistan-needs-to-learn-to-celebrate-failure.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Contact   Careers" FOLDED="true">
            <node TEXT="Contact introduction and invitation to reach out" FOLDED="true"/>
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="Your Name*" FOLDED="true"/>
              <node TEXT="Your Email*" FOLDED="true"/>
              <node TEXT="Company*" FOLDED="true"/>
              <node TEXT="Subject*" FOLDED="true"/>
              <node TEXT="Your Message*" FOLDED="true"/>
              <node TEXT="GET IN TOUCH" FOLDED="true">
                <node TEXT="Button" LINK="https://teamupventures.com/#contact-careers" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_contact-careers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="National Incubation Centre" LINK="https://nicpakistan.pk/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_nicpakistan.pk.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Scrapboard" LINK="https://teamupventures.com/#scrap-board" FOLDED="true">
          <node TEXT="Blog   News Highlights" FOLDED="true">
            <node TEXT="The Era of VCs and Boom of Startups" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/the-era-of-vcs-and-boom-of-start-ups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_the-era-of-vcs-and-boom-of-start-ups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="To Survive Pakistanapos;s COVID Pandemic, Grocery Stores Go Online" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/to-survive-pakistans-covid-pandemic-grocery-stores-go-online/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_to-survive-pakistans-covid-pandemic-grocery-stores-go-online.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Clicky.pk attracts $700,000 in pre-series A funding round" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/clicky-pk-attracts-700000-in-pre-series-a-funding-round/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_clicky-pk-attracts-700000-in-pre-series-a-funding-round.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Sehat Kahani Raises $1 Million to Grow its Telemedicine Network" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-sehat-kahani-raises-1-million-pre-series-a-to-grow-its-telemedicine-network/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-sehat-kahani-raises-1-million-pre-series-a-to-grow-its-telemedicine-network.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Startup Challenges: The Way Out" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/startup-challenges-the-way-out/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_startup-challenges-the-way-out.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Remotebase Raises $1.4 Million Led by Indus Valley Capital" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pak-tech-startup-remotebase-raises-1-4-million-led-by-indus-valley-capital/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pak-tech-startup-remotebase-raises-1-4-million-led-by-indus-valley-capital.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Shopsy Introduces Voice Search for Customers" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/islamabad-based-startup-called-shopsy-introduces-voice-search-for-its-customers/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_islamabad-based-startup-called-shopsy-introduces-voice-search-for-its-customers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="PayPro Receives Rs 7.4 Million Grant from USAID and SMEA" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-fintech-startup-called-paypro-receives-a-grant-of-rs-7-4-million-from-usaid-and-smea/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-fintech-startup-called-paypro-receives-a-grant-of-rs-7-4-million-from-usaid-and-smea.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Startup Using AI to Detect COVID-19" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/local-startup-is-using-ai-to-detect-covid-19/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_local-startup-is-using-ai-to-detect-covid-19.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="HumWell Comes To Rescue with Telehealth Service" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/humwell-comes-to-rescue-with-an-all-inclusive-telehealth-service/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_humwell-comes-to-rescue-with-an-all-inclusive-telehealth-service.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="E-commerce Marketing Tool Launched in Pakistan" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-first-e-commerce-marketing-tool-launched-by-pakistani-entrepreneur-to-make-e-commerce-more-competitive/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-first-e-commerce-marketing-tool-launched-by-pakistani-entrepreneur-to-make-e-commerce-more-competitive.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Pakistani Startups Break Records in 2020" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-startups-break-records-in-2020-despite-global-economic-slowdown/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-startups-break-records-in-2020-despite-global-economic-slowdown.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Truck It In Raises $1.5 Million Pre-Seed for Trucking Marketplace" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-truck-it-in-raises-1-5-million-pre-seed-for-its-trucking-marketplace/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-truck-it-in-raises-1-5-million-pre-seed-for-its-trucking-marketplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Edkasa Raises $320,000 Pre-Seed for Exam Prep App" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-edtech-startup-edkasa-raises-320000-pre-seed-by-launching-an-exam-prep-app-for-students/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-edtech-startup-edkasa-raises-320000-pre-seed-by-launching-an-exam-prep-app-for-students.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Pakistan Launches Growth Funds for Startups" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistan-launches-growth-funds-for-startups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistan-launches-growth-funds-for-startups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Bayfikr – Fin-tech App for Overseas Pakistanis" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/bayfikr-a-user-friendly-fin-tech-app-making-payments-in-pakistan-easier-for-overseas-pakistanis/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_bayfikr-a-user-friendly-fin-tech-app-making-payments-in-pakistan-easier-for-overseas-pakistanis.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="SadaPay Raises $7.2 Million in Largest Seed Round" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/exclusive-pakistani-fintech-sadapay-raises-7-2-million-in-countrys-largest-seed-round/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_exclusive-pakistani-fintech-sadapay-raises-7-2-million-in-countrys-largest-seed-round.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Pakistani Startups Had Their Best Year With $65 Million Funding" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/despite-a-pandemic-pakistani-startups-had-their-best-year-yet-with-over-65-million-in-funding/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_despite-a-pandemic-pakistani-startups-had-their-best-year-yet-with-over-65-million-in-funding.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="NIC Welcomes Its 10th Cohort of Startups" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/nic-welcomes-its-10th-cohort-of-startups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_nic-welcomes-its-10th-cohort-of-startups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Learning to Celebrate Failure for Startup Ecosystem" FOLDED="true">
              <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/for-a-successful-startup-ecosystem-pakistan-needs-to-learn-to-celebrate-failure/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_for-a-successful-startup-ecosystem-pakistan-needs-to-learn-to-celebrate-failure.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Contact   Careers Section" FOLDED="true">
            <node TEXT="Contact   Careers Summary" FOLDED="true"/>
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="Your Name*" FOLDED="true"/>
              <node TEXT="Your Email" FOLDED="true"/>
              <node TEXT="Company*" FOLDED="true"/>
              <node TEXT="Subject*" FOLDED="true"/>
              <node TEXT="Your Message*" FOLDED="true"/>
              <node TEXT="GET IN TOUCH" LINK="https://teamupventures.com/#contact-careers" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_contact-careers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrap-board.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact   Careers" LINK="https://teamupventures.com/#contact-careers" FOLDED="true">
          <node TEXT="The Pakistan Story" FOLDED="true">
            <node TEXT="Introduction summary: Digital era, growing economy, investment opportunity" FOLDED="true"/>
            <node TEXT="READ MORE" FOLDED="true">
              <node TEXT="Link" LINK="https://teamupventures.com/pakistan-story/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_pakistan-story.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Scrapboard Blog   News" FOLDED="true">
            <node TEXT="The Era of VCs and Boom of Startups" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/the-era-of-vcs-and-boom-of-start-ups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_the-era-of-vcs-and-boom-of-start-ups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="To Survive Pakistan’s COVID Pandemic, Grocery Stores Go Online" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/to-survive-pakistans-covid-pandemic-grocery-stores-go-online/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_to-survive-pakistans-covid-pandemic-grocery-stores-go-online.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Clicky.pk attracts $700,000 in pre-series A funding round" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/clicky-pk-attracts-700000-in-pre-series-a-funding-round/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_clicky-pk-attracts-700000-in-pre-series-a-funding-round.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Sehat Kahani Raises $1 Million Pre-Series A to Grow its Telemedicine Network" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/pakistans-sehat-kahani-raises-1-million-pre-series-a-to-grow-its-telemedicine-network/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-sehat-kahani-raises-1-million-pre-series-a-to-grow-its-telemedicine-network.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Startup Challenges: The Way Out" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/startup-challenges-the-way-out/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_startup-challenges-the-way-out.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Pak Tech Startup Remotebase Raises $1.4 Million Led by Indus Valley Capital" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/pak-tech-startup-remotebase-raises-1-4-million-led-by-indus-valley-capital/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pak-tech-startup-remotebase-raises-1-4-million-led-by-indus-valley-capital.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Shopsy Introduces Voice Search for its Customers" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/islamabad-based-startup-called-shopsy-introduces-voice-search-for-its-customers/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_islamabad-based-startup-called-shopsy-introduces-voice-search-for-its-customers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="PayPro Receives a Grant of Rs 7.4 Million from USAID and SMEA" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/pakistani-fintech-startup-called-paypro-receives-a-grant-of-rs-7-4-million-from-usaid-and-smea/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-fintech-startup-called-paypro-receives-a-grant-of-rs-7-4-million-from-usaid-and-smea.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Local Startup Using AI to Detect COVID-19" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/local-startup-is-using-ai-to-detect-covid-19/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_local-startup-is-using-ai-to-detect-covid-19.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="HumWell: All-inclusive Telehealth Service" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/humwell-comes-to-rescue-with-an-all-inclusive-telehealth-service/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_humwell-comes-to-rescue-with-an-all-inclusive-telehealth-service.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Pakistan’s First E-commerce Marketing Tool Launched" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/pakistans-first-e-commerce-marketing-tool-launched-by-pakistani-entrepreneur-to-make-e-commerce-more-competitive/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-first-e-commerce-marketing-tool-launched-by-pakistani-entrepreneur-to-make-e-commerce-more-competitive.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Pakistani Startups Break Records in 2020 Despite Slowdown" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/pakistani-startups-break-records-in-2020-despite-global-economic-slowdown/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-startups-break-records-in-2020-despite-global-economic-slowdown.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Truck It In Raises $1.5 Million Pre-Seed" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/pakistans-truck-it-in-raises-1-5-million-pre-seed-for-its-trucking-marketplace/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-truck-it-in-raises-1-5-million-pre-seed-for-its-trucking-marketplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="EdTech Startup Edkasa Raises $320,000 Pre-Seed" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/pakistani-edtech-startup-edkasa-raises-320000-pre-seed-by-launching-an-exam-prep-app-for-students/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-edtech-startup-edkasa-raises-320000-pre-seed-by-launching-an-exam-prep-app-for-students.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Pakistan Launches Growth Funds for Startups" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/pakistan-launches-growth-funds-for-startups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistan-launches-growth-funds-for-startups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Bayfikr – Fin-Tech App for Overseas Pakistanis" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/bayfikr-a-user-friendly-fin-tech-app-making-payments-in-pakistan-easier-for-overseas-pakistanis/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_bayfikr-a-user-friendly-fin-tech-app-making-payments-in-pakistan-easier-for-overseas-pakistanis.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="SadaPay Raises $7.2 Million in Country’s Largest Seed Round" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/exclusive-pakistani-fintech-sadapay-raises-7-2-million-in-countrys-largest-seed-round/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_exclusive-pakistani-fintech-sadapay-raises-7-2-million-in-countrys-largest-seed-round.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Despite a Pandemic, Pakistani Startups Had Their Best Year" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/despite-a-pandemic-pakistani-startups-had-their-best-year-yet-with-over-65-million-in-funding/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_despite-a-pandemic-pakistani-startups-had-their-best-year-yet-with-over-65-million-in-funding.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="NIC Welcomes its 10th Cohort of Startups" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/nic-welcomes-its-10th-cohort-of-startups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_nic-welcomes-its-10th-cohort-of-startups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="For a Successful Startup Ecosystem, Celebrate Failure" FOLDED="true">
              <node TEXT="VIEW DETAILS" FOLDED="true">
                <node TEXT="Link" LINK="https://teamupventures.com/scrapboard/for-a-successful-startup-ecosystem-pakistan-needs-to-learn-to-celebrate-failure/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_for-a-successful-startup-ecosystem-pakistan-needs-to-learn-to-celebrate-failure.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
          </node>
          <node TEXT="Contact   Careers Section" FOLDED="true">
            <node TEXT="Contact prompt and invitation summary" FOLDED="true"/>
            <node TEXT="Contact Form" FOLDED="true">
              <node TEXT="Your Name" FOLDED="true"/>
              <node TEXT="Your Email" FOLDED="true"/>
              <node TEXT="Company" FOLDED="true"/>
              <node TEXT="Subject" FOLDED="true"/>
              <node TEXT="Your Message" FOLDED="true"/>
              <node TEXT="GET IN TOUCH" FOLDED="true"/>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_contact-careers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Page Content" FOLDED="true">
      <node TEXT="The Pakistan Story" FOLDED="true">
        <node TEXT="Description" FOLDED="true">
          <node TEXT="Pakistan is on the verge of a new digital era. A young population, low unemployment and a growing middle class position Pakistan to become one of the most promising economies for investors in the coming decade." FOLDED="true"/>
        </node>
        <node TEXT="READ MORE" LINK="https://teamupventures.com/pakistan-story/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_pakistan-story.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Scrapboard" FOLDED="true">
        <node TEXT="BLOG   NEWS" FOLDED="true"/>
        <node TEXT="The Era of VCs and Boom of Startups" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/the-era-of-vcs-and-boom-of-start-ups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_the-era-of-vcs-and-boom-of-start-ups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="To Survive Pakistanapos;s COVID Pandemic, Grocery Stores Go Online" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/to-survive-pakistans-covid-pandemic-grocery-stores-go-online/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_to-survive-pakistans-covid-pandemic-grocery-stores-go-online.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Clicky.pk attracts $700,000 in pre-series A funding round" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/clicky-pk-attracts-700000-in-pre-series-a-funding-round/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_clicky-pk-attracts-700000-in-pre-series-a-funding-round.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Pakistanapos;s apos;Sehat Kahaniapos; Raises $1 Million Pre-Series A to Grow its Telemedicine Network" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-sehat-kahani-raises-1-million-pre-series-a-to-grow-its-telemedicine-network/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-sehat-kahani-raises-1-million-pre-series-a-to-grow-its-telemedicine-network.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Startup Challenges: The Way Out" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/startup-challenges-the-way-out/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_startup-challenges-the-way-out.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Pak Tech Startup apos;Remotebaseapos; Raises $1.4 Million Led by Indus Valley Capital" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pak-tech-startup-remotebase-raises-1-4-million-led-by-indus-valley-capital/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pak-tech-startup-remotebase-raises-1-4-million-led-by-indus-valley-capital.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Islamabad-based Startup Called apos;Shopsyapos; Introduces Voice Search for its Customers" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/islamabad-based-startup-called-shopsy-introduces-voice-search-for-its-customers/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_islamabad-based-startup-called-shopsy-introduces-voice-search-for-its-customers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Pakistani Fintech Startup Called apos;PayProapos; Receives a Grant of Rs 7.4 Million from USAID and SMEA" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-fintech-startup-called-paypro-receives-a-grant-of-rs-7-4-million-from-usaid-and-smea/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-fintech-startup-called-paypro-receives-a-grant-of-rs-7-4-million-from-usaid-and-smea.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Local Startup is Using AI to Detect COVID-19" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/local-startup-is-using-ai-to-detect-covid-19/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_local-startup-is-using-ai-to-detect-covid-19.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="HumWell Comes To Rescue, With An All-Inclusive Telehealth Service" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/humwell-comes-to-rescue-with-an-all-inclusive-telehealth-service/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_humwell-comes-to-rescue-with-an-all-inclusive-telehealth-service.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Pakistanapos;s First E-commerce Marketing Tool Launched by Pakistani Entrepreneur to Make E-commerce More Competitive" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-first-e-commerce-marketing-tool-launched-by-pakistani-entrepreneur-to-make-e-commerce-more-competitive/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-first-e-commerce-marketing-tool-launched-by-pakistani-entrepreneur-to-make-e-commerce-more-competitive.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Pakistani Startups Break Records in 2020 Despite Global Economic Slowdown" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-startups-break-records-in-2020-despite-global-economic-slowdown/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-startups-break-records-in-2020-despite-global-economic-slowdown.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Pakistanapos;s apos;Truck It Inapos; Raises $1.5 Million Pre-Seed for its Trucking Marketplace" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistans-truck-it-in-raises-1-5-million-pre-seed-for-its-trucking-marketplace/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistans-truck-it-in-raises-1-5-million-pre-seed-for-its-trucking-marketplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Pakistani EdTech Startup apos;Edkasaapos; Raises $320,000 Pre-Seed by Launching an Exam Prep App for Students" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistani-edtech-startup-edkasa-raises-320000-pre-seed-by-launching-an-exam-prep-app-for-students/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistani-edtech-startup-edkasa-raises-320000-pre-seed-by-launching-an-exam-prep-app-for-students.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Pakistan Launches Growth Funds for Startups" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/pakistan-launches-growth-funds-for-startups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_pakistan-launches-growth-funds-for-startups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Bayfikr – a User-Friendly Fin-Tech app, Making Payments in Pakistan Easier for Overseas Pakistanis" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/bayfikr-a-user-friendly-fin-tech-app-making-payments-in-pakistan-easier-for-overseas-pakistanis/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_bayfikr-a-user-friendly-fin-tech-app-making-payments-in-pakistan-easier-for-overseas-pakistanis.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Pakistani Fintech SadaPay Raises $7.2 Million in Countryapos;s Largest Seed Round" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/exclusive-pakistani-fintech-sadapay-raises-7-2-million-in-countrys-largest-seed-round/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_exclusive-pakistani-fintech-sadapay-raises-7-2-million-in-countrys-largest-seed-round.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Despite a Pandemic, Pakistani Startups Had Their Best Year Yet With Over $65 Million in Funding" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/despite-a-pandemic-pakistani-startups-had-their-best-year-yet-with-over-65-million-in-funding/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_despite-a-pandemic-pakistani-startups-had-their-best-year-yet-with-over-65-million-in-funding.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="NIC Welcomes Itapos;s 10th Cohort of Startups" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/nic-welcomes-its-10th-cohort-of-startups/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_nic-welcomes-its-10th-cohort-of-startups.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="For a successful startup ecosystem, Pakistan needs to learn to celebrate failure" FOLDED="true">
          <node TEXT="View Details" LINK="https://teamupventures.com/scrapboard/for-a-successful-startup-ecosystem-pakistan-needs-to-learn-to-celebrate-failure/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_scrapboard_for-a-successful-startup-ecosystem-pakistan-needs-to-learn-to-celebrate-failure.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
      </node>
      <node TEXT="Contact   Careers" LINK="https://teamupventures.com/#contact-careers" FOLDED="true">
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="Your Name" FOLDED="true"/>
          <node TEXT="Your Email" FOLDED="true"/>
          <node TEXT="Company" FOLDED="true"/>
          <node TEXT="Subject" FOLDED="true"/>
          <node TEXT="Your Message" FOLDED="true"/>
          <node TEXT="GET IN TOUCH" LINK="https://teamupventures.com/#contact-careers" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_contact-careers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_contact-careers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Company Info" FOLDED="true">
        <node TEXT="Teamup Ventures is licensed and regulated by the Dubai Financial Services Authority. Company Number: 4684" FOLDED="true"/>
      </node>
      <node TEXT="Dubai Office" FOLDED="true">
        <node TEXT="Teamup Ventures" FOLDED="true"/>
        <node TEXT="Level 1 Gate Avenue – South" LINK="https://maps.app.goo.gl/6TW76qnbMrejyLBt6" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_6TW76qnbMrejyLBt6.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Dubai International Financial Centre (DIFC)" LINK="https://maps.app.goo.gl/yuURWpV31zyayDeN7" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_maps.app.goo.gl_yuURWpV31zyayDeN7.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="PO Box 50 70 33" FOLDED="true"/>
        <node TEXT="Dubai, UAE" FOLDED="true"/>
      </node>
      <node TEXT="Other Contact" FOLDED="true">
        <node TEXT="contact@teamupventures.com" LINK="mailto:contact@teamupventures.com" FOLDED="true"/>
        <node TEXT="Social Media" FOLDED="true">
          <node TEXT="Twitter" LINK="https://twitter.com/VenturesTeamup" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_twitter.com_VenturesTeamup.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Instagram" LINK="https://www.instagram.com/teamupventures/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.instagram.com_teamupventures.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/teamup-ventures/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_company_teamup-ventures.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Terms   Conditions" LINK="https://teamupventures.com/terms-conditions/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_teamupventures.com_terms-conditions.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
  </node>
</map>
