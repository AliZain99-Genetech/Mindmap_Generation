<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="referral form">
    <node TEXT="Requesting Physician Information">
      <node TEXT="Referral Form">
        <node TEXT="First Name" />
        <node TEXT="Last Name" />
        <node TEXT="Area Code and Phone Number" />
        <node TEXT="City" />
        <node TEXT="State" />
      </node>
    </node>
    <node TEXT="Patient Information">
      <node TEXT="First Name" />
      <node TEXT="Last Name" />
      <node TEXT="Area Code and Phone Number" />
      <node TEXT="Date of Birth" />
      <node TEXT="Gender" />
    </node>
    <node TEXT="Appointment Information">
      <node TEXT="Urgency" />
      <node TEXT="Medical Condition" />
      <node TEXT="Other" />
      <node TEXT="Special Request" />
    </node>
  </node>
</map>