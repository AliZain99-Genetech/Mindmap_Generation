<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="letter from our president">
    <node TEXT="President #39;s Welcome and Practice Overview">
      <node TEXT="Summary: 33 years in nephrology, evolution of LACNA, support for nephrology field" />
    </node>
    <node TEXT="LACNA Growth, Specialization, and Commitment">
      <node TEXT="Summary: PD center development, interventions, staff, and dedication to innovation and patient care" />
      <node TEXT="peritoneal dialysis">
        <node TEXT="Link: Glossary of Terms" LINK="https://lacountynephrology.com/glossary-of-terms/" />
      </node>
    </node>
  </node>
</map>