<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="what we treat">
    <node TEXT="Overview of Nephrology Services">
      <node TEXT="Full spectrum of kidney disease management for all ages" />
      <node TEXT="List of kidney-related conditions treated" />
    </node>
    <node TEXT="Support   Patient Commitments">
      <node TEXT="Collaborative care with patients and families" />
      <node TEXT="On-site labs at many locations" />
      <node TEXT="Online Patient Education Center">
        <node TEXT="Patient Education Center" LINK="https://lacountynephrology.com/patient-education-center/" />
      </node>
    </node>
  </node>
</map>