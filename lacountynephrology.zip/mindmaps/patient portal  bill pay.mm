<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="patient portal  bill pay">
    <node TEXT="Pay Bill as Guest">
      <node TEXT="Pay as a guest" LINK="https://qp-portal-redirect.cf.px.athena.io/portal-integration" />
      <node TEXT="Continue" LINK="https://16656-1.portal.athenahealth.com/" />
      <node TEXT="Go Home" LINK="https://16656-1.portal.athenahealth.com/" />
    </node>
    <node TEXT="Account Payment Instructions">
      <node TEXT="Your Account Status   Payment Due Summary" />
      <node TEXT="If you have not created your patient statement, sign in to the Patient Portal to review your balance." />
      <node TEXT="click here to re-register" LINK="https://16656-1.portal.athenahealth.com/?section=landing&amp;sub=enroll" />
    </node>
  </node>
</map>