<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="qualifying criteria">
    <node TEXT="Qualifying requirements summary" />
    <node TEXT="Main qualifying criteria section" />
    <node TEXT="BOOK NOW">
      <node TEXT="https://altitudeocr.com/altitude-ocr-para/#paraRegForm" />
    </node>
    <node TEXT="GET IN TOUCH">
      <node TEXT="https://altitudeocr.com/contact" />
    </node>
  </node>
</map>