<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="ocr journey">
    <node TEXT="Page Actions">
      <node TEXT="BOOK NOW">
        <node TEXT="https://altitudeocr.com/altitude-ocr-para/#paraRegForm" />
      </node>
      <node TEXT="GET IN TOUCH">
        <node TEXT="https://altitudeocr.com/contact" />
      </node>
    </node>
    <node TEXT="Introduction">
      <node TEXT="Inspirational Journey Message" />
    </node>
    <node TEXT="World Championships Schedule">
      <node TEXT="September 2021, Mt. Kilimanjaro (5,985m), Tanzania" />
      <node TEXT="November 2022, Mt. Everest (8,848m), Nepal" />
      <node TEXT="October 2023, Mt. Apo (2,954m), Philippines" />
      <node TEXT="November 2024, Mt. Vinson Massif (4,892m), Antarctica" />
      <node TEXT="July 2025, Mt. Kosciuszko (2,228m), Australia" />
      <node TEXT="February 2026, Mt. Aconcagua (6,961m), Argentina" />
      <node TEXT="May 2027, Mt. Denali (6,190m), USA" />
    </node>
    <node TEXT="Event Format   Series Info">
      <node TEXT="Yearly locations   participant options summary" />
    </node>
    <node TEXT="Guinness Record Challenge">
      <node TEXT="Conquer the toughest events summary" />
      <node TEXT="GET EXCLUSIVE UPDATES">
        <node TEXT="https://altitudeocr.com/contact/" />
      </node>
      <node TEXT="BOOK A VIDEO CALL">
        <node TEXT="https://wa.me/4407590365869" />
      </node>
      <node TEXT="BOOK NOW">
        <node TEXT="https://altitudeocr.com/altitude-ocr-para/#paraRegForm" />
      </node>
      <node TEXT="GET IN TOUCH">
        <node TEXT="https://altitudeocr.com/contact" />
      </node>
    </node>
  </node>
</map>