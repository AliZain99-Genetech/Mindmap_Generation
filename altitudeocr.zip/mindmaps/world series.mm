<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="world series">
    <node TEXT="Pathway to the Altitude OCR World Finals   World Championships">
      <node TEXT="Section summary: Information about exclusive partner events and qualification for the World Finals and Championships." />
    </node>
    <node TEXT="Altitude OCR World Series Partners">
      <node TEXT="Section summary: Details about partnership agreements and collaboration goals." />
    </node>
    <node TEXT="BOOK NOW">
      <node TEXT="Link: BOOK NOW" LINK="https://altitudeocr.com/altitude-ocr-para/#paraRegForm" />
    </node>
    <node TEXT="GET IN TOUCH">
      <node TEXT="Link: GET IN TOUCH" LINK="https://altitudeocr.com/contact/" />
    </node>
  </node>
</map>