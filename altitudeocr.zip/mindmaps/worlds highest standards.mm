<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="worlds highest standards">
    <node TEXT="Introduction   Standards Summary">
      <node TEXT="Summary of World's Highest Standards and objectives for quality of life enhancement in altitude events." />
    </node>
    <node TEXT="Partnerships   Research">
      <node TEXT="Partnership programs, university collaborations, and focus on research and safety in high-altitude events." />
    </node>
    <node TEXT="BOOK NOW">
      <node TEXT="BOOK NOW (https://altitudeocr.com/altitude-ocr-para/#paraRegForm)" />
    </node>
    <node TEXT="GET IN TOUCH">
      <node TEXT="GET IN TOUCH (https://altitudeocr.com/contact)" />
    </node>
  </node>
</map>