<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="partners">
    <node TEXT="Main Section">
      <node TEXT="Partners Title and Intro" />
      <node TEXT="Book Now">
        <node TEXT="BOOK NOW" LINK="https://altitudeocr.com/altitude-ocr-para/#paraRegForm" />
      </node>
      <node TEXT="Get In Touch">
        <node TEXT="GET IN TOUCH" LINK="https://altitudeocr.com/contact" />
      </node>
    </node>
    <node TEXT="Partners Grid">
      <node TEXT="Grid of partner logos and names" />
    </node>
    <node TEXT="Become a Partner">
      <node TEXT="BECOME A PARTNER" LINK="https://altitudeocr.com/contact/" />
    </node>
    <node TEXT="Buttons (lower section)">
      <node TEXT="BOOK NOW" LINK="https://altitudeocr.com/altitude-ocr-para/#paraRegForm" />
      <node TEXT="GET IN TOUCH" LINK="https://altitudeocr.com/contact" />
    </node>
  </node>
</map>