<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="world championships">
    <node TEXT="Altitude OCR World Championships">
      <node TEXT="BOOK NOW">
        <node TEXT="BOOK NOW" LINK="https://altitudeocr.com/altitude-ocr-para/#paraRegForm" />
      </node>
      <node TEXT="Key Info Cards">
        <node TEXT="Press Release">
          <node TEXT="READ MORE" LINK="https://altitudeocr.com/press-release/" />
        </node>
        <node TEXT="Kilimanjaro 2021">
          <node TEXT="READ MORE" LINK="https://altitudeocr.com/kilimanjaro-2021-2/" />
        </node>
        <node TEXT="Everest 2022">
          <node TEXT="READ MORE" LINK="https://altitudeocr.com/ocr-everest-2022/" />
        </node>
        <node TEXT="Qualifying Criteria">
          <node TEXT="READ MORE" LINK="https://altitudeocr.com/qualifying-criteria/" />
        </node>
      </node>
    </node>
  </node>
</map>