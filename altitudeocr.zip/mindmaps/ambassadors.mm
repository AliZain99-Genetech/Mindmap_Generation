<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="ambassadors">
    <node TEXT="Veterans In Extreme World Record Breaking Sports" />
    <node TEXT="Ambassadors Profiles">
      <node TEXT="Jason Wood">
        <node TEXT="ALTITUDE OCR Ambassador for Veterans worldwide. Inspiring, Encouraging and Empowering all Veterans to achieve incredible goals in extreme altitude sports" />
        <node TEXT="Instagram: jfloydwood">
          <node TEXT="jfloydwood" LINK="https://www.instagram.com/jfloydwood/" />
        </node>
      </node>
      <node TEXT="Kristina Madsen">
        <node TEXT="Promoting girls and women in extreme altitude sport worldwide" />
        <node TEXT="Facebook: Kristinaextremerunning">
          <node TEXT="Kristinaextrenerunning" LINK="https://www.facebook.com/kristinaextremerunning" />
        </node>
        <node TEXT="Instagram: Kristinaextremerunning">
          <node TEXT="Kristinaextremerunning" LINK="https://www.instagram.com/kristinaextremerunning" />
        </node>
        <node TEXT="Strava: 12901567">
          <node TEXT="12901567" LINK="https://www.strava.com/athletes/12901567" />
        </node>
        <node TEXT="Article">
          <node TEXT="2020 World Marathon Challenge Results" LINK="https://www.runnersworld.com/news/a30916189/2020-world-marathon-challenge-results" />
        </node>
      </node>
    </node>
    <node TEXT="Buttons">
      <node TEXT="BOOK NOW" LINK="https://altitudeocr.com/altitude-ocr-para/#paraRegForm" />
      <node TEXT="GET IN TOUCH" LINK="https://altitudeocr.com/contact" />
    </node>
  </node>
</map>