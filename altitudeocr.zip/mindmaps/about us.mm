<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="about us">
    <node TEXT="Intro   Call to Action">
      <node TEXT="Event Organizers and World Record Expertise summary" />
      <node TEXT="BOOK NOW">
        <node TEXT="BOOK NOW Link" LINK="https://altitudeocr.com/altitude-ocr-para/#paraRegForm" />
      </node>
      <node TEXT="GET IN TOUCH">
        <node TEXT="GET IN TOUCH Link" LINK="https://altitudeocr.com/contact" />
      </node>
    </node>
    <node TEXT="Meet the Founders">
      <node TEXT="Dave Pickles - Keynote Speaker   Mountaineer summary" />
      <node TEXT="Rob Edmond - Obstacle Race Events Director summary" />
    </node>
  </node>
</map>