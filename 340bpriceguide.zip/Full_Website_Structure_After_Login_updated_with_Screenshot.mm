<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home Page">
    <node TEXT="Header">
      <node TEXT="Logo" />
      <node TEXT="Navigation">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search">
          <node TEXT="Frequently Searched Products">
            <node TEXT="ADVAIR HFA 230-21 MCG INHALER">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#382"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_382.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="BREO ELLIPTA 100-25 MCG INHALR">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2387"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_2387.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="BUTRANS 5 MCG/HR PATCH">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2829"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_2829.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="DULERA 200 MCG-5 MCG INHALER">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#6302"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_6302.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="FARXIGA 10 MG TABLET">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#7308"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_7308.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="JANUVIA 100 MG TABLET">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9856"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_9856.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="JARDIANCE 10 MG TABLET">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9864"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_9864.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10370"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_10370.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="LIDOCAINE 5% PATCH">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10863"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_10863.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="LYRICA 100 MG CAPSULE">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#11489"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_11489.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="PROAIR RESPICLICK 90 MCG INHLR">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#15844"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_15844.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="TRADJENTA 5 MG TABLET">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#18799"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_18799.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19218"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_19218.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19879"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_19879.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="XARELTO 10 MG TABLET">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#20198"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_20198.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Search Filters">
            <node TEXT="Please assign pharmacy from the portal first!" />
            <node TEXT="Medication/NDC Search Input" />
            <node TEXT="Quantity Dropdown" />
            <node TEXT="Patient Group Dropdown" />
            <node TEXT="Formulary Dropdown" />
            <node TEXT="Clear All Data Button" />
          </node>
          <node TEXT="Comments Section">
            <node TEXT="User comments and replies about 340B pricing and pharmacy issues" />
            <node TEXT="Search Comments Input" />
            <node TEXT="Sort by Dropdown" />
            <node TEXT="Load more comments Button" />
          </node>
          <node TEXT="Add Comment Form">
            <node TEXT="Comment Textarea" />
            <node TEXT="Post Button" />
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news">
          <node TEXT="Featured Articles">
            <node TEXT="WEEKLY PRODUCT SHORTAGES">
              <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="MANUFACTURER 340B RESTRICTIONS FOR OREGON">
              <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_144-status-of-manufacturer-340b-restrictions-for-oregon.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="NOVO NORDISK CHANGES PATIENT ASSISTANCE PROGRAM (PAP) 2026">
              <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026." />
              <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_143-changes-to-novo-nordisk-patient-assistance-program-pap-2026.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="BAUSCH HEALTH EXITS THE 340B DRUG PRICING PROGRAM">
              <node TEXT="Bausch Health has ended its participation in the 340B Drug Pricing Program; products are no longer eligible." />
              <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_142-bausch-health-exits-the-340b-drug-pricing-program.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="More Articles">
            <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September">
              <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Communication from BPHC announcing new award terms">
              <node TEXT="Communication from BPHC announcing new award terms" LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_140-communication-from-bphc-announcing-new-award-terms.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Rite Aid Winds Down 340B Operations">
              <node TEXT="Rite Aid Winds Down 340B Operations" LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_139-rite-aid-winds-down-340b-operations.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Continued Brand Name Victoza Shortages">
              <node TEXT="Continued Brand Name Victoza Shortages" LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_138-continued-brand-name-victoza-shortages.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Pagination">
            <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_4.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_8.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_12.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_16.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_20.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="7" LINK="https://www.340bpriceguide.net/articles-news?start=24"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_24.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_4.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=24"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_24.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us">
          <node TEXT="340B Price Guide Overview">
            <node TEXT="Summary: Customized publication for health organizations to understand 340B drug pricing and its impact." />
          </node>
          <node TEXT="340B Guided Services">
            <node TEXT="Summary: Independent consulting for covered entities, best practices, and program management." />
          </node>
          <node TEXT="Client Testimonials" />
          <node TEXT="Featured Partners &amp; Organizations" />
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_about-us.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us">
          <node TEXT="Contact Form">
            <node TEXT="Name (required)" />
            <node TEXT="Email (required)" />
            <node TEXT="Company" />
            <node TEXT="Address" />
            <node TEXT="City, State Zip" />
            <node TEXT="Phone" />
            <node TEXT="Inquiry Type (dropdown, required)" />
            <node TEXT="Comment or Question (textarea)" />
            <node TEXT="Captcha" />
            <node TEXT="Submit Button" />
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_contact-us.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Profile" LINK="https://www.340bpriceguide.net/my-profile">
          <node TEXT="User Overview">
            <node TEXT="Name: Ali Zain (Online)" />
          </node>
          <node TEXT="Details Section">
            <node TEXT="Summary of user details: Username, First Name, Last Name, Clinic/Hospital, Email, Phone, Pharmacy, Group" />
            <node TEXT="alizainsharif48@gmail.com">
              <node TEXT="mailto:alizainsharif48@gmail.com" />
            </node>
          </node>
          <node TEXT="Edit Profile">
            <node TEXT="Edit Profile" />
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_my-profile.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Logout" LINK="https://www.340bpriceguide.net/logout"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_logout.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="SecureMsg" LINK="https://www.340bpriceguide.net/secure-message">
          <node TEXT="Main Content">
            <node TEXT="Community Health Centers Of Lane County - Eugene, Oregon" />
            <node TEXT="WHAT IS 340B?">
              <node TEXT="340B has helped provide low-cost medications and better health for 25 years." />
            </node>
            <node TEXT="WEEKLY PRODUCT SHORTAGES" />
          </node>
          <node TEXT="Form">
            <node TEXT="Medication Search">
              <node TEXT="Text Input: Enter a medication" />
              <node TEXT="Button: FIND 340B PRICES" />
            </node>
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_secure-message.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Search Icon" />
    </node>
    <node TEXT="Home Page Content">
      <node TEXT="Image Carousel">
        <node TEXT="Community Health Centers Of Lane County" />
        <node TEXT="Location: Eugene, Oregon" />
      </node>
      <node TEXT="Medication Search Form">
        <node TEXT="Text Field: Enter a medication" />
        <node TEXT="Button: FIND 340B PRICES" />
      </node>
      <node TEXT="What is 340B? Section">
        <node TEXT="Description: For the past 25 years, 340B has helped provide low-cost medications and better health..." />
        <node TEXT="Link: What is 340B?" LINK="https://www.340bpriceguide.net/articles-news/50-what-is-340b"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_50-what-is-340b.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Weekly Product Shortages Section">
        <node TEXT="Link: Weekly Product Shortages" LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Logo" />
      <node TEXT="Useful Links">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/index.php"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_about-us.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Articles   News" LINK="https://www.340bpriceguide.net/index.php/articles-news"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_articles-news.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_contact-us.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us">
        <node TEXT="Address: 501 Fourth Street, #854 Lake Oswego, OR 97034" />
        <node TEXT="Phone: (503)298-0681" />
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" />
      </node>
      <node TEXT="External Resource">
        <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/http_www.hrsa.gov_opa.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="TOP" LINK="https://www.340bpriceguide.net/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net.png" width="500" height="250" />
        </p>
      </body>
    </html></richcontent></node></node>
    </node>
  </node>
</map>