<?xml version='1.0' encoding='UTF-8'?>
<map version="1.0.1">
  <node TEXT="Home Page" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Logo: 340B PRICE GUIDE" FOLDED="true"/>
      <node TEXT="Navigation" FOLDED="true">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_about-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_contact-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Search Button" FOLDED="true">
        <node TEXT="Search Icon" FOLDED="true"/>
      </node>
    </node>
    <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search" FOLDED="true">
      <node TEXT="Frequently Searched Products" FOLDED="true">
        <node TEXT="ADVAIR HFA 230-21 MCG INHALER" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#382" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_382.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="BREO ELLIPTA 100-25 MCG INHALR" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2387" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_2387.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="BUTRANS 5 MCG/HR PATCH" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2829" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_2829.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="DULERA 200 MCG-5 MCG INHALER" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#6302" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_6302.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="FARXIGA 10 MG TABLET" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#7308" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_7308.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="JANUVIA 100 MG TABLET" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9856" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_9856.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="JARDIANCE 10 MG TABLET" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9864" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_9864.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10370" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_10370.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="LIDOCAINE 5% PATCH" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10863" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_10863.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="LYRICA 100 MG CAPSULE" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#11489" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_11489.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="PROAIR RESPICLICK 90 MCG INHLR" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#15844" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_15844.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="TRADJENTA 5 MG TABLET" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#18799" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_18799.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19218" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_19218.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19879" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_19879.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="XARELTO 10 MG TABLET" FOLDED="true">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#20198" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_20198.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
      </node>
      <node TEXT="Comments Section" FOLDED="true">
        <node TEXT="User questions and expert replies about 340B pricing and medications" FOLDED="true"/>
        <node TEXT="Search Comments Form" FOLDED="true">
          <node TEXT="Search Comments (input)" FOLDED="true"/>
          <node TEXT="Sort by (dropdown)" FOLDED="true"/>
        </node>
        <node TEXT="Load more comments Button" FOLDED="true"/>
      </node>
    <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news" FOLDED="true">
      <node TEXT="Featured Articles" FOLDED="true">
        <node TEXT="Weekly Product Shortages" FOLDED="true">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Manufacturer 340B Restrictions for Oregon" FOLDED="true">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_144-status-of-manufacturer-340b-restrictions-for-oregon.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026" FOLDED="true">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_143-changes-to-novo-nordisk-patient-assistance-program-pap-2026.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Bausch Health Exits the 340B Drug Pricing Program" FOLDED="true">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_142-bausch-health-exits-the-340b-drug-pricing-program.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
      </node>
      <node TEXT="More Articles" FOLDED="true">
        <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Communication from BPHC announcing new award terms" LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_140-communication-from-bphc-announcing-new-award-terms.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Rite Aid Winds Down 340B Operations" LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_139-rite-aid-winds-down-340b-operations.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Continued Brand Name Victoza Shortages" LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_138-continued-brand-name-victoza-shortages.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Pagination" FOLDED="true">
        <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_8.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_12.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_16.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us" FOLDED="true">
      <node TEXT="340B Price Guide Overview" FOLDED="true">
        <node TEXT="Summary: Customized publication for health organizations to understand 340B drug pricing." FOLDED="true"/>
      </node>
      <node TEXT="340B Guided Services" FOLDED="true">
        <node TEXT="Summary: Independent consulting and guidance for 340B program management and best practices." FOLDED="true"/>
      </node>
      <node TEXT="Client Testimonials" FOLDED="true">
        <node TEXT="Summary: User feedback highlighting benefits and experiences with 340B Price Guide." FOLDED="true"/>
      </node>
      <node TEXT="Partner Organizations" FOLDED="true">
        <node TEXT="Summary: Logos of health organizations and clinics associated with 340B Price Guide." FOLDED="true"/>
      </node>
    <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_about-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us" FOLDED="true">
      <node TEXT="Contact Form" FOLDED="true">
        <node TEXT="Name" FOLDED="true"/>
        <node TEXT="Email" FOLDED="true"/>
        <node TEXT="Company" FOLDED="true"/>
        <node TEXT="Address" FOLDED="true"/>
        <node TEXT="City, State Zip" FOLDED="true"/>
        <node TEXT="Phone" FOLDED="true"/>
        <node TEXT="Inquiry Type" FOLDED="true"/>
        <node TEXT="Comment or Question" FOLDED="true"/>
        <node TEXT="Captcha" FOLDED="true"/>
        <node TEXT="Submit Button" FOLDED="true">
          <node TEXT="SUBMIT" FOLDED="true"/>
        </node>
      </node>
    <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_contact-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Home Page Content" FOLDED="true">
      <node TEXT="Hero Section" FOLDED="true">
        <node TEXT="Image Carousel" FOLDED="true"/>
        <node TEXT="Community Health Centers Of Lane County" FOLDED="true"/>
        <node TEXT="Search Form" FOLDED="true">
          <node TEXT="Input: Enter a medication" FOLDED="true"/>
          <node TEXT="Button: FIND 340B PRICES" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="What is 340B?" FOLDED="true">
        <node TEXT="Description: For the past 25 years, 340B has helped provide low-cost medications and better health..." FOLDED="true"/>
        <node TEXT="Learn More" LINK="https://www.340bpriceguide.net/articles-news/50-what-is-340b" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_50-what-is-340b.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Weekly Product Shortages" FOLDED="true">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Logo: 340B PRICE GUIDE" FOLDED="true"/>
      <node TEXT="Useful Links" FOLDED="true">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/index.php" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_about-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Articles   News" LINK="https://www.340bpriceguide.net/index.php/articles-news" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_articles-news.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_contact-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information" FOLDED="true">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us" FOLDED="true">
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" FOLDED="true"/>
        <node TEXT="Address: 501 Fourth Street, #854, Lake Oswego, OR 97034" FOLDED="true"/>
        <node TEXT="Phone: (503)298-0681" FOLDED="true"/>
      </node>
      <node TEXT="HRSA OPA" FOLDED="true">
        <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/http_www.hrsa.gov_opa.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="TOP" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Login / Sign up" LINK="https://www.340bpriceguide.net/client-login?view=registration" FOLDED="true">
      <node TEXT="Forgot your password?" LINK="https://www.340bpriceguide.net/client-login?view=reset" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_client-login_view_reset.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Forgot your username?" LINK="https://www.340bpriceguide.net/client-login?view=remind" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_client-login_view_remind.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Create an account" LINK="https://www.340bpriceguide.net/client-login?view=registration" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_client-login_view_registration.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_client-login_view_registration.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node><node TEXT="After Login Flow" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Logo" FOLDED="true"/>
      <node TEXT="Navigation" FOLDED="true">
        <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search" FOLDED="true">
          <node TEXT="Frequently Searched Products" FOLDED="true">
            <node TEXT="ADVAIR HFA 230-21 MCG INHALER" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#382" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_382.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="BREO ELLIPTA 100-25 MCG INHALR" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2387" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_2387.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="BUTRANS 5 MCG/HR PATCH" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2829" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_2829.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="DULERA 200 MCG-5 MCG INHALER" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#6302" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_6302.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="FARXIGA 10 MG TABLET" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#7308" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_7308.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="JANUVIA 100 MG TABLET" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9856" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_9856.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="JARDIANCE 10 MG TABLET" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9864" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_9864.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10370" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_10370.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="LIDOCAINE 5% PATCH" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10863" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_10863.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="LYRICA 100 MG CAPSULE" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#11489" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_11489.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="PROAIR RESPICLICK 90 MCG INHLR" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#15844" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_15844.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="TRADJENTA 5 MG TABLET" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#18799" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_18799.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19218" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_19218.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19879" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_19879.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="XARELTO 10 MG TABLET" FOLDED="true">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#20198" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_20198.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Search Filters Form" FOLDED="true">
            <node TEXT="Search Medication or NDC input" FOLDED="true"/>
            <node TEXT="Pharmacy assignment notice" FOLDED="true"/>
            <node TEXT="Quantity dropdown" FOLDED="true"/>
            <node TEXT="Patient Group dropdown" FOLDED="true"/>
            <node TEXT="Formulary dropdown" FOLDED="true"/>
            <node TEXT="Clear All Data button" FOLDED="true"/>
          </node>
          <node TEXT="Comments Section" FOLDED="true">
            <node TEXT="Add Comment Form" FOLDED="true">
              <node TEXT="Comment input" FOLDED="true"/>
              <node TEXT="Post button" FOLDED="true"/>
            </node>
            <node TEXT="User Comments List" FOLDED="true"/>
            <node TEXT="Load more comments button" FOLDED="true"/>
          </node>
          <node TEXT="Sort and Search Comments" FOLDED="true">
            <node TEXT="Search Comments input" FOLDED="true"/>
            <node TEXT="Sort by dropdown" FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news" FOLDED="true">
          <node TEXT="Featured Articles" FOLDED="true">
            <node TEXT="WEEKLY PRODUCT SHORTAGES" FOLDED="true">
              <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="MANUFACTURER 340B RESTRICTIONS FOR OREGON" FOLDED="true">
              <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_144-status-of-manufacturer-340b-restrictions-for-oregon.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="NOVO NORDISK CHANGES PATIENT ASSISTANCE PROGRAM (PAP) 2026" FOLDED="true">
              <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026." FOLDED="true"/>
              <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_143-changes-to-novo-nordisk-patient-assistance-program-pap-2026.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="BAUSCH HEALTH EXITS THE 340B DRUG PRICING PROGRAM" FOLDED="true">
              <node TEXT="Bausch Health has ended its participation in the 340B Drug Pricing Program as of October 1, 2025." FOLDED="true"/>
              <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_142-bausch-health-exits-the-340b-drug-pricing-program.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="More Articles" FOLDED="true">
            <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="Communication from BPHC announcing new award terms" LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_140-communication-from-bphc-announcing-new-award-terms.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="Rite Aid Winds Down 340B Operations" LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_139-rite-aid-winds-down-340b-operations.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="Continued Brand Name Victoza Shortages" LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_138-continued-brand-name-victoza-shortages.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Pagination" FOLDED="true">
            <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_4.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_8.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_12.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_16.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_20.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="7" LINK="https://www.340bpriceguide.net/articles-news?start=24" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_24.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_4.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
            <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=24" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_24.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us" FOLDED="true">
          <node TEXT="340B Price Guide Overview" FOLDED="true">
            <node TEXT="Summary: Customized publication for health organizations to understand 340B drug prices and their impact." FOLDED="true"/>
          </node>
          <node TEXT="340B Guided Services" FOLDED="true">
            <node TEXT="Summary: Consulting and guidance for covered entities to manage and optimize their 340B programs." FOLDED="true"/>
          </node>
          <node TEXT="Client Testimonials" FOLDED="true">
            <node TEXT="Summary: Feedback from healthcare professionals and organizations on the benefits and impact of 340B Price Guide." FOLDED="true"/>
          </node>
          <node TEXT="Partners &amp; Clients" FOLDED="true">
            <node TEXT="Summary: Logos of partner organizations and health centers served by 340B Price Guide." FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_about-us.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us" FOLDED="true">
          <node TEXT="Contact Form" FOLDED="true">
            <node TEXT="Name" FOLDED="true"/>
            <node TEXT="Email" FOLDED="true"/>
            <node TEXT="Company" FOLDED="true"/>
            <node TEXT="Address" FOLDED="true"/>
            <node TEXT="City, State Zip" FOLDED="true"/>
            <node TEXT="Phone" FOLDED="true"/>
            <node TEXT="Inquiry Type" FOLDED="true"/>
            <node TEXT="Comment or Question" FOLDED="true"/>
            <node TEXT="Captcha" FOLDED="true"/>
            <node TEXT="Submit Button" FOLDED="true">
              <node TEXT="SUBMIT" FOLDED="true"/>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_contact-us.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Profile" LINK="https://www.340bpriceguide.net/my-profile" FOLDED="true">
          <node TEXT="User Overview" FOLDED="true">
            <node TEXT="Name: Ali Zain (Online)" FOLDED="true"/>
          </node>
          <node TEXT="Details Section" FOLDED="true">
            <node TEXT="Summary of user details: Username, First Name, Last Name, Clinic/Hospital, Email, Phone, Pharmacy, Group" FOLDED="true"/>
            <node TEXT="Email Address" FOLDED="true">
              <node TEXT="alizainsharif48@gmail.com" LINK="mailto:alizainsharif48@gmail.com" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Edit Profile" FOLDED="true">
            <node TEXT="Edit Profile" LINK="https://www.340bpriceguide.net/profile/profile?layout=edit" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_profile_profile_layout_edit.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_my-profile.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Logout" LINK="https://www.340bpriceguide.net/logout" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_logout.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="SecureMsg" LINK="https://www.340bpriceguide.net/secure-message" FOLDED="true">
          <node TEXT="Main Content" FOLDED="true">
            <node TEXT="Community Health Centers Of Lane County - Eugene, Oregon" FOLDED="true"/>
            <node TEXT="WHAT IS 340B? - 340B helps provide low-cost medications and better health" FOLDED="true"/>
            <node TEXT="WEEKLY PRODUCT SHORTAGES" FOLDED="true"/>
          </node>
          <node TEXT="Form: Medication Search" FOLDED="true">
            <node TEXT="Text Input: Enter a medication" FOLDED="true"/>
            <node TEXT="Button: FIND 340B PRICES" FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_secure-message.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Search Icon" FOLDED="true"/>
    </node>
    <node TEXT="Home Page Content" FOLDED="true">
      <node TEXT="Image Carousel" FOLDED="true">
        <node TEXT="Community Health Centers Of Lane County" FOLDED="true"/>
        <node TEXT="Eugene, Oregon" FOLDED="true"/>
      </node>
      <node TEXT="Medication Search Form" FOLDED="true">
        <node TEXT="Text Field: Enter a medication" FOLDED="true"/>
        <node TEXT="Button: FIND 340B PRICES" FOLDED="true"/>
      </node>
      <node TEXT="What is 340B? Section" FOLDED="true">
        <node TEXT="Description: For the past 25 years, 340B has helped provide low-cost medications and better health..." FOLDED="true"/>
        <node TEXT="Link: What is 340B?" LINK="https://www.340bpriceguide.net/articles-news/50-what-is-340b" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_50-what-is-340b.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Weekly Product Shortages" FOLDED="true">
        <node TEXT="Link: Weekly Product Shortages" LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Logo" FOLDED="true"/>
      <node TEXT="Useful Links" FOLDED="true">
        <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/index.php" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_about-us.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Articles   News" LINK="https://www.340bpriceguide.net/index.php/articles-news" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_articles-news.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_contact-us.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information" FOLDED="true">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us" FOLDED="true">
        <node TEXT="Address: 501 Fourth Street, #854 Lake Oswego, OR 97034" FOLDED="true"/>
        <node TEXT="Phone: (503)298-0681" FOLDED="true"/>
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" FOLDED="true"/>
      </node>
      <node TEXT="External Resource" FOLDED="true">
        <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/http_www.hrsa.gov_opa.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="TOP" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net.png" width="500" height="250"/>
        </p>
      </body>
    </html></richcontent></node></node>
    </node>
  </node>
</node>
  </node>
</map>
