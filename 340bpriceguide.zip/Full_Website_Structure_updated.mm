<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home Page">
    <node TEXT="Header">
      <node TEXT="Logo: 340B PRICE GUIDE" />
      <node TEXT="Navigation">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/" />
        <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search" />
        <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news" />
        <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us" />
        <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us" />
      </node>
      <node TEXT="Search Icon" />
    </node>
    <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search">
      <node TEXT="Frequently Searched Products">
        <node TEXT="ADVAIR HFA 230-21 MCG INHALER">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#382" />
        </node>
        <node TEXT="BREO ELLIPTA 100-25 MCG INHALR">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2387" />
        </node>
        <node TEXT="BUTRANS 5 MCG/HR PATCH">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2829" />
        </node>
        <node TEXT="DULERA 200 MCG-5 MCG INHALER">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#6302" />
        </node>
        <node TEXT="FARXIGA 10 MG TABLET">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#7308" />
        </node>
        <node TEXT="JANUVIA 100 MG TABLET">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9856" />
        </node>
        <node TEXT="JARDIANCE 10 MG TABLET">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9864" />
        </node>
        <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10370" />
        </node>
        <node TEXT="LIDOCAINE 5% PATCH">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10863" />
        </node>
        <node TEXT="LYRICA 100 MG CAPSULE">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#11489" />
        </node>
        <node TEXT="PROAIR RESPICLICK 90 MCG INHLR">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#15844" />
        </node>
        <node TEXT="TRADJENTA 5 MG TABLET">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#18799" />
        </node>
        <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19218" />
        </node>
        <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19879" />
        </node>
        <node TEXT="XARELTO 10 MG TABLET">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#20198" />
        </node>
      </node>
      <node TEXT="Comments Section">
        <node TEXT="Search Comments Form">
          <node TEXT="Search Comments (input)" />
          <node TEXT="Sort by (dropdown)" />
        </node>
        <node TEXT="Load more comments Button">
          <node TEXT="Load more comments" />
        </node>
      </node>
    </node>
    <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news">
      <node TEXT="Featured Articles">
        <node TEXT="Weekly Product Shortages">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" />
        </node>
        <node TEXT="Manufacturer 340B Restrictions for Oregon">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" />
        </node>
        <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" />
        </node>
        <node TEXT="Bausch Health Exits the 340B Drug Pricing Program">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" />
        </node>
      </node>
      <node TEXT="More Articles">
        <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" />
        <node TEXT="Communication from BPHC announcing new award terms" LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" />
        <node TEXT="Rite Aid Winds Down 340B Operations" LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" />
        <node TEXT="Continued Brand Name Victoza Shortages" LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" />
      </node>
      <node TEXT="Pagination">
        <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4" />
        <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8" />
        <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12" />
        <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16" />
        <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20" />
        <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4" />
        <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=20" />
      </node>
    </node>
    <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us">
      <node TEXT="340B Price Guide Overview">
        <node TEXT="Summary: Customized publication for health organizations to understand 340B drug pricing." />
      </node>
      <node TEXT="340B Guided Services">
        <node TEXT="Summary: Independent consulting and guidance for 340B program management and best practices." />
      </node>
      <node TEXT="Client Testimonials">
        <node TEXT="Summary: User feedback highlighting benefits and experiences with 340B Price Guide." />
      </node>
      <node TEXT="Partners   Clients">
        <node TEXT="Summary: Logos of health organizations and clinics served by 340B Price Guide." />
      </node>
    </node>
    <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us">
      <node TEXT="Contact Form">
        <node TEXT="Fields">
          <node TEXT="Name" />
          <node TEXT="Email" />
          <node TEXT="Company" />
          <node TEXT="Address" />
          <node TEXT="City, State Zip" />
          <node TEXT="Phone" />
          <node TEXT="Inquiry Type" />
          <node TEXT="Comment or Question" />
          <node TEXT="Captcha" />
        </node>
        <node TEXT="Submit Button">
          <node TEXT="SUBMIT" />
        </node>
      </node>
    </node>
    <node TEXT="Home Page Content">
      <node TEXT="Hero Section">
        <node TEXT="Image Carousel" />
        <node TEXT="Community Health Centers Of Lane County" />
        <node TEXT="Search Form">
          <node TEXT="Enter a medication (text field)" />
          <node TEXT="FIND 340B PRICES (button)" />
        </node>
      </node>
      <node TEXT="What is 340B?">
        <node TEXT="Description: For the past 25 years, 340B has helped provide low-cost medications and better health..." />
        <node TEXT="Learn More" LINK="https://www.340bpriceguide.net/articles-news/50-what-is-340b" />
      </node>
      <node TEXT="Weekly Product Shortages">
        <node TEXT="View Weekly Product Shortages" LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" />
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Logo: 340B PRICE GUIDE" />
      <node TEXT="Useful Links">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/index.php" />
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" />
        <node TEXT="Articles   News" LINK="https://www.340bpriceguide.net/index.php/articles-news" />
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" />
      </node>
      <node TEXT="Information">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" />
      </node>
      <node TEXT="Contact Us">
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" />
        <node TEXT="Address: 501 Fourth Street, #854, Lake Oswego, OR 97034" />
        <node TEXT="Phone: (503)298-0681" />
      </node>
      <node TEXT="Legal   Resources">
        <node TEXT="HRSA OPA" LINK="http://www.hrsa.gov/opa" />
      </node>
    </node>
    <node TEXT="Login / Signup" LINK="https://www.340bpriceguide.net/client-login?view=registration">
      <node TEXT="Forgot your password?" LINK="https://www.340bpriceguide.net/client-login?view=reset" />
      <node TEXT="Forgot your username?" LINK="https://www.340bpriceguide.net/client-login?view=remind" />
    </node>
  </node>
</map>