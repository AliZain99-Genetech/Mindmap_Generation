<map version="1.0.1">
  <node TEXT="Contact">
    <node TEXT="Contact Form">
      <node TEXT="Name (required)"/>
      <node TEXT="Email (required)"/>
      <node TEXT="Company"/>
      <node TEXT="Address"/>
      <node TEXT="City, State Zip"/>
      <node TEXT="Phone"/>
      <node TEXT="Inquiry Type (dropdown, required)"/>
      <node TEXT="Comment or Question (textarea)"/>
      <node TEXT="Captcha"/>
      <node TEXT="Submit Button"/>
    </node>
  </node>
</map>