<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home - 340B Price Guide">
    <node TEXT="Header">
      <node TEXT="Logo" />
      <node TEXT="Navigation">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/" />
        <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search" />
        <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news" />
        <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us" />
        <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us" />
        <node TEXT="Profile" LINK="https://www.340bpriceguide.net/my-profile" />
        <node TEXT="Logout" LINK="https://www.340bpriceguide.net/logout" />
        <node TEXT="SecureMsg" LINK="https://www.340bpriceguide.net/secure-message" />
      </node>
      <node TEXT="Search Icon" />
    </node>
    <node TEXT="Home Page Content">
      <node TEXT="Image Carousel">
        <node TEXT="Community Health Centers Of Lane County" />
        <node TEXT="Location: Eugene, Oregon" />
      </node>
      <node TEXT="Medication Search Form">
        <node TEXT="Text Field: Enter a medication" />
        <node TEXT="Button: FIND 340B PRICES" />
      </node>
      <node TEXT="What is 340B? Section">
        <node TEXT="Description: For the past 25 years, 340B has helped provide low-cost medications and better health..." />
        <node TEXT="Link: What is 340B?" LINK="https://www.340bpriceguide.net/articles-news/50-what-is-340b" />
      </node>
      <node TEXT="Weekly Product Shortages Section">
        <node TEXT="Link: Weekly Product Shortages" LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" />
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Logo" />
      <node TEXT="Useful Links">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/index.php" />
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" />
        <node TEXT="Articles   News" LINK="https://www.340bpriceguide.net/index.php/articles-news" />
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" />
      </node>
      <node TEXT="Information">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" />
      </node>
      <node TEXT="Contact Us">
        <node TEXT="Address: 501 Fourth Street, #854 Lake Oswego, OR 97034" />
        <node TEXT="Phone: (503)298-0681" />
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" />
      </node>
      <node TEXT="External Resource">
        <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" />
      </node>
      <node TEXT="TOP" LINK="https://www.340bpriceguide.net/" />
    </node>
  </node>
</map>