<map version="1.0.1">
  <node TEXT="Profile">
    <node TEXT="User Overview">
      <node TEXT="Name: Ali Zain (Online)"/>
    </node>
    <node TEXT="Details Section">
      <node TEXT="Summary of user details: Username, First Name, Last Name, Clinic/Hospital, Email, Phone, Pharmacy, Group"/>
      <node TEXT="alizainsharif48@gmail.com">
        <node TEXT="mailto:alizainsharif48@gmail.com"/>
      </node>
    </node>
    <node TEXT="Edit Profile">
      <node TEXT="Edit Profile"/>
    </node>
  </node>
</map>