<map version="1.0.1">
  <node TEXT="Articles">
    <node TEXT="Featured Articles">
      <node TEXT="WEEKLY PRODUCT SHORTAGES">
        <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages"/>
      </node>
      <node TEXT="MANUFACTURER 340B RESTRICTIONS FOR OREGON">
        <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon"/>
      </node>
      <node TEXT="NOVO NORDISK CHANGES PATIENT ASSISTANCE PROGRAM (PAP) 2026">
        <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026."/>
        <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026"/>
      </node>
      <node TEXT="BAUSCH HEALTH EXITS THE 340B DRUG PRICING PROGRAM">
        <node TEXT="Bausch Health has ended its participation in the 340B Drug Pricing Program; products are no longer eligible."/>
        <node TEXT="READ MORE ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program"/>
      </node>
    </node>
    <node TEXT="More Articles">
      <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September">
        <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september"/>
      </node>
      <node TEXT="Communication from BPHC announcing new award terms">
        <node TEXT="Communication from BPHC announcing new award terms" LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms"/>
      </node>
      <node TEXT="Rite Aid Winds Down 340B Operations">
        <node TEXT="Rite Aid Winds Down 340B Operations" LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations"/>
      </node>
      <node TEXT="Continued Brand Name Victoza Shortages">
        <node TEXT="Continued Brand Name Victoza Shortages" LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages"/>
      </node>
    </node>
    <node TEXT="Pagination">
      <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4"/>
      <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8"/>
      <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12"/>
      <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16"/>
      <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20"/>
      <node TEXT="7" LINK="https://www.340bpriceguide.net/articles-news?start=24"/>
      <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4"/>
      <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=24"/>
    </node>
  </node>
</map>