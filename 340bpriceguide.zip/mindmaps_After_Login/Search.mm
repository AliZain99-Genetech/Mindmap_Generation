<map version="1.0.1">
  <node TEXT="Search">
    <node TEXT="Frequently Searched Products">
      <node TEXT="ADVAIR HFA 230-21 MCG INHALER">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#382"/>
      </node>
      <node TEXT="BREO ELLIPTA 100-25 MCG INHALR">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2387"/>
      </node>
      <node TEXT="BUTRANS 5 MCG/HR PATCH">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2829"/>
      </node>
      <node TEXT="DULERA 200 MCG-5 MCG INHALER">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#6302"/>
      </node>
      <node TEXT="FARXIGA 10 MG TABLET">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#7308"/>
      </node>
      <node TEXT="JANUVIA 100 MG TABLET">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9856"/>
      </node>
      <node TEXT="JARDIANCE 10 MG TABLET">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9864"/>
      </node>
      <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10370"/>
      </node>
      <node TEXT="LIDOCAINE 5% PATCH">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10863"/>
      </node>
      <node TEXT="LYRICA 100 MG CAPSULE">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#11489"/>
      </node>
      <node TEXT="PROAIR RESPICLICK 90 MCG INHLR">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#15844"/>
      </node>
      <node TEXT="TRADJENTA 5 MG TABLET">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#18799"/>
      </node>
      <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19218"/>
      </node>
      <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19879"/>
      </node>
      <node TEXT="XARELTO 10 MG TABLET">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#20198"/>
      </node>
    </node>
    <node TEXT="Search Filters">
      <node TEXT="Please assign pharmacy from the portal first!"/>
      <node TEXT="Medication/NDC Search Input"/>
      <node TEXT="Quantity Dropdown"/>
      <node TEXT="Patient Group Dropdown"/>
      <node TEXT="Formulary Dropdown"/>
      <node TEXT="Clear All Data Button"/>
    </node>
    <node TEXT="Comments Section">
      <node TEXT="User comments and replies about 340B pricing and pharmacy issues"/>
      <node TEXT="Search Comments Input"/>
      <node TEXT="Sort by Dropdown"/>
      <node TEXT="Load more comments Button"/>
    </node>
    <node TEXT="Add Comment Form">
      <node TEXT="Comment Textarea"/>
      <node TEXT="Post Button"/>
    </node>
  </node>
</map>