<map version="1.0.1">
  <node TEXT="SecureMsg">
    <node TEXT="Main Content">
      <node TEXT="Community Health Centers Of Lane County - Eugene, Oregon"/>
      <node TEXT="WHAT IS 340B?">
        <node TEXT="340B has helped provide low-cost medications and better health for 25 years."/>
      </node>
      <node TEXT="WEEKLY PRODUCT SHORTAGES"/>
    </node>
    <node TEXT="Form">
      <node TEXT="Medication Search">
        <node TEXT="Text Input: Enter a medication"/>
        <node TEXT="Button: FIND 340B PRICES"/>
      </node>
    </node>
  </node>
</map>