<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home Page">
    <node TEXT="Header">
      <node TEXT="Logo: 340B PRICE GUIDE" />
      <node TEXT="Navigation">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_about-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_contact-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Search Icon" />
    </node>
    <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search">
      <node TEXT="Frequently Searched Products">
        <node TEXT="ADVAIR HFA 230-21 MCG INHALER">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#382"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_382.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="BREO ELLIPTA 100-25 MCG INHALR">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2387"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_2387.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="BUTRANS 5 MCG/HR PATCH">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2829"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_2829.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="DULERA 200 MCG-5 MCG INHALER">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#6302"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_6302.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="FARXIGA 10 MG TABLET">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#7308"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_7308.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="JANUVIA 100 MG TABLET">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9856"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_9856.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="JARDIANCE 10 MG TABLET">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9864"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_9864.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10370"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_10370.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="LIDOCAINE 5% PATCH">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#10863"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_10863.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="LYRICA 100 MG CAPSULE">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#11489"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_11489.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="PROAIR RESPICLICK 90 MCG INHLR">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#15844"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_15844.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="TRADJENTA 5 MG TABLET">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#18799"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_18799.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19218"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_19218.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19879"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_19879.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="XARELTO 10 MG TABLET">
          <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#20198"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_20198.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
      </node>
      <node TEXT="Comments Section">
        <node TEXT="Search Comments Form">
          <node TEXT="Search Comments (input)" />
          <node TEXT="Sort by (dropdown)" />
        </node>
        <node TEXT="Load more comments Button">
          <node TEXT="Load more comments" />
        </node>
      </node>
    <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news">
      <node TEXT="Featured Articles">
        <node TEXT="Weekly Product Shortages">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Manufacturer 340B Restrictions for Oregon">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_144-status-of-manufacturer-340b-restrictions-for-oregon.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_143-changes-to-novo-nordisk-patient-assistance-program-pap-2026.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Bausch Health Exits the 340B Drug Pricing Program">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_142-bausch-health-exits-the-340b-drug-pricing-program.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
      </node>
      <node TEXT="More Articles">
        <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Communication from BPHC announcing new award terms" LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_140-communication-from-bphc-announcing-new-award-terms.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Rite Aid Winds Down 340B Operations" LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_139-rite-aid-winds-down-340b-operations.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Continued Brand Name Victoza Shortages" LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_138-continued-brand-name-victoza-shortages.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Pagination">
        <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_8.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_12.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_16.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=20"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us">
      <node TEXT="340B Price Guide Overview">
        <node TEXT="Summary: Customized publication for health organizations to understand 340B drug pricing." />
      </node>
      <node TEXT="340B Guided Services">
        <node TEXT="Summary: Independent consulting and guidance for 340B program management and best practices." />
      </node>
      <node TEXT="Client Testimonials">
        <node TEXT="Summary: User feedback highlighting benefits and experiences with 340B Price Guide." />
      </node>
      <node TEXT="Partners   Clients">
        <node TEXT="Summary: Logos of health organizations and clinics served by 340B Price Guide." />
      </node>
    <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_about-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us">
      <node TEXT="Contact Form">
        <node TEXT="Fields">
          <node TEXT="Name" />
          <node TEXT="Email" />
          <node TEXT="Company" />
          <node TEXT="Address" />
          <node TEXT="City, State Zip" />
          <node TEXT="Phone" />
          <node TEXT="Inquiry Type" />
          <node TEXT="Comment or Question" />
          <node TEXT="Captcha" />
        </node>
        <node TEXT="Submit Button">
          <node TEXT="SUBMIT" />
        </node>
      </node>
    <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_contact-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Home Page Content">
      <node TEXT="Hero Section">
        <node TEXT="Image Carousel" />
        <node TEXT="Community Health Centers Of Lane County" />
        <node TEXT="Search Form">
          <node TEXT="Enter a medication (text field)" />
          <node TEXT="FIND 340B PRICES (button)" />
        </node>
      </node>
      <node TEXT="What is 340B?">
        <node TEXT="Description: For the past 25 years, 340B has helped provide low-cost medications and better health..." />
        <node TEXT="Learn More" LINK="https://www.340bpriceguide.net/articles-news/50-what-is-340b"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_50-what-is-340b.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Weekly Product Shortages">
        <node TEXT="View Weekly Product Shortages" LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Logo: 340B PRICE GUIDE" />
      <node TEXT="Useful Links">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/index.php"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_about-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Articles   News" LINK="https://www.340bpriceguide.net/index.php/articles-news"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_articles-news.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_contact-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us">
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" />
        <node TEXT="Address: 501 Fourth Street, #854, Lake Oswego, OR 97034" />
        <node TEXT="Phone: (503)298-0681" />
      </node>
      <node TEXT="Legal   Resources">
        <node TEXT="HRSA OPA" LINK="http://www.hrsa.gov/opa"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/http_www.hrsa.gov_opa.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Login / Signup" LINK="https://www.340bpriceguide.net/client-login?view=registration">
      <node TEXT="Forgot your password?" LINK="https://www.340bpriceguide.net/client-login?view=reset"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_client-login_view_reset.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Forgot your username?" LINK="https://www.340bpriceguide.net/client-login?view=remind"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_client-login_view_remind.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_client-login_view_registration.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
  </node>
</map>