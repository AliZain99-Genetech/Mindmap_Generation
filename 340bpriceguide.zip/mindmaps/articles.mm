<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="articles">
    <node TEXT="Featured Articles">
      <node TEXT="Weekly Product Shortages">
        <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" />
      </node>
      <node TEXT="Manufacturer 340B Restrictions for Oregon">
        <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" />
      </node>
      <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026">
        <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" />
      </node>
      <node TEXT="Bausch Health Exits the 340B Drug Pricing Program">
        <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" />
      </node>
    </node>
    <node TEXT="More Articles">
      <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" />
      <node TEXT="Communication from BPHC announcing new award terms" LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" />
      <node TEXT="Rite Aid Winds Down 340B Operations" LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" />
      <node TEXT="Continued Brand Name Victoza Shortages" LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" />
    </node>
    <node TEXT="Pagination">
      <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4" />
      <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8" />
      <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12" />
      <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16" />
      <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20" />
      <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4" />
      <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=20" />
    </node>
  </node>
</map>