<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="contact">
    <node TEXT="Contact Form">
      <node TEXT="Fields">
        <node TEXT="Name" />
        <node TEXT="Email" />
        <node TEXT="Company" />
        <node TEXT="Address" />
        <node TEXT="City, State Zip" />
        <node TEXT="Phone" />
        <node TEXT="Inquiry Type" />
        <node TEXT="Comment or Question" />
        <node TEXT="Captcha" />
      </node>
      <node TEXT="Submit Button">
        <node TEXT="SUBMIT" />
      </node>
    </node>
  </node>
</map>