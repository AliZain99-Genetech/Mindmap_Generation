<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Professional Workforce   Staffing Solutions - Lions   Tigers">
    <node TEXT="Header">
      <node TEXT="Logo" />
      <node TEXT="Navigation">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/">
          <node TEXT="The Power of  ">
            <node TEXT="Introduction">
              <node TEXT="If tomorrow is never promised, then today needs to fulfill more of what we want." />
            </node>
          </node>
          <node TEXT="How it all started: Re-imagining Work   Life">
            <node TEXT="Summary">
              <node TEXT="Created conditions for individuals to thrive on their terms   in community." />
            </node>
            <node TEXT="Video: Story of Brea Starmer" />
          </node>
          <node TEXT="Vision and Mission">
            <node TEXT="Vision: To unlock the full potential of the workforce." />
            <node TEXT="Mission: Strengthen businesses with blended, human-centered teams." />
          </node>
          <node TEXT="Our Values">
            <node TEXT="Community: Nurturing collective action and economic access." />
            <node TEXT="Impact: Ownership, outcomes over output." />
            <node TEXT="Stewardship: Leave things better than we found them." />
            <node TEXT="Courage: Lead with resilience and empathy." />
          </node>
          <node TEXT="Recent Recognition">
            <node TEXT="Awards and Industry Recognition" />
          </node>
          <node TEXT="L T Talent Network">
            <node TEXT="Team Showcase Photos" />
          </node>
          <node TEXT="Staff Team">
            <node TEXT="Brea Starmer (Founder, CEO)">
              <node TEXT="Bio">
                <node TEXT="Bio" LINK="https://lionsandtigers.com/brea-starmer"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_brea-starmer.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/breastarmer"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Ashley Jude (President)">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/ashleyjude"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_ashleyjude.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Lorraine Cunningham (Chief Technology   Financial Officer)">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/cunninghamlorraine"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_cunninghamlorraine.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="LaShunte Portrey (Business Development)">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/lashunteportrey/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_lashunteportrey.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Steven Rowe (Client Experience)">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/sttrowe"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_sttrowe.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Reiko Kono (Client Experience)">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/reiko-kono-161056171/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_reiko-kono-161056171.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Shannon Lee (Client Experience Team)">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/shannon-lee13/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_shannon-lee13.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Nan Jackson (Marketing)">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/nanbjackson"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_nanbjackson.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Miranda Leurquin (Talent Advocacy)">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mirandaleurquin/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_mirandaleurquin.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Jocylynn Kelley (Talent Advocacy)">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/jocylynn-kelley/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_jocylynn-kelley.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Allison Monat (Talent Advocacy)">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/allisonsmonat"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_allisonsmonat.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Mercedes Dunn (Talent Advocacy)">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mercedesdunn/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_mercedesdunn.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Clients">
            <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Talent">
            <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/">
          <node TEXT="Workforce Reimagined">
            <node TEXT="Unlocking the Power of Blended Teams" />
            <node TEXT="Read the Research Report">
              <node TEXT="Link: Read the Research Report" LINK="https://lionsandtigers.com/why-now/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="The American workforce is at an inflection point">
            <node TEXT="Key statistics on workforce changes in 2025 and beyond" />
          </node>
          <node TEXT="Why This Study">
            <node TEXT="Purpose of research and methodology summary" />
            <node TEXT="Brea Starmer">
              <node TEXT="Link: Brea Starmer" LINK="https://www.linkedin.com/in/breastarmer/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Blended Teams: Key Insights">
            <node TEXT="Expert quote: Re-architecting work for flexibility and expertise" />
            <node TEXT="The Data Is In: Blended Teams Work" />
            <node TEXT="Statistics: Skills, quality, innovation as competitive edges" />
          </node>
          <node TEXT="The Value Compounds Over Time">
            <node TEXT="Impact increases with long-term use of blended teams" />
          </node>
          <node TEXT="Why It Matters">
            <node TEXT="Blended teams as a lifeline and future of work" />
          </node>
          <node TEXT="The 2025 Blended Workforce Survey">
            <node TEXT="Overview of Read the Room Advisors' study" />
            <node TEXT="Download Full Survey Report">
              <node TEXT="Link: Download Full Survey Report" LINK="https://lionsandtigers.com/why-now/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/">
          <node TEXT="Built For Fortune 500s   Startups">
            <node TEXT="Powered by 100+ consultants, workforce design   solutions." />
          </node>
          <node TEXT="Working together">
            <node TEXT="Collaborative ROAR methodology co-designs workforce solutions." />
            <node TEXT="ROAR Framework: Results, Ownership, Accountability, Relationship" />
          </node>
          <node TEXT="Engagement Model Built for YOU" LINK="https://lionsandtigers.com/solutions/#engagement-model">
            <node TEXT="Talent available: Full-time   Fractional, Individuals   Teams, Time   Outcome Based" />
            <node TEXT="Team structure and experience levels summary" />
          <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_engagement-model.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets">
            <node TEXT="Communications   Marketing, Operations, Change" />
          <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_capabilities-skillsets.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Client Stories" LINK="https://lionsandtigers.com/solutions/#client-stories">
            <node TEXT="Case study needs: Scale team, inclusivity, product insights, flexibility, domain experts" />
          <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_client-stories.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Work with us">
            <node TEXT="CLIENTS">
              <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="TALENT">
              <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/">
          <node TEXT="Inclusive community   open roles">
            <node TEXT="Explore open roles">
              <node TEXT="EXPLORE OPEN ROLES">
                <node TEXT="https://lionsandtigers.com/join-our-team/#open-roles" />
              </node>
            </node>
          </node>
          <node TEXT="What it means to be a great place to work">
            <node TEXT="Summary: Flexibility, community, values, growth, remote work, DEI, transparency, fun" />
            <node TEXT="DEI">
              <node TEXT="more">
                <node TEXT="https://lionsandtigers.com/dei" />
              </node>
            </node>
          </node>
          <node TEXT="Open Roles">
            <node TEXT="Open jobs board and positions listing" />
          </node>
          <node TEXT="Talent Newsletter">
            <node TEXT="Subscribe for open roles   updates (form)">
              <node TEXT="Field: Enter Your email address" />
              <node TEXT="Button: SUBSCRIBE" />
            </node>
          </node>
          <node TEXT="Consultant stats   highlights">
            <node TEXT="Retention rate, payouts, remote/hybrid stats, women ratio summary" />
          </node>
          <node TEXT="What Happens After You Apply">
            <node TEXT="Application process steps summarized" />
            <node TEXT="CONSULTANT FAQ">
              <node TEXT="CONSULTANT FAQ">
                <node TEXT="https://lionsandtigers.com/consultant-faq/" />
              </node>
            </node>
          </node>
          <node TEXT="From Our Team">
            <node TEXT="Testimonial quote" />
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Resources">
          <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/">
            <node TEXT="Main Content">
              <node TEXT="Avoiding the All-Or-Nothing Workplace: Enabling People to Operate at their Highest   Best Use">
                <node TEXT="Brea Starmer, Founder/CEO of Lions   Tigers" LINK="https://lionsandtigers.com/brea-starmer/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_brea-starmer.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Download a pdf of the playbook" LINK="https://lionsandtigers.com/playbook-download/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_playbook-download.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="audio version." LINK="https://player.captivate.fm/episode/ae64d6e2-5fb9-49fb-95e8-46d0a2433c68"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_player.captivate.fm_episode_ae64d6e2-5fb9-49fb-95e8-46d0a2433c68.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Contents Summary:">
                <node TEXT="Future Now of Work" />
                <node TEXT="Reimagining the Workplace with the Highest   Best Use Operating System™" />
                <node TEXT="Our Process of Establishing HBU" />
                <node TEXT="Blending Our Workforce: Example" />
                <node TEXT="Building the Plane While You Fly It" />
                <node TEXT="A Few Things to Dream About" />
                <node TEXT="In Conclusion" />
              </node>
            </node>
            <node TEXT="Visible Sections">
              <node TEXT="The Future Now of Work">
                <node TEXT="How I Lost My Job and Found My Way" />
                <node TEXT="The Workplace Isn’t Working for Everyone" />
                <node TEXT="The “Great Resignation”" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#great-resignation"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_great-resignation.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="We’re Losing Those We Most Seek" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#losing-those-we-seek"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_losing-those-we-seek.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Where’d They Go? 50% Independent" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#whered-they-go"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_whered-they-go.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Pew Research Center’s resignation findings" LINK="https://www.pewresearch.org/fact-tank/2022/03/09/majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disrespected/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.pewresearch.org_fact-tank_2022_03_09_majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disres.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="business leaders say they are highly committed" LINK="https://www.mckinsey.com/featured-insights/diversity-and-inclusion/women-in-the-workplace"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.mckinsey.com_featured-insights_diversity-and-inclusion_women-in-the-workplace.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="since 75% of American women would go broke while taking 8 weeks of leave" LINK="https://www.fatherly.com/news/75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.fatherly.com_news_75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="30-year low." LINK="https://en.wikipedia.org/wiki/Labor_force_in_the_United_States#cite_note-45"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_en.wikipedia.org_wiki_Labor_force_in_the_United_States_cite_note-45.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="employees age 30 to 45" LINK="https://www.superstaff.com/blog/top-20-great-resignation-statistics/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.superstaff.com_blog_top-20-great-resignation-statistics.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="One-third" LINK="https://www.latimes.com/politics/story/2021-08-18/pandemic-pushes-moms-to-scale-back-or-quit-their-careers"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.latimes.com_politics_story_2021-08-18_pandemic-pushes-moms-to-scale-back-or-quit-their-careers.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="disappeared from the workforce" LINK="https://www.fastcompany.com/90848858/women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.fastcompany.com_90848858_women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="black female labor participation" LINK="https://www.businessinsider.com/black-women-leaving-corporate-america-entreprenurship-startups-2022-12"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.businessinsider.com_black-women-leaving-corporate-america-entreprenurship-startups-2022-12.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="McKinsey" LINK="https://www.mckinsey.com/capabilities/people-and-organizational-performance/our-insights/great-attrition-or-great-attraction-the-choice-is-yours"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.mckinsey.com_capabilities_people-and-organizational-performance_our-insights_great-attrition-or-great-attraction-the-choice-is-yours.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="70 million Americans" LINK="https://www.zippia.com/advice/how-many-freelancers-in-the-us/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.zippia.com_advice_how-many-freelancers-in-the-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Gallup survey" LINK="https://www.gallup.com/workplace/397751/returning-office-current-preferred-future-state-remote-work.aspx"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.gallup.com_workplace_397751_returning-office-current-preferred-future-state-remote-work.aspx.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="research shows" LINK="https://www.vox.com/recode/23129752/work-from-home-productivity"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.vox.com_recode_23129752_work-from-home-productivity.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="We Must Adopt Blended Work Ecosystems">
                <node TEXT="MITSloan" LINK="https://shop.sloanreview.mit.edu/store/workforce-ecosystems-a-new-strategic-approach-to-the-future-of-work"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_shop.sloanreview.mit.edu_store_workforce-ecosystems-a-new-strategic-approach-to-the-future-of-work.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="A.team" LINK="http://www.a.team/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/http_www.a.team.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="HBR, BCG" LINK="https://www.hbs.edu/managing-the-future-of-work/Documents/Building_The_On_Demand_Workforce.pdf"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.hbs.edu_managing-the-future-of-work_Documents_Building_The_On_Demand_Workforce.pdf.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="The Era of Sustainability: Measuring Impact Over Hours" />
              <node TEXT="Reimagining the Workplace with the Highest   Best Use Operating System™">
                <node TEXT="The Highest   Best Use Operating System" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-op-system"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_hbu-op-system.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="The 3Ms of HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#3ms-hbu"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_3ms-hbu.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Applying the 3Ms to our Blended Work Ecosystem" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#3ms-blended-work"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_3ms-blended-work.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Our Process of Establishing HBU">
                <node TEXT="First Step: Highest   Best ORGANIZATION" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-organization"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_hbu-organization.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Second Step: Highest   Best YOU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-you"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_hbu-you.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Third Step: Highest   Best COMMUNITY" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-community"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_hbu-community.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Stitching It All Together: Your Ecosystem is Unique" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#stitching-it-all-together"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_stitching-it-all-together.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Unlocking HBU: High-EQ Change Management" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#unlocking-hbu"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_unlocking-hbu.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Blending Our Workforce: Natalie’s Example" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#natalies-example"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_natalies-example.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Building the Plane While You Fly It">
                <node TEXT="Very Practical Advice for Proliferating HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#practical-advice"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_practical-advice.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="How to Convince Your Boss or Peers You Need HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#convince-your-boss"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_convince-your-boss.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="The P L Benefits of a Blended Workforce" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#benefits-of-blended"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_benefits-of-blended.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Human Resources vs Procurement: Who Manages the Blended Workforce?" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hr-procurement"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_hr-procurement.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="A Few Things to Dream About">
                <node TEXT="Every Org Needs a “Gig Economy”" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#gig-economy"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_gig-economy.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Commitments to Diversity are Now Public" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#commitments-to-diversity"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_commitments-to-diversity.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Portable Benefits for Independent Workers" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#portable-benefits"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_portable-benefits.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Hybrid   Flex Work Permanence" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#work-permanence"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_work-permanence.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="In Conclusion" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#conclusion"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_conclusion.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Where to from here?">
                <node TEXT="Download a pdf version" LINK="https://lionsandtigers.com/playbook-download/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_playbook-download.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Reach out to our team" LINK="https://lionsandtigers.com/talk-to-us/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Subscribe to the newsletter" LINK="https://lionsandtigers.com/newsletter/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_newsletter.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Follow Brea on LinkedIn" LINK="https://www.linkedin.com/in/breastarmer/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Check out our blog" LINK="https://lionsandtigers.com/blog/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
          <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/">
            <node TEXT="Courage at Work">
              <node TEXT="Overview">Here you can find thought leadership, best practices, news, and stories about people &amp; impact.</node>
            </node>
            <node TEXT="Main Categories">
              <node TEXT="Thought Leadership   Best Practices">
                <node TEXT="thought leadership" LINK="https://lionsandtigers.com/category/thought-leadership/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_thought-leadership.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="best practices" LINK="https://lionsandtigers.com/category/best-practices/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_best-practices.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="New   Noteworthy">
                <node TEXT="new" LINK="https://lionsandtigers.com/category/new/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_new.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="noteworthy" LINK="https://lionsandtigers.com/category/noteworthy/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_noteworthy.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="People   Projects">
                <node TEXT="people" LINK="https://lionsandtigers.com/category/people/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_people.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Featured Blog Posts">
              <node TEXT="Workforce Reimagined Research Launch Event">
                <node TEXT="read more" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_workforce-reimagined-research-launch-event.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic">
                <node TEXT="read more" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Building Better Workplaces for Women: 3 Power Moves to Help You Grow, Lead, and Thrive">
                <node TEXT="read more" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Elevating Culture   Community: Miranda Leurquin’s New Chapter at L T">
                <node TEXT="read more" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_elevating-culture-community-miranda-hickmans-new-chapter-at-lt.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Newsletter Signup">
              <node TEXT="Form">
                <node TEXT="Email" />
                <node TEXT="SUBSCRIBE" />
              </node>
              <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_newsletter.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Media">
              <node TEXT="Take me there" LINK="https://lionsandtigers.com/media/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_media.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Pagination">
              <node TEXT=" laquo; Older Entries" LINK="https://lionsandtigers.com/blog/page/2/?et_blog"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog_page_2_et_blog.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/">
            <node TEXT="Client Newsletter">
              <node TEXT="Summary: Solutions, success stories, best practices, thought leadership" />
              <node TEXT="Form">
                <node TEXT="Email Input" />
                <node TEXT="SUBSCRIBE Button" />
              </node>
            </node>
            <node TEXT="Talent Newsletter">
              <node TEXT="Summary: Open roles, events, talent news, Role Call newsletter" />
              <node TEXT="Form">
                <node TEXT="Email Input" />
                <node TEXT="SUBSCRIBE Button" />
              </node>
            </node>
            <node TEXT="Work with us">
              <node TEXT="CLIENTS">
                <node TEXT="TALK TO US">
                  <node TEXT="https://lionsandtigers.com/talk-to-us/" />
                </node>
              </node>
              <node TEXT="TALENT">
                <node TEXT="JOIN OUR TEAM">
                  <node TEXT="https://lionsandtigers.com/join-our-team/" />
                </node>
              </node>
            </node>
          <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_newsletter.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/">
          <node TEXT="Page Introduction">
            <node TEXT="Consultant inquiry section and invitation to join team" />
            <node TEXT="Learn more about joining team">
              <node TEXT="here">
                <node TEXT="https://lionsandtigers.com/join-our-team" />
              </node>
            </node>
          </node>
          <node TEXT="Contact Form">
            <node TEXT="First Name" />
            <node TEXT="Last Name" />
            <node TEXT="Title" />
            <node TEXT="Organization" />
            <node TEXT="Email" />
            <node TEXT="Phone" />
            <node TEXT="Message" />
            <node TEXT="Captcha (1 + 11 = )" />
            <node TEXT="Submit Button" />
          </node>
        <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Home Page">
      <node TEXT="Hero Section">
        <node TEXT="Build Your Dream Team" />
        <node TEXT="Description">
          <node TEXT="Highly skilled marketing, comms, operations   change specialists waiting for you. Drive your business   your people forward – no compromises." />
        </node>
        <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Hero Image" />
      </node>
      <node TEXT="Trusted By">
        <node TEXT="Logos">
          <node TEXT="XBOX" />
          <node TEXT="ada developers academy" />
          <node TEXT="Alaska Airlines" />
          <node TEXT="GitHub" />
          <node TEXT="Microsoft" />
          <node TEXT="Minecraft" />
          <node TEXT="Tribute" />
        </node>
      </node>
      <node TEXT="Model Section">
        <node TEXT="Our model fits your needs   our people" />
        <node TEXT="Description">
          <node TEXT="We design the solutions that fit your needs – today   tomorrow." />
        </node>
        <node TEXT="Model Types">
          <node TEXT="Full-time   Fractional" />
          <node TEXT="Individuals   Teams" />
          <node TEXT="Time   Outcome Based" />
        </node>
      </node>
      <node TEXT="Client Testimonial">
        <node TEXT="A Word From Our Clients" />
        <node TEXT="Testimonial Quote" />
        <node TEXT="Client Name">
          <node TEXT="DeAnna Paddleford" />
          <node TEXT="Change Management Strategy Lead" />
        </node>
      </node>
      <node TEXT="Culture Section">
        <node TEXT="Want to build a culture of high performance   belonging?" />
        <node TEXT="Description">
          <node TEXT="We built a playbook for leaders who are thinking about workforce innovation and need a system for change. Our Highest   Best Use Operating System™ maximizes human potential aligned to business outcomes, while guarding against burnout and exclusion." />
        </node>
        <node TEXT="LEARN MORE Button" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Vision   Mission">
        <node TEXT="Vision">
          <node TEXT="To unlock the full potential of the workforce." />
        </node>
        <node TEXT="Mission">
          <node TEXT="We strengthen businesses with the power of the independent workforce by building blended, human-centered teams." />
        </node>
        <node TEXT="OUR STORY Button" LINK="https://lionsandtigers.com/our-story/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Team Image" />
        <node TEXT="Team Diversity Note">
          <node TEXT="Our team self-identifies as 87% women." />
        </node>
      </node>
      <node TEXT="Work With Us">
        <node TEXT="Clients">
          <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Talent">
          <node TEXT="JOIN OUR TEAM Button" LINK="https://lionsandtigers.com/join-our-team/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Company Info">
        <node TEXT="Lions   Tigers Logo" />
        <node TEXT="Professional Staffing   Workforce Solutions Partner" />
      </node>
      <node TEXT="About Us">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="DEI" LINK="https://lionsandtigers.com/dei/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_dei.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Solutions">
        <node TEXT="Working Together" LINK="https://lionsandtigers.com/solutions/#working-together"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_working-together.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Engagement Model" LINK="https://lionsandtigers.com/solutions/#engagement-model"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_engagement-model.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_capabilities-skillsets.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_client-stories.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Resources">
        <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Media" LINK="https://lionsandtigers.com/media/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_media.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="General Inquiries" LINK="https://lionsandtigers.com/general-inquiries/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_general-inquiries.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Newsletter">
        <node TEXT="Description">
          <node TEXT="Learn about our solutions, our success stories, best practices, and thought leadership." />
        </node>
        <node TEXT="Newsletter Form">
          <node TEXT="Email (input field)" />
          <node TEXT="SUBSCRIBE (button)" />
        </node>
      </node>
      <node TEXT="Social Media">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_company_lionsandtigers.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_twitter.com_lionstigersco.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.instagram.com_lionstigersco.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.youtube.com_lionstigersco.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Privacy Policy" LINK="https://lionsandtigers.com/privacy-policy/"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_privacy-policy.png" width="500" height="250" />
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
  </node>
</map>