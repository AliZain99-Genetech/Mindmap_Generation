<map version="1.0.1">
<node TEXT="Test Cases" POSITION="left" FOLDED="true">
    <node TEXT="Our Story Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Our Story' link in the header navigates the user to the correct 'Our Story' page."/>
            <node TEXT="2. The 'Our Story' page loads all main content sections, including introduction, vision, mission, and values."/>
            <node TEXT="3. The 'Our Story' page displays the company video and it plays when clicked."/>
            <node TEXT="4. All team member bios on the 'Our Story' page are accessible and open in a new tab when clicked."/>
            <node TEXT="5. The 'Our Story' page displays recent recognition badges and awards correctly."/>
            <node TEXT="6. The 'Our Story' navigation link is visually highlighted when the user is on the page."/>
            <node TEXT="7. The 'Our Story' page is accessible from every other main page via the header navigation."/>
            <node TEXT="8. The 'Our Story' page loads within 3 seconds on a standard broadband connection."/>
            <node TEXT="9. The 'Our Story' page is scrollable and all sections are reachable via scrolling."/>
            <node TEXT="10. The 'Our Story' page displays the staff team grid with correct images and names."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. If the 'Our Story' page URL is manually altered to a non-existent path, a 404 error page is displayed."/>
            <node TEXT="2. If the 'Our Story' video fails to load, an appropriate error message or fallback image is shown."/>
            <node TEXT="3. If a team member's bio link is broken, the user is notified or redirected to a default profile page."/>
            <node TEXT="4. If the 'Our Story' page is accessed without internet connectivity, a browser error is shown."/>
            <node TEXT="5. If the recognition badges fail to load, the page does not crash and displays placeholder images."/>
            <node TEXT="6. If the 'Our Story' link is removed from the header, the page is not accessible via navigation."/>
            <node TEXT="7. If the user tries to submit a form on the 'Our Story' page with missing required fields, an error is shown."/>
            <node TEXT="8. If the page is loaded with JavaScript disabled, essential content is still visible."/>
            <node TEXT="9. If the staff team grid fails to load images, alt text is displayed for each image."/>
            <node TEXT="10. If the user clicks the 'Our Story' link multiple times rapidly, only one navigation event occurs."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The 'Our Story' page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="2. The 'Our Story' page is responsive and displays correctly on mobile, tablet, and desktop devices."/>
            <node TEXT="3. The 'Our Story' page loads in under 2 seconds on a high-speed connection."/>
            <node TEXT="4. The 'Our Story' page supports screen readers for all main content and navigation."/>
            <node TEXT="5. The 'Our Story' page maintains layout integrity across Chrome, Firefox, Safari, and Edge browsers."/>
            <node TEXT="6. The 'Our Story' page does not exceed 2MB in total page size."/>
            <node TEXT="7. The 'Our Story' page is protected against XSS and CSRF vulnerabilities."/>
            <node TEXT="8. The 'Our Story' page's video player is keyboard accessible."/>
            <node TEXT="9. The 'Our Story' page's images are optimized for fast loading."/>
            <node TEXT="10. The 'Our Story' page's navigation link is always visible and accessible in the header."/>
        </node>
    </node>
    <node TEXT="Why Now Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Why Now' link in the header navigates the user to the 'Why Now' page."/>
            <node TEXT="2. The 'Why Now' page displays the research report summary and key statistics."/>
            <node TEXT="3. The 'Why Now' page provides a working link to download the full survey report."/>
            <node TEXT="4. The 'Why Now' page displays expert quotes and insights as intended."/>
            <node TEXT="5. The 'Why Now' navigation link is visually highlighted when the user is on the page."/>
            <node TEXT="6. The 'Why Now' page is accessible from every other main page via the header navigation."/>
            <node TEXT="7. The 'Why Now' page loads all infographics and data visualizations correctly."/>
            <node TEXT="8. The 'Why Now' page allows users to click on external references and open them in new tabs."/>
            <node TEXT="9. The 'Why Now' page is scrollable and all sections are reachable via scrolling."/>
            <node TEXT="10. The 'Why Now' page displays the 'Read the Research Report' button and it functions as expected."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. If the 'Why Now' page URL is manually altered to a non-existent path, a 404 error page is displayed."/>
            <node TEXT="2. If the research report download link is broken, an error message is shown to the user."/>
            <node TEXT="3. If an infographic fails to load, the page displays a placeholder or alt text."/>
            <node TEXT="4. If the 'Why Now' link is removed from the header, the page is not accessible via navigation."/>
            <node TEXT="5. If the user tries to access the 'Why Now' page with JavaScript disabled, essential content is still visible."/>
            <node TEXT="6. If the user clicks the 'Why Now' link multiple times rapidly, only one navigation event occurs."/>
            <node TEXT="7. If the external reference links are broken, the user is notified or redirected to a default page."/>
            <node TEXT="8. If the 'Why Now' page is accessed without internet connectivity, a browser error is shown."/>
            <node TEXT="9. If the data visualizations fail to render, the page does not crash and displays a fallback message."/>
            <node TEXT="10. If the user tries to submit a form on the 'Why Now' page with missing required fields, an error is shown."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The 'Why Now' page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="2. The 'Why Now' page is responsive and displays correctly on mobile, tablet, and desktop devices."/>
            <node TEXT="3. The 'Why Now' page loads in under 2 seconds on a high-speed connection."/>
            <node TEXT="4. The 'Why Now' page supports screen readers for all main content and navigation."/>
            <node TEXT="5. The 'Why Now' page maintains layout integrity across Chrome, Firefox, Safari, and Edge browsers."/>
            <node TEXT="6. The 'Why Now' page does not exceed 2MB in total page size."/>
            <node TEXT="7. The 'Why Now' page is protected against XSS and CSRF vulnerabilities."/>
            <node TEXT="8. The 'Why Now' page's download links are keyboard accessible."/>
            <node TEXT="9. The 'Why Now' page's images and infographics are optimized for fast loading."/>
            <node TEXT="10. The 'Why Now' page's navigation link is always visible and accessible in the header."/>
        </node>
    </node>
    <node TEXT="Solutions Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Solutions' link in the header navigates the user to the 'Solutions' page."/>
            <node TEXT="2. The 'Solutions' page displays all solution offerings, including engagement models and skillsets."/>
            <node TEXT="3. The 'Solutions' page allows users to view client stories and case studies."/>
            <node TEXT="4. The 'Solutions' navigation link is visually highlighted when the user is on the page."/>
            <node TEXT="5. The 'Solutions' page is accessible from every other main page via the header navigation."/>
            <node TEXT="6. The 'Solutions' page displays all images and icons correctly."/>
            <node TEXT="7. The 'Solutions' page allows users to click on 'Work with us' options for clients and talent."/>
            <node TEXT="8. The 'Solutions' page loads all sections, including 'Working Together' and 'Engagement Model'."/>
            <node TEXT="9. The 'Solutions' page is scrollable and all sections are reachable via scrolling."/>
            <node TEXT="10. The 'Solutions' page provides working links to related resources and contact forms."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. If the 'Solutions' page URL is manually altered to a non-existent path, a 404 error page is displayed."/>
            <node TEXT="2. If a client story or case study link is broken, the user is notified or redirected to a default page."/>
            <node TEXT="3. If the 'Solutions' link is removed from the header, the page is not accessible via navigation."/>
            <node TEXT="4. If the user tries to access the 'Solutions' page with JavaScript disabled, essential content is still visible."/>
            <node TEXT="5. If the user clicks the 'Solutions' link multiple times rapidly, only one navigation event occurs."/>
            <node TEXT="6. If images on the 'Solutions' page fail to load, alt text is displayed for each image."/>
            <node TEXT="7. If the 'Work with us' options fail to load, the page does not crash and displays a fallback message."/>
            <node TEXT="8. If the 'Solutions' page is accessed without internet connectivity, a browser error is shown."/>
            <node TEXT="9. If the user submits a form on the 'Solutions' page with missing required fields, an error is shown."/>
            <node TEXT="10. If the engagement model section fails to render, the rest of the page remains functional."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The 'Solutions' page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="2. The 'Solutions' page is responsive and displays correctly on mobile, tablet, and desktop devices."/>
            <node TEXT="3. The 'Solutions' page loads in under 2 seconds on a high-speed connection."/>
            <node TEXT="4. The 'Solutions' page supports screen readers for all main content and navigation."/>
            <node TEXT="5. The 'Solutions' page maintains layout integrity across Chrome, Firefox, Safari, and Edge browsers."/>
            <node TEXT="6. The 'Solutions' page does not exceed 2MB in total page size."/>
            <node TEXT="7. The 'Solutions' page is protected against XSS and CSRF vulnerabilities."/>
            <node TEXT="8. The 'Solutions' page's navigation and links are keyboard accessible."/>
            <node TEXT="9. The 'Solutions' page's images are optimized for fast loading."/>
            <node TEXT="10. The 'Solutions' page's navigation link is always visible and accessible in the header."/>
        </node>
    </node>
    <node TEXT="Join Our Team Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Join Our Team' link in the header navigates the user to the 'Join Our Team' page."/>
            <node TEXT="2. The 'Join Our Team' page displays open roles and job descriptions."/>
            <node TEXT="3. The 'Join Our Team' page allows users to submit applications for open positions."/>
            <node TEXT="4. The 'Join Our Team' navigation link is visually highlighted when the user is on the page."/>
            <node TEXT="5. The 'Join Our Team' page is accessible from every other main page via the header navigation."/>
            <node TEXT="6. The 'Join Our Team' page displays testimonials and team impact statistics."/>
            <node TEXT="7. The 'Join Our Team' page provides a working link to the Consultant FAQ."/>
            <node TEXT="8. The 'Join Our Team' page allows users to sign up for the talent newsletter."/>
            <node TEXT="9. The 'Join Our Team' page is scrollable and all sections are reachable via scrolling."/>
            <node TEXT="10. The 'Join Our Team' page displays all images and graphics correctly."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. If the 'Join Our Team' page URL is manually altered to a non-existent path, a 404 error page is displayed."/>
            <node TEXT="2. If the application form is submitted with missing required fields, an error message is shown."/>
            <node TEXT="3. If the 'Join Our Team' link is removed from the header, the page is not accessible via navigation."/>
            <node TEXT="4. If the Consultant FAQ link is broken, the user is notified or redirected to a default page."/>
            <node TEXT="5. If the user tries to access the 'Join Our Team' page with JavaScript disabled, essential content is still visible."/>
            <node TEXT="6. If the user clicks the 'Join Our Team' link multiple times rapidly, only one navigation event occurs."/>
            <node TEXT="7. If images on the 'Join Our Team' page fail to load, alt text is displayed for each image."/>
            <node TEXT="8. If the open roles section fails to load, the page does not crash and displays a fallback message."/>
            <node TEXT="9. If the talent newsletter signup form is submitted with an invalid email, an error is shown."/>
            <node TEXT="10. If the 'Join Our Team' page is accessed without internet connectivity, a browser error is shown."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The 'Join Our Team' page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="2. The 'Join Our Team' page is responsive and displays correctly on mobile, tablet, and desktop devices."/>
            <node TEXT="3. The 'Join Our Team' page loads in under 2 seconds on a high-speed connection."/>
            <node TEXT="4. The 'Join Our Team' page supports screen readers for all main content and navigation."/>
            <node TEXT="5. The 'Join Our Team' page maintains layout integrity across Chrome, Firefox, Safari, and Edge browsers."/>
            <node TEXT="6. The 'Join Our Team' page does not exceed 2MB in total page size."/>
            <node TEXT="7. The 'Join Our Team' page is protected against XSS and CSRF vulnerabilities."/>
            <node TEXT="8. The 'Join Our Team' page's forms and links are keyboard accessible."/>
            <node TEXT="9. The 'Join Our Team' page's images are optimized for fast loading."/>
            <node TEXT="10. The 'Join Our Team' page's navigation link is always visible and accessible in the header."/>
        </node>
    </node>
    <node TEXT="Hybrid Workplace Playbook Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Hybrid Workplace Playbook' link in the header navigates the user to the playbook page."/>
            <node TEXT="2. The playbook page displays the introduction and overview content."/>
            <node TEXT="3. The playbook page provides a working link to download the PDF version of the playbook."/>
            <node TEXT="4. The playbook page allows users to listen to the audio version by clicking the provided link."/>
            <node TEXT="5. The playbook navigation link is visually highlighted when the user is on the page."/>
            <node TEXT="6. The playbook page is accessible from every other main page via the header navigation."/>
            <node TEXT="7. The playbook page displays all infographics and images correctly."/>
            <node TEXT="8. The playbook page allows users to access referenced external resources."/>
            <node TEXT="9. The playbook page is scrollable and all sections are reachable via scrolling."/>
            <node TEXT="10. The playbook page displays the 'Contact Us' or 'Reach Out' section with working links."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. If the playbook page URL is manually altered to a non-existent path, a 404 error page is displayed."/>
            <node TEXT="2. If the PDF download link is broken, an error message is shown to the user."/>
            <node TEXT="3. If the audio version link is broken, the user is notified or redirected to a default page."/>
            <node TEXT="4. If the playbook link is removed from the header, the page is not accessible via navigation."/>
            <node TEXT="5. If the user tries to access the playbook page with JavaScript disabled, essential content is still visible."/>
            <node TEXT="6. If the user clicks the playbook link multiple times rapidly, only one navigation event occurs."/>
            <node TEXT="7. If images on the playbook page fail to load, alt text is displayed for each image."/>
            <node TEXT="8. If the referenced external resources are broken, the user is notified or redirected to a default page."/>
            <node TEXT="9. If the playbook page is accessed without internet connectivity, a browser error is shown."/>
            <node TEXT="10. If the playbook page's contact form is submitted with missing required fields, an error is shown."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The playbook page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="2. The playbook page is responsive and displays correctly on mobile, tablet, and desktop devices."/>
            <node TEXT="3. The playbook page loads in under 2 seconds on a high-speed connection."/>
            <node TEXT="4. The playbook page supports screen readers for all main content and navigation."/>
            <node TEXT="5. The playbook page maintains layout integrity across Chrome, Firefox, Safari, and Edge browsers."/>
            <node TEXT="6. The playbook page does not exceed 2MB in total page size."/>
            <node TEXT="7. The playbook page is protected against XSS and CSRF vulnerabilities."/>
            <node TEXT="8. The playbook page's download and audio links are keyboard accessible."/>
            <node TEXT="9. The playbook page's images and infographics are optimized for fast loading."/>
            <node TEXT="10. The playbook page's navigation link is always visible and accessible in the header."/>
        </node>
    </node>
    <node TEXT="Blog Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Blog' link in the header navigates the user to the main blog page."/>
            <node TEXT="2. The blog page displays a list of recent blog posts with titles and summaries."/>
            <node TEXT="3. The blog page allows users to filter posts by category, such as 'Thought Leadership' or 'Best Practices'."/>
            <node TEXT="4. The blog navigation link is visually highlighted when the user is on the page."/>
            <node TEXT="5. The blog page is accessible from every other main page via the header navigation."/>
            <node TEXT="6. The blog page allows users to click on a post title to view the full article."/>
            <node TEXT="7. The blog page displays images and author information for each post."/>
            <node TEXT="8. The blog page provides pagination or 'Older Entries' navigation."/>
            <node TEXT="9. The blog page allows users to sign up for the newsletter via a visible form."/>
            <node TEXT="10. The blog page displays featured posts and highlights them appropriately."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. If the blog page URL is manually altered to a non-existent path, a 404 error page is displayed."/>
            <node TEXT="2. If a blog post link is broken, the user is notified or redirected to a default page."/>
            <node TEXT="3. If the blog link is removed from the header, the page is not accessible via navigation."/>
            <node TEXT="4. If the user tries to access the blog page with JavaScript disabled, essential content is still visible."/>
            <node TEXT="5. If the user clicks the blog link multiple times rapidly, only one navigation event occurs."/>
            <node TEXT="6. If images on the blog page fail to load, alt text is displayed for each image."/>
            <node TEXT="7. If the newsletter signup form is submitted with an invalid email, an error is shown."/>
            <node TEXT="8. If the blog page's category filter fails, all posts are still displayed by default."/>
            <node TEXT="9. If the blog page is accessed without internet connectivity, a browser error is shown."/>
            <node TEXT="10. If the pagination or 'Older Entries' link is broken, the user is notified or redirected to the first page."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The blog page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="2. The blog page is responsive and displays correctly on mobile, tablet, and desktop devices."/>
            <node TEXT="3. The blog page loads in under 2 seconds on a high-speed connection."/>
            <node TEXT="4. The blog page supports screen readers for all main content and navigation."/>
            <node TEXT="5. The blog page maintains layout integrity across Chrome, Firefox, Safari, and Edge browsers."/>
            <node TEXT="6. The blog page does not exceed 2MB in total page size."/>
            <node TEXT="7. The blog page is protected against XSS and CSRF vulnerabilities."/>
            <node TEXT="8. The blog page's forms and links are keyboard accessible."/>
            <node TEXT="9. The blog page's images are optimized for fast loading."/>
            <node TEXT="10. The blog page's navigation link is always visible and accessible in the header."/>
        </node>
    </node>
    <node TEXT="Newsletter Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Newsletter' link in the header navigates the user to the newsletter signup page."/>
            <node TEXT="2. The newsletter page displays a form for users to enter their email address."/>
            <node TEXT="3. The newsletter signup form validates email addresses before submission."/>
            <node TEXT="4. The newsletter navigation link is visually highlighted when the user is on the page."/>
            <node TEXT="5. The newsletter page is accessible from every other main page via the header navigation."/>
            <node TEXT="6. The newsletter page displays information about the types of newsletters available."/>
            <node TEXT="7. The newsletter signup form displays a success message upon successful submission."/>
            <node TEXT="8. The newsletter page provides links to client and talent newsletters."/>
            <node TEXT="9. The newsletter page allows users to unsubscribe via a visible link."/>
            <node TEXT="10. The newsletter page displays all images and graphics correctly."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. If the newsletter page URL is manually altered to a non-existent path, a 404 error page is displayed."/>
            <node TEXT="2. If the newsletter signup form is submitted with an invalid email, an error message is shown."/>
            <node TEXT="3. If the newsletter link is removed from the header, the page is not accessible via navigation."/>
            <node TEXT="4. If the user tries to access the newsletter page with JavaScript disabled, essential content is still visible."/>
            <node TEXT="5. If the user clicks the newsletter link multiple times rapidly, only one navigation event occurs."/>
            <node TEXT="6. If images on the newsletter page fail to load, alt text is displayed for each image."/>
            <node TEXT="7. If the newsletter signup form is submitted with a blank field, an error is shown."/>
            <node TEXT="8. If the unsubscribe link is broken, the user is notified or redirected to a default page."/>
            <node TEXT="9. If the newsletter page is accessed without internet connectivity, a browser error is shown."/>
            <node TEXT="10. If the newsletter form submission fails due to server error, an appropriate error message is displayed."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The newsletter page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="2. The newsletter page is responsive and displays correctly on mobile, tablet, and desktop devices."/>
            <node TEXT="3. The newsletter page loads in under 2 seconds on a high-speed connection."/>
            <node TEXT="4. The newsletter page supports screen readers for all main content and navigation."/>
            <node TEXT="5. The newsletter page maintains layout integrity across Chrome, Firefox, Safari, and Edge browsers."/>
            <node TEXT="6. The newsletter page does not exceed 2MB in total page size."/>
            <node TEXT="7. The newsletter page is protected against XSS and CSRF vulnerabilities."/>
            <node TEXT="8. The newsletter page's forms and links are keyboard accessible."/>
            <node TEXT="9. The newsletter page's images are optimized for fast loading."/>
            <node TEXT="10. The newsletter page's navigation link is always visible and accessible in the header."/>
        </node>
    </node>
    <node TEXT="TALK TO US Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'TALK TO US' link in the header navigates the user to the contact page."/>
            <node TEXT="2. The contact page displays a form with required fields for user inquiries."/>
            <node TEXT="3. The contact form validates all required fields before submission."/>
            <node TEXT="4. The 'TALK TO US' navigation link is visually highlighted when the user is on the page."/>
            <node TEXT="5. The contact page is accessible from every other main page via the header navigation."/>
            <node TEXT="6. The contact form displays a success message upon successful submission."/>
            <node TEXT="7. The contact page displays information about how to join the team or become a consultant."/>
            <node TEXT="8. The contact page provides working links to related resources and team pages."/>
            <node TEXT="9. The contact page is scrollable and all sections are reachable via scrolling."/>
            <node TEXT="10. The contact page displays all images and graphics correctly."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. If the contact page URL is manually altered to a non-existent path, a 404 error page is displayed."/>
            <node TEXT="2. If the contact form is submitted with missing required fields, an error message is shown."/>
            <node TEXT="3. If the 'TALK TO US' link is removed from the header, the page is not accessible via navigation."/>
            <node TEXT="4. If the user tries to access the contact page with JavaScript disabled, essential content is still visible."/>
            <node TEXT="5. If the user clicks the 'TALK TO US' link multiple times rapidly, only one navigation event occurs."/>
            <node TEXT="6. If images on the contact page fail to load, alt text is displayed for each image."/>
            <node TEXT="7. If the contact form is submitted with an invalid email, an error is shown."/>
            <node TEXT="8. If the contact form submission fails due to server error, an appropriate error message is displayed."/>
            <node TEXT="9. If the contact page is accessed without internet connectivity, a browser error is shown."/>
            <node TEXT="10. If the related resource links are broken, the user is notified or redirected to a default page."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The contact page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="2. The contact page is responsive and displays correctly on mobile, tablet, and desktop devices."/>
            <node TEXT="3. The contact page loads in under 2 seconds on a high-speed connection."/>
            <node TEXT="4. The contact page supports screen readers for all main content and navigation."/>
            <node TEXT="5. The contact page maintains layout integrity across Chrome, Firefox, Safari, and Edge browsers."/>
            <node TEXT="6. The contact page does not exceed 2MB in total page size."/>
            <node TEXT="7. The contact page is protected against XSS and CSRF vulnerabilities."/>
            <node TEXT="8. The contact page's forms and links are keyboard accessible."/>
            <node TEXT="9. The contact page's images are optimized for fast loading."/>
            <node TEXT="10. The contact page's navigation link is always visible and accessible in the header."/>
        </node>
    </node>
    <node TEXT="Home Page Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Home Page' link in the header navigates the user to the website's main landing page."/>
            <node TEXT="2. The home page displays the hero section with headline, description, and call-to-action button."/>
            <node TEXT="3. The home page displays trusted client logos in the 'Trusted By' section."/>
            <node TEXT="4. The home page displays the model section with all engagement types listed."/>
            <node TEXT="5. The home page displays a client testimonial with name and title."/>
            <node TEXT="6. The home page displays the culture and belonging section with a working 'Learn More' button."/>
            <node TEXT="7. The home page displays the vision and mission statements clearly."/>
            <node TEXT="8. The home page provides working links to 'TALK TO US' and 'JOIN OUR TEAM' sections."/>
            <node TEXT="9. The home page is scrollable and all sections are reachable via scrolling."/>
            <node TEXT="10. The home page displays all images, graphics, and videos correctly."/>
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. If the home page URL is manually altered to a non-existent path, a 404 error page is displayed."/>
            <node TEXT="2. If the hero section's call-to-action button link is broken, the user is notified or redirected to a default page."/>
            <node TEXT="3. If the home page link is removed from the header, the page is not accessible via navigation."/>
            <node TEXT="4. If the user tries to access the home page with JavaScript disabled, essential content is still visible."/>
            <node TEXT="5. If the user clicks the home page link multiple times rapidly, only one navigation event occurs."/>
            <node TEXT="6. If images or videos on the home page fail to load, alt text or fallback content is displayed."/>
            <node TEXT="7. If the 'Trusted By' logos fail to load, the page does not crash and displays placeholders."/>
            <node TEXT="8. If the home page is accessed without internet connectivity, a browser error is shown."/>
            <node TEXT="9. If the 'Learn More' button is broken, the user is notified or redirected to a default page."/>
            <node TEXT="10. If the home page's testimonial section fails to render, the rest of the page remains functional."/>
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The home page meets WCAG 2.1 AA accessibility standards."/>
            <node TEXT="2. The home page is responsive and displays correctly on mobile, tablet, and desktop devices."/>
            <node TEXT="3. The home page loads in under 2 seconds on a high-speed connection."/>
            <node TEXT="4. The home page supports screen readers for all main content and navigation."/>
            <node TEXT="5. The home page maintains layout integrity across Chrome, Firefox, Safari, and Edge browsers."/>
            <node TEXT="6. The home page does not exceed 2MB in total page size."/>
            <node TEXT="7. The home page is protected against XSS and CSRF vulnerabilities."/>
            <node TEXT="8. The home page's navigation and call-to-action buttons are keyboard accessible."/>
            <node TEXT="9. The home page's images and videos are optimized for fast loading."/>
            <node TEXT="10. The home page's navigation link is always visible and accessible in the header."/>
        </node>
    </node>
</node>
</map>