<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Professional Workforce   Staffing Solutions - Lions   Tigers" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Logo" FOLDED="true" />
      <node TEXT="Navigation" FOLDED="true">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" FOLDED="true">
          <node TEXT="The Power of  " FOLDED="true">
            <node TEXT="Introduction" FOLDED="true">
              <node TEXT="If tomorrow is never promised, then today needs to fulfill more of what we want." FOLDED="true" />
              </node>
            </node>
          <node TEXT="How it all started: Re-imagining Work   Life" FOLDED="true">
            <node TEXT="Summary" FOLDED="true">
              <node TEXT="Created conditions for individuals to thrive on their terms   in community." FOLDED="true" />
              </node>
            <node TEXT="Video: Story of Brea Starmer" FOLDED="true" />
            </node>
          <node TEXT="Vision and Mission" FOLDED="true">
            <node TEXT="Vision: To unlock the full potential of the workforce." FOLDED="true" />
            <node TEXT="Mission: Strengthen businesses with blended, human-centered teams." FOLDED="true" />
            </node>
          <node TEXT="Our Values" FOLDED="true">
            <node TEXT="Community: Nurturing collective action and economic access." FOLDED="true" />
            <node TEXT="Impact: Ownership, outcomes over output." FOLDED="true" />
            <node TEXT="Stewardship: Leave things better than we found them." FOLDED="true" />
            <node TEXT="Courage: Lead with resilience and empathy." FOLDED="true" />
            </node>
          <node TEXT="Recent Recognition" FOLDED="true">
            <node TEXT="Awards and Industry Recognition" FOLDED="true" />
            </node>
          <node TEXT="L T Talent Network" FOLDED="true">
            <node TEXT="Team Showcase Photos" FOLDED="true" />
            </node>
          <node TEXT="Staff Team" FOLDED="true">
            <node TEXT="Brea Starmer (Founder, CEO)" FOLDED="true">
              <node TEXT="Bio" FOLDED="true">
                <node TEXT="Bio" LINK="https://lionsandtigers.com/brea-starmer" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_brea-starmer.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/breastarmer" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Ashley Jude (President)" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/ashleyjude" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_ashleyjude.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Lorraine Cunningham (Chief Technology   Financial Officer)" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/cunninghamlorraine" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_cunninghamlorraine.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="LaShunte Portrey (Business Development)" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/lashunteportrey/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_lashunteportrey.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Steven Rowe (Client Experience)" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/sttrowe" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_sttrowe.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Reiko Kono (Client Experience)" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/reiko-kono-161056171/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_reiko-kono-161056171.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Shannon Lee (Client Experience Team)" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/shannon-lee13/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_shannon-lee13.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Nan Jackson (Marketing)" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/nanbjackson" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_nanbjackson.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Miranda Leurquin (Talent Advocacy)" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mirandaleurquin/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_mirandaleurquin.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Jocylynn Kelley (Talent Advocacy)" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/jocylynn-kelley/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_jocylynn-kelley.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Allison Monat (Talent Advocacy)" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/allisonsmonat" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_allisonsmonat.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Mercedes Dunn (Talent Advocacy)" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mercedesdunn/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_mercedesdunn.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            </node>
          <node TEXT="Clients" FOLDED="true">
            <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true">
              <node TEXT="Screenshot Example" FOLDED="true">
                <richcontent TYPE="NODE">
                  <html>
                    <body>
                      <p>
                        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
                        </p>
                      </body>
                    </html>
                  </richcontent>
                </node>
              </node>
            </node>
          <node TEXT="Talent" FOLDED="true">
            <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true">
              <node TEXT="Screenshot Example" FOLDED="true">
                <richcontent TYPE="NODE">
                  <html>
                    <body>
                      <p>
                        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250" />
                        </p>
                      </body>
                    </html>
                  </richcontent>
                </node>
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" FOLDED="true">
          <node TEXT="Workforce Reimagined" FOLDED="true">
            <node TEXT="Unlocking the Power of Blended Teams" FOLDED="true" />
            <node TEXT="Read the Research Report" FOLDED="true">
              <node TEXT="Link: Read the Research Report" LINK="https://lionsandtigers.com/why-now/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            </node>
          <node TEXT="The American workforce is at an inflection point" FOLDED="true">
            <node TEXT="Key statistics on workforce changes in 2025 and beyond" FOLDED="true" />
            </node>
          <node TEXT="Why This Study" FOLDED="true">
            <node TEXT="Purpose of research and methodology summary" FOLDED="true" />
            <node TEXT="Brea Starmer" FOLDED="true">
              <node TEXT="Link: Brea Starmer" LINK="https://www.linkedin.com/in/breastarmer/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            </node>
          <node TEXT="Blended Teams: Key Insights" FOLDED="true">
            <node TEXT="Expert quote: Re-architecting work for flexibility and expertise" FOLDED="true" />
            <node TEXT="The Data Is In: Blended Teams Work" FOLDED="true" />
            <node TEXT="Statistics: Skills, quality, innovation as competitive edges" FOLDED="true" />
            </node>
          <node TEXT="The Value Compounds Over Time" FOLDED="true">
            <node TEXT="Impact increases with long-term use of blended teams" FOLDED="true" />
            </node>
          <node TEXT="Why It Matters" FOLDED="true">
            <node TEXT="Blended teams as a lifeline and future of work" FOLDED="true" />
            </node>
          <node TEXT="The 2025 Blended Workforce Survey" FOLDED="true">
            <node TEXT="Overview of Read the Room Advisors' study" FOLDED="true" />
            <node TEXT="Download Full Survey Report" FOLDED="true">
              <node TEXT="Link: Download Full Survey Report" LINK="https://lionsandtigers.com/why-now/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                <node TEXT="Triggers file or report download." FOLDED="true">
                  <node TEXT="Triggers file or report download." FOLDED="true" />
                  </node>
                </node>
              <node TEXT="Triggers file or report download." FOLDED="true">
                <node TEXT="Triggers file or report download." FOLDED="true" />
                </node>
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/" FOLDED="true">
          <node TEXT="Built For Fortune 500s   Startups" FOLDED="true">
            <node TEXT="Powered by 100+ consultants, workforce design   solutions." FOLDED="true" />
            </node>
          <node TEXT="Working together" FOLDED="true">
            <node TEXT="Collaborative ROAR methodology co-designs workforce solutions." FOLDED="true" />
            <node TEXT="ROAR Framework: Results, Ownership, Accountability, Relationship" FOLDED="true" />
            </node>
          <node TEXT="Engagement Model Built for YOU" LINK="https://lionsandtigers.com/solutions/#engagement-model" FOLDED="true">
            <node TEXT="Talent available: Full-time   Fractional, Individuals   Teams, Time   Outcome Based" FOLDED="true" />
            <node TEXT="Team structure and experience levels summary" FOLDED="true" />
            <node TEXT="Screenshot Example" FOLDED="true">
              <richcontent TYPE="NODE">
                <html>
                  <body>
                    <p>
                      <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_engagement-model.png" width="500" height="250" />
                      </p>
                    </body>
                  </html>
                </richcontent>
              </node>
            </node>
          <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" FOLDED="true">
            <node TEXT="Communications   Marketing, Operations, Change" FOLDED="true" />
            <node TEXT="Screenshot Example" FOLDED="true">
              <richcontent TYPE="NODE">
                <html>
                  <body>
                    <p>
                      <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_capabilities-skillsets.png" width="500" height="250" />
                      </p>
                    </body>
                  </html>
                </richcontent>
              </node>
            </node>
          <node TEXT="Client Stories" LINK="https://lionsandtigers.com/solutions/#client-stories" FOLDED="true">
            <node TEXT="Case study needs: Scale team, inclusivity, product insights, flexibility, domain experts" FOLDED="true" />
            <node TEXT="Screenshot Example" FOLDED="true">
              <richcontent TYPE="NODE">
                <html>
                  <body>
                    <p>
                      <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_client-stories.png" width="500" height="250" />
                      </p>
                    </body>
                  </html>
                </richcontent>
              </node>
            </node>
          <node TEXT="Work with us" FOLDED="true">
            <node TEXT="CLIENTS" FOLDED="true">
              <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="TALENT" FOLDED="true">
              <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true">
          <node TEXT="Inclusive community   open roles" FOLDED="true">
            <node TEXT="Explore open roles" FOLDED="true">
              <node TEXT="EXPLORE OPEN ROLES" FOLDED="true">
                <node TEXT="https://lionsandtigers.com/join-our-team/#open-roles" FOLDED="true" />
                </node>
              </node>
            </node>
          <node TEXT="What it means to be a great place to work" FOLDED="true">
            <node TEXT="Summary: Flexibility, community, values, growth, remote work, DEI, transparency, fun" FOLDED="true" />
            <node TEXT="DEI" FOLDED="true">
              <node TEXT="more" FOLDED="true">
                <node TEXT="https://lionsandtigers.com/dei" FOLDED="true" />
                </node>
              </node>
            </node>
          <node TEXT="Open Roles" FOLDED="true">
            <node TEXT="Open jobs board and positions listing" FOLDED="true" />
            </node>
          <node TEXT="Talent Newsletter" FOLDED="true">
            <node TEXT="Subscribe for open roles   updates (form)" FOLDED="true">
              <node TEXT="Field: Enter Your email address" FOLDED="true" />
              <node TEXT="Button: SUBSCRIBE" FOLDED="true">
                <node TEXT="Starts a subscription or membership plan." FOLDED="true" />
                </node>
              <node TEXT="Starts a subscription or membership plan." FOLDED="true" />
              </node>
            </node>
          <node TEXT="Consultant stats   highlights" FOLDED="true">
            <node TEXT="Retention rate, payouts, remote/hybrid stats, women ratio summary" FOLDED="true" />
            </node>
          <node TEXT="What Happens After You Apply" FOLDED="true">
            <node TEXT="Application process steps summarized" FOLDED="true" />
            <node TEXT="CONSULTANT FAQ" FOLDED="true">
              <node TEXT="CONSULTANT FAQ" FOLDED="true">
                <node TEXT="https://lionsandtigers.com/consultant-faq/" FOLDED="true" />
                </node>
              </node>
            </node>
          <node TEXT="From Our Team" FOLDED="true">
            <node TEXT="Testimonial quote" FOLDED="true" />
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Resources" FOLDED="true">
          <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" FOLDED="true">
            <node TEXT="Main Content" FOLDED="true">
              <node TEXT="Avoiding the All-Or-Nothing Workplace: Enabling People to Operate at their Highest   Best Use" FOLDED="true">
                <node TEXT="Brea Starmer, Founder/CEO of Lions   Tigers" LINK="https://lionsandtigers.com/brea-starmer/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_brea-starmer.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Download a pdf of the playbook" LINK="https://lionsandtigers.com/playbook-download/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_playbook-download.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  <node TEXT="Triggers file or report download." FOLDED="true">
                    <node TEXT="Triggers file or report download." FOLDED="true" />
                    </node>
                  </node>
                <node TEXT="audio version." LINK="https://player.captivate.fm/episode/ae64d6e2-5fb9-49fb-95e8-46d0a2433c68" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_player.captivate.fm_episode_ae64d6e2-5fb9-49fb-95e8-46d0a2433c68.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              <node TEXT="Contents Summary:" FOLDED="true">
                <node TEXT="Future Now of Work" FOLDED="true" />
                <node TEXT="Reimagining the Workplace with the Highest   Best Use Operating System™" FOLDED="true" />
                <node TEXT="Our Process of Establishing HBU" FOLDED="true" />
                <node TEXT="Blending Our Workforce: Example" FOLDED="true" />
                <node TEXT="Building the Plane While You Fly It" FOLDED="true" />
                <node TEXT="A Few Things to Dream About" FOLDED="true">
                  <node TEXT="Displays information about the organization or product." FOLDED="true" />
                  </node>
                <node TEXT="In Conclusion" FOLDED="true" />
                </node>
              </node>
            <node TEXT="Visible Sections" FOLDED="true">
              <node TEXT="The Future Now of Work" FOLDED="true">
                <node TEXT="How I Lost My Job and Found My Way" FOLDED="true" />
                <node TEXT="The Workplace Isn’t Working for Everyone" FOLDED="true" />
                <node TEXT="The “Great Resignation”" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#great-resignation" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_great-resignation.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="We’re Losing Those We Most Seek" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#losing-those-we-seek" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_losing-those-we-seek.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Where’d They Go? 50% Independent" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#whered-they-go" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_whered-they-go.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Pew Research Center’s resignation findings" LINK="https://www.pewresearch.org/fact-tank/2022/03/09/majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disrespected/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.pewresearch.org_fact-tank_2022_03_09_majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disres.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="business leaders say they are highly committed" LINK="https://www.mckinsey.com/featured-insights/diversity-and-inclusion/women-in-the-workplace" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.mckinsey.com_featured-insights_diversity-and-inclusion_women-in-the-workplace.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="since 75% of American women would go broke while taking 8 weeks of leave" LINK="https://www.fatherly.com/news/75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.fatherly.com_news_75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="30-year low." LINK="https://en.wikipedia.org/wiki/Labor_force_in_the_United_States#cite_note-45" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_en.wikipedia.org_wiki_Labor_force_in_the_United_States_cite_note-45.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="employees age 30 to 45" LINK="https://www.superstaff.com/blog/top-20-great-resignation-statistics/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.superstaff.com_blog_top-20-great-resignation-statistics.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="One-third" LINK="https://www.latimes.com/politics/story/2021-08-18/pandemic-pushes-moms-to-scale-back-or-quit-their-careers" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.latimes.com_politics_story_2021-08-18_pandemic-pushes-moms-to-scale-back-or-quit-their-careers.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="disappeared from the workforce" LINK="https://www.fastcompany.com/90848858/women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.fastcompany.com_90848858_women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="black female labor participation" LINK="https://www.businessinsider.com/black-women-leaving-corporate-america-entreprenurship-startups-2022-12" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.businessinsider.com_black-women-leaving-corporate-america-entreprenurship-startups-2022-12.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="McKinsey" LINK="https://www.mckinsey.com/capabilities/people-and-organizational-performance/our-insights/great-attrition-or-great-attraction-the-choice-is-yours" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.mckinsey.com_capabilities_people-and-organizational-performance_our-insights_great-attrition-or-great-attraction-the-choice-is-yours.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="70 million Americans" LINK="https://www.zippia.com/advice/how-many-freelancers-in-the-us/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.zippia.com_advice_how-many-freelancers-in-the-us.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Gallup survey" LINK="https://www.gallup.com/workplace/397751/returning-office-current-preferred-future-state-remote-work.aspx" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.gallup.com_workplace_397751_returning-office-current-preferred-future-state-remote-work.aspx.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="research shows" LINK="https://www.vox.com/recode/23129752/work-from-home-productivity" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.vox.com_recode_23129752_work-from-home-productivity.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              <node TEXT="We Must Adopt Blended Work Ecosystems" FOLDED="true">
                <node TEXT="MITSloan" LINK="https://shop.sloanreview.mit.edu/store/workforce-ecosystems-a-new-strategic-approach-to-the-future-of-work" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_shop.sloanreview.mit.edu_store_workforce-ecosystems-a-new-strategic-approach-to-the-future-of-work.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="A.team" LINK="http://www.a.team/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/http_www.a.team.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="HBR, BCG" LINK="https://www.hbs.edu/managing-the-future-of-work/Documents/Building_The_On_Demand_Workforce.pdf" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.hbs.edu_managing-the-future-of-work_Documents_Building_The_On_Demand_Workforce.pdf.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              <node TEXT="The Era of Sustainability: Measuring Impact Over Hours" FOLDED="true" />
              <node TEXT="Reimagining the Workplace with the Highest   Best Use Operating System™" FOLDED="true">
                <node TEXT="The Highest   Best Use Operating System" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-op-system" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_hbu-op-system.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="The 3Ms of HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#3ms-hbu" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_3ms-hbu.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Applying the 3Ms to our Blended Work Ecosystem" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#3ms-blended-work" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_3ms-blended-work.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              <node TEXT="Our Process of Establishing HBU" FOLDED="true">
                <node TEXT="First Step: Highest   Best ORGANIZATION" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-organization" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_hbu-organization.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Second Step: Highest   Best YOU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-you" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_hbu-you.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Third Step: Highest   Best COMMUNITY" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-community" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_hbu-community.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Stitching It All Together: Your Ecosystem is Unique" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#stitching-it-all-together" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_stitching-it-all-together.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              <node TEXT="Unlocking HBU: High-EQ Change Management" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#unlocking-hbu" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_unlocking-hbu.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              <node TEXT="Blending Our Workforce: Natalie’s Example" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#natalies-example" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_natalies-example.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              <node TEXT="Building the Plane While You Fly It" FOLDED="true">
                <node TEXT="Very Practical Advice for Proliferating HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#practical-advice" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_practical-advice.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="How to Convince Your Boss or Peers You Need HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#convince-your-boss" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_convince-your-boss.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="The P L Benefits of a Blended Workforce" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#benefits-of-blended" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_benefits-of-blended.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Human Resources vs Procurement: Who Manages the Blended Workforce?" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hr-procurement" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_hr-procurement.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              <node TEXT="A Few Things to Dream About" FOLDED="true">
                <node TEXT="Every Org Needs a “Gig Economy”" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#gig-economy" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_gig-economy.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Commitments to Diversity are Now Public" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#commitments-to-diversity" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_commitments-to-diversity.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Portable Benefits for Independent Workers" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#portable-benefits" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_portable-benefits.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Hybrid   Flex Work Permanence" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#work-permanence" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_work-permanence.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Displays information about the organization or product." FOLDED="true">
                  <node TEXT="Displays information about the organization or product." FOLDED="true" />
                  </node>
                </node>
              <node TEXT="In Conclusion" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#conclusion" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace_conclusion.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              <node TEXT="Where to from here?" FOLDED="true">
                <node TEXT="Download a pdf version" LINK="https://lionsandtigers.com/playbook-download/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_playbook-download.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  <node TEXT="Triggers file or report download." FOLDED="true">
                    <node TEXT="Triggers file or report download." FOLDED="true" />
                    </node>
                  </node>
                <node TEXT="Reach out to our team" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Subscribe to the newsletter" LINK="https://lionsandtigers.com/newsletter/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_newsletter.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  <node TEXT="Starts a subscription or membership plan." FOLDED="true" />
                  </node>
                <node TEXT="Follow Brea on LinkedIn" LINK="https://www.linkedin.com/in/breastarmer/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Check out our blog" LINK="https://lionsandtigers.com/blog/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              </node>
            <node TEXT="Screenshot Example" FOLDED="true">
              <richcontent TYPE="NODE">
                <html>
                  <body>
                    <p>
                      <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250" />
                      </p>
                    </body>
                  </html>
                </richcontent>
              </node>
            </node>
          <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" FOLDED="true">
            <node TEXT="Courage at Work" FOLDED="true">
              <node TEXT="Overview" FOLDED="true">Here you can find thought leadership, best practices, news, and stories about people &amp; impact.</node>
              </node>
            <node TEXT="Main Categories" FOLDED="true">
              <node TEXT="Thought Leadership   Best Practices" FOLDED="true">
                <node TEXT="thought leadership" LINK="https://lionsandtigers.com/category/thought-leadership/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_category_thought-leadership.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="best practices" LINK="https://lionsandtigers.com/category/best-practices/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_category_best-practices.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              <node TEXT="New   Noteworthy" FOLDED="true">
                <node TEXT="new" LINK="https://lionsandtigers.com/category/new/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_category_new.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="noteworthy" LINK="https://lionsandtigers.com/category/noteworthy/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_category_noteworthy.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              <node TEXT="People   Projects" FOLDED="true">
                <node TEXT="people" LINK="https://lionsandtigers.com/category/people/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_category_people.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              </node>
            <node TEXT="Featured Blog Posts" FOLDED="true">
              <node TEXT="Workforce Reimagined Research Launch Event" FOLDED="true">
                <node TEXT="read more" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_workforce-reimagined-research-launch-event.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic" FOLDED="true">
                <node TEXT="read more" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              <node TEXT="Building Better Workplaces for Women: 3 Power Moves to Help You Grow, Lead, and Thrive" FOLDED="true">
                <node TEXT="read more" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                <node TEXT="Leads to FAQs, support tickets, or live chat." FOLDED="true" />
                </node>
              <node TEXT="Elevating Culture   Community: Miranda Leurquin’s New Chapter at L T" FOLDED="true">
                <node TEXT="read more" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" FOLDED="true">
                  <node TEXT="Screenshot Example" FOLDED="true">
                    <richcontent TYPE="NODE">
                      <html>
                        <body>
                          <p>
                            <img src="hyperlink_screenshots/https_lionsandtigers.com_elevating-culture-community-miranda-hickmans-new-chapter-at-lt.png" width="500" height="250" />
                            </p>
                          </body>
                        </html>
                      </richcontent>
                    </node>
                  </node>
                </node>
              </node>
            <node TEXT="Newsletter Signup" FOLDED="true">
              <node TEXT="Form" FOLDED="true">
                <node TEXT="Email" FOLDED="true" />
                <node TEXT="SUBSCRIBE" FOLDED="true">
                  <node TEXT="Starts a subscription or membership plan." FOLDED="true" />
                  </node>
                </node>
              <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_lionsandtigers.com_newsletter.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Media" FOLDED="true">
              <node TEXT="Take me there" LINK="https://lionsandtigers.com/media/" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_lionsandtigers.com_media.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Pagination" FOLDED="true">
              <node TEXT=" laquo; Older Entries" LINK="https://lionsandtigers.com/blog/page/2/?et_blog" FOLDED="true">
                <node TEXT="Screenshot Example" FOLDED="true">
                  <richcontent TYPE="NODE">
                    <html>
                      <body>
                        <p>
                          <img src="hyperlink_screenshots/https_lionsandtigers.com_blog_page_2_et_blog.png" width="500" height="250" />
                          </p>
                        </body>
                      </html>
                    </richcontent>
                  </node>
                </node>
              </node>
            <node TEXT="Screenshot Example" FOLDED="true">
              <richcontent TYPE="NODE">
                <html>
                  <body>
                    <p>
                      <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250" />
                      </p>
                    </body>
                  </html>
                </richcontent>
              </node>
            </node>
          <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/" FOLDED="true">
            <node TEXT="Client Newsletter" FOLDED="true">
              <node TEXT="Summary: Solutions, success stories, best practices, thought leadership" FOLDED="true" />
              <node TEXT="Form" FOLDED="true">
                <node TEXT="Email Input" FOLDED="true" />
                <node TEXT="SUBSCRIBE Button" FOLDED="true">
                  <node TEXT="Starts a subscription or membership plan." FOLDED="true" />
                  </node>
                </node>
              </node>
            <node TEXT="Talent Newsletter" FOLDED="true">
              <node TEXT="Summary: Open roles, events, talent news, Role Call newsletter" FOLDED="true" />
              <node TEXT="Form" FOLDED="true">
                <node TEXT="Email Input" FOLDED="true" />
                <node TEXT="SUBSCRIBE Button" FOLDED="true">
                  <node TEXT="Starts a subscription or membership plan." FOLDED="true" />
                  </node>
                </node>
              </node>
            <node TEXT="Work with us" FOLDED="true">
              <node TEXT="CLIENTS" FOLDED="true">
                <node TEXT="TALK TO US" FOLDED="true">
                  <node TEXT="https://lionsandtigers.com/talk-to-us/" FOLDED="true" />
                  </node>
                </node>
              <node TEXT="TALENT" FOLDED="true">
                <node TEXT="JOIN OUR TEAM" FOLDED="true">
                  <node TEXT="https://lionsandtigers.com/join-our-team/" FOLDED="true" />
                  </node>
                </node>
              </node>
            <node TEXT="Screenshot Example" FOLDED="true">
              <richcontent TYPE="NODE">
                <html>
                  <body>
                    <p>
                      <img src="hyperlink_screenshots/https_lionsandtigers.com_newsletter.png" width="500" height="250" />
                      </p>
                    </body>
                  </html>
                </richcontent>
              </node>
            </node>
          </node>
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true">
          <node TEXT="Page Introduction" FOLDED="true">
            <node TEXT="Consultant inquiry section and invitation to join team" FOLDED="true" />
            <node TEXT="Learn more about joining team" FOLDED="true">
              <node TEXT="here" FOLDED="true">
                <node TEXT="https://lionsandtigers.com/join-our-team" FOLDED="true" />
                </node>
              <node TEXT="Displays information about the organization or product." FOLDED="true">
                <node TEXT="Displays information about the organization or product." FOLDED="true" />
                </node>
              </node>
            </node>
          <node TEXT="Contact Form" FOLDED="true">
            <node TEXT="First Name" FOLDED="true" />
            <node TEXT="Last Name" FOLDED="true" />
            <node TEXT="Title" FOLDED="true" />
            <node TEXT="Organization" FOLDED="true" />
            <node TEXT="Email" FOLDED="true" />
            <node TEXT="Phone" FOLDED="true" />
            <node TEXT="Message" FOLDED="true">
              <node TEXT="Opens a direct message or chat box." FOLDED="true" />
              </node>
            <node TEXT="Captcha (1 + 11 = )" FOLDED="true" />
            <node TEXT="Submit Button" FOLDED="true">
              <node TEXT="Sends form data to the server." FOLDED="true" />
              </node>
            <node TEXT="Opens contact form or company contact details." FOLDED="true">
              <node TEXT="Opens contact form or company contact details." FOLDED="true" />
              </node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      </node>
    <node TEXT="Home Page" FOLDED="true">
      <node TEXT="Hero Section" FOLDED="true">
        <node TEXT="Build Your Dream Team" FOLDED="true" />
        <node TEXT="Description" FOLDED="true">
          <node TEXT="Highly skilled marketing, comms, operations   change specialists waiting for you. Drive your business   your people forward – no compromises." FOLDED="true" />
          </node>
        <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Hero Image" FOLDED="true" />
        </node>
      <node TEXT="Trusted By" FOLDED="true">
        <node TEXT="Logos" FOLDED="true">
          <node TEXT="XBOX" FOLDED="true" />
          <node TEXT="ada developers academy" FOLDED="true" />
          <node TEXT="Alaska Airlines" FOLDED="true" />
          <node TEXT="GitHub" FOLDED="true" />
          <node TEXT="Microsoft" FOLDED="true" />
          <node TEXT="Minecraft" FOLDED="true" />
          <node TEXT="Tribute" FOLDED="true" />
          </node>
        </node>
      <node TEXT="Model Section" FOLDED="true">
        <node TEXT="Our model fits your needs   our people" FOLDED="true" />
        <node TEXT="Description" FOLDED="true">
          <node TEXT="We design the solutions that fit your needs – today   tomorrow." FOLDED="true" />
          </node>
        <node TEXT="Model Types" FOLDED="true">
          <node TEXT="Full-time   Fractional" FOLDED="true" />
          <node TEXT="Individuals   Teams" FOLDED="true" />
          <node TEXT="Time   Outcome Based" FOLDED="true" />
          </node>
        </node>
      <node TEXT="Client Testimonial" FOLDED="true">
        <node TEXT="A Word From Our Clients" FOLDED="true" />
        <node TEXT="Testimonial Quote" FOLDED="true" />
        <node TEXT="Client Name" FOLDED="true">
          <node TEXT="DeAnna Paddleford" FOLDED="true" />
          <node TEXT="Change Management Strategy Lead" FOLDED="true" />
          </node>
        </node>
      <node TEXT="Culture Section" FOLDED="true">
        <node TEXT="Want to build a culture of high performance   belonging?" FOLDED="true" />
        <node TEXT="Description" FOLDED="true">
          <node TEXT="We built a playbook for leaders who are thinking about workforce innovation and need a system for change. Our Highest   Best Use Operating System™ maximizes human potential aligned to business outcomes, while guarding against burnout and exclusion." FOLDED="true">
            <node TEXT="Displays information about the organization or product." FOLDED="true" />
            </node>
          </node>
        <node TEXT="LEARN MORE Button" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Vision   Mission" FOLDED="true">
        <node TEXT="Vision" FOLDED="true">
          <node TEXT="To unlock the full potential of the workforce." FOLDED="true" />
          </node>
        <node TEXT="Mission" FOLDED="true">
          <node TEXT="We strengthen businesses with the power of the independent workforce by building blended, human-centered teams." FOLDED="true" />
          </node>
        <node TEXT="OUR STORY Button" LINK="https://lionsandtigers.com/our-story/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Team Image" FOLDED="true" />
        <node TEXT="Team Diversity Note" FOLDED="true">
          <node TEXT="Our team self-identifies as 87% women." FOLDED="true" />
          </node>
        </node>
      <node TEXT="Work With Us" FOLDED="true">
        <node TEXT="Clients" FOLDED="true">
          <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true">
            <node TEXT="Screenshot Example" FOLDED="true">
              <richcontent TYPE="NODE">
                <html>
                  <body>
                    <p>
                      <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250" />
                      </p>
                    </body>
                  </html>
                </richcontent>
              </node>
            </node>
          </node>
        <node TEXT="Talent" FOLDED="true">
          <node TEXT="JOIN OUR TEAM Button" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true">
            <node TEXT="Screenshot Example" FOLDED="true">
              <richcontent TYPE="NODE">
                <html>
                  <body>
                    <p>
                      <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250" />
                      </p>
                    </body>
                  </html>
                </richcontent>
              </node>
            </node>
          </node>
        </node>
      <node TEXT="Navigates to the main landing page or dashboard." FOLDED="true">
        <node TEXT="Centralized area showing user stats and quick actions." FOLDED="true" />
        </node>
      </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Company Info" FOLDED="true">
        <node TEXT="Lions   Tigers Logo" FOLDED="true" />
        <node TEXT="Professional Staffing   Workforce Solutions Partner" FOLDED="true" />
        </node>
      <node TEXT="About Us" FOLDED="true">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="DEI" LINK="https://lionsandtigers.com/dei/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_dei.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Displays information about the organization or product." FOLDED="true">
          <node TEXT="Displays information about the organization or product." FOLDED="true" />
          </node>
        </node>
      <node TEXT="Solutions" FOLDED="true">
        <node TEXT="Working Together" LINK="https://lionsandtigers.com/solutions/#working-together" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_working-together.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Engagement Model" LINK="https://lionsandtigers.com/solutions/#engagement-model" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_engagement-model.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_capabilities-skillsets.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_client-stories.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Resources" FOLDED="true">
        <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Media" LINK="https://lionsandtigers.com/media/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_media.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="General Inquiries" LINK="https://lionsandtigers.com/general-inquiries/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_lionsandtigers.com_general-inquiries.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Newsletter" FOLDED="true">
        <node TEXT="Description" FOLDED="true">
          <node TEXT="Learn about our solutions, our success stories, best practices, and thought leadership." FOLDED="true">
            <node TEXT="Displays information about the organization or product." FOLDED="true" />
            </node>
          </node>
        <node TEXT="Newsletter Form" FOLDED="true">
          <node TEXT="Email (input field)" FOLDED="true" />
          <node TEXT="SUBSCRIBE (button)" FOLDED="true">
            <node TEXT="Starts a subscription or membership plan." FOLDED="true" />
            </node>
          </node>
        </node>
      <node TEXT="Social Media" FOLDED="true">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_www.linkedin.com_company_lionsandtigers.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_twitter.com_lionstigersco.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_www.instagram.com_lionstigersco.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco" FOLDED="true">
          <node TEXT="Screenshot Example" FOLDED="true">
            <richcontent TYPE="NODE">
              <html>
                <body>
                  <p>
                    <img src="hyperlink_screenshots/https_www.youtube.com_lionstigersco.png" width="500" height="250" />
                    </p>
                  </body>
                </html>
              </richcontent>
            </node>
          </node>
        </node>
      <node TEXT="Privacy Policy" LINK="https://lionsandtigers.com/privacy-policy/" FOLDED="true">
        <node TEXT="Screenshot Example" FOLDED="true">
          <richcontent TYPE="NODE">
            <html>
              <body>
                <p>
                  <img src="hyperlink_screenshots/https_lionsandtigers.com_privacy-policy.png" width="500" height="250" />
                  </p>
                </body>
              </html>
            </richcontent>
          </node>
        </node>
      <node TEXT="Displays footer information and links." FOLDED="true">
        <node TEXT="Displays footer information and links." FOLDED="true" />
        </node>
      </node>
    <node TEXT="Test Cases" POSITION="left" FOLDED="true">
      <node TEXT="Our Story Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the 'Our Story' link in the header navigates the user to the correct 'Our Story' page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The 'Our Story' page loads all main content sections, including company history and values." FOLDED="true" POSITION="left" />
          <node TEXT="3. All images and videos on the 'Our Story' page display correctly without broken links." FOLDED="true" POSITION="left" />
          <node TEXT="4. The 'Our Story' page is accessible from every page via the header navigation." FOLDED="true" POSITION="left" />
          <node TEXT="5. The 'Our Story' page displays the leadership team bios with working LinkedIn links." FOLDED="true" POSITION="left" />
          <node TEXT="6. The 'Our Story' page includes recent recognition and awards, and these are visible to the user." FOLDED="true" POSITION="left" />
          <node TEXT="7. The 'Our Story' page's navigation breadcrumbs accurately reflect the user's location." FOLDED="true" POSITION="left" />
          <node TEXT="8. The 'Our Story' page is responsive and displays correctly on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="9. The 'Our Story' page's internal links (e.g., to team bios) function as expected." FOLDED="true" POSITION="left" />
          <node TEXT="10. The 'Our Story' page loads within 3 seconds under normal network conditions." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempting to access the 'Our Story' page with an invalid URL returns a 404 error page." FOLDED="true" POSITION="left" />
          <node TEXT="2. If the 'Our Story' page is deleted from the server, the link in the header does not break the site." FOLDED="true" POSITION="left" />
          <node TEXT="3. If images on the 'Our Story' page are missing, the page displays appropriate placeholders or alt text." FOLDED="true" POSITION="left" />
          <node TEXT="4. If the user is not authenticated (if required), the 'Our Story' page still loads as a public page." FOLDED="true" POSITION="left" />
          <node TEXT="5. If JavaScript is disabled, the main content of the 'Our Story' page remains accessible." FOLDED="true" POSITION="left" />
          <node TEXT="6. If the 'Our Story' page fails to load due to a server error, an error message is displayed to the user." FOLDED="true" POSITION="left" />
          <node TEXT="7. If the user clicks the 'Our Story' link multiple times rapidly, only one page load occurs." FOLDED="true" POSITION="left" />
          <node TEXT="8. If the 'Our Story' page is accessed with a slow network, a loading indicator is shown." FOLDED="true" POSITION="left" />
          <node TEXT="9. If the user tries to access a restricted section from 'Our Story', access is denied appropriately." FOLDED="true" POSITION="left" />
          <node TEXT="10. If the 'Our Story' page is accessed in a language not supported, the default language is shown." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The 'Our Story' page meets WCAG 2.1 AA accessibility standards." FOLDED="true" POSITION="left" />
          <node TEXT="2. The 'Our Story' page loads in under 2 seconds on a broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="3. The 'Our Story' page is fully responsive across all major browsers and devices." FOLDED="true" POSITION="left" />
          <node TEXT="4. The 'Our Story' page's images are optimized for fast loading without loss of quality." FOLDED="true" POSITION="left" />
          <node TEXT="5. The 'Our Story' page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="6. The 'Our Story' page is crawlable and indexable by search engines." FOLDED="true" POSITION="left" />
          <node TEXT="7. The 'Our Story' page does not leak any sensitive information in the page source." FOLDED="true" POSITION="left" />
          <node TEXT="8. The 'Our Story' page supports screen readers and keyboard navigation." FOLDED="true" POSITION="left" />
          <node TEXT="9. The 'Our Story' page maintains layout integrity when zoomed to 200%." FOLDED="true" POSITION="left" />
          <node TEXT="10. The 'Our Story' page does not trigger any browser security warnings." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="Why Now Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the 'Why Now' link in the header navigates the user to the 'Why Now' page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The 'Why Now' page displays the research report and key statistics sections." FOLDED="true" POSITION="left" />
          <node TEXT="3. The 'Why Now' page's download links for reports function and trigger downloads." FOLDED="true" POSITION="left" />
          <node TEXT="4. All infographics and images on the 'Why Now' page load correctly." FOLDED="true" POSITION="left" />
          <node TEXT="5. The 'Why Now' page's internal navigation (e.g., to survey results) works as expected." FOLDED="true" POSITION="left" />
          <node TEXT="6. The 'Why Now' page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
          <node TEXT="7. The 'Why Now' page's expert quotes and data are visible and formatted properly." FOLDED="true" POSITION="left" />
          <node TEXT="8. The 'Why Now' page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
          <node TEXT="9. The 'Why Now' page's external links (e.g., to LinkedIn) open in a new tab." FOLDED="true" POSITION="left" />
          <node TEXT="10. The 'Why Now' page loads without JavaScript errors in the browser console." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempting to access the 'Why Now' page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
          <node TEXT="2. If the research report file is missing, the download link displays an error message." FOLDED="true" POSITION="left" />
          <node TEXT="3. If images on the 'Why Now' page fail to load, alt text is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="4. If the user is not authenticated (if required), the 'Why Now' page remains accessible." FOLDED="true" POSITION="left" />
          <node TEXT="5. If the 'Why Now' page is accessed with JavaScript disabled, main content is still visible." FOLDED="true" POSITION="left" />
          <node TEXT="6. If the 'Why Now' page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="7. If the user clicks the 'Why Now' link multiple times quickly, only one navigation occurs." FOLDED="true" POSITION="left" />
          <node TEXT="8. If the 'Why Now' page is accessed with a slow network, a loading spinner is shown." FOLDED="true" POSITION="left" />
          <node TEXT="9. If the user tries to download a corrupted report, an error is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="10. If the 'Why Now' page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The 'Why Now' page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="2. The 'Why Now' page loads in under 2.5 seconds on a broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="3. The 'Why Now' page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="4. The 'Why Now' page's downloadable files are under 5MB for quick access." FOLDED="true" POSITION="left" />
          <node TEXT="5. The 'Why Now' page's text and graphics are clear at 200% zoom." FOLDED="true" POSITION="left" />
          <node TEXT="6. The 'Why Now' page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
          <node TEXT="7. The 'Why Now' page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
          <node TEXT="8. The 'Why Now' page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
          <node TEXT="9. The 'Why Now' page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
          <node TEXT="10. The 'Why Now' page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="Solutions Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the 'Solutions' link in the header navigates the user to the 'Solutions' page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The 'Solutions' page displays all solution offerings and engagement models." FOLDED="true" POSITION="left" />
          <node TEXT="3. The 'Solutions' page's internal anchor links (e.g., to client stories) work correctly." FOLDED="true" POSITION="left" />
          <node TEXT="4. All images and case studies on the 'Solutions' page load without errors." FOLDED="true" POSITION="left" />
          <node TEXT="5. The 'Solutions' page's contact buttons (e.g., 'Talk to Us') function as expected." FOLDED="true" POSITION="left" />
          <node TEXT="6. The 'Solutions' page is accessible from every other page via the header." FOLDED="true" POSITION="left" />
          <node TEXT="7. The 'Solutions' page's downloadable resources are available and trigger downloads." FOLDED="true" POSITION="left" />
          <node TEXT="8. The 'Solutions' page is responsive and displays correctly on all device sizes." FOLDED="true" POSITION="left" />
          <node TEXT="9. The 'Solutions' page's team and skillset sections are visible and formatted properly." FOLDED="true" POSITION="left" />
          <node TEXT="10. The 'Solutions' page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempting to access the 'Solutions' page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
          <node TEXT="2. If a downloadable resource is missing, the download link displays an error message." FOLDED="true" POSITION="left" />
          <node TEXT="3. If images on the 'Solutions' page fail to load, alt text is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="4. If the user is not authenticated (if required), the 'Solutions' page remains accessible." FOLDED="true" POSITION="left" />
          <node TEXT="5. If JavaScript is disabled, the main content of the 'Solutions' page is still accessible." FOLDED="true" POSITION="left" />
          <node TEXT="6. If the 'Solutions' page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="7. If the user clicks the 'Solutions' link multiple times rapidly, only one navigation occurs." FOLDED="true" POSITION="left" />
          <node TEXT="8. If the 'Solutions' page is accessed with a slow network, a loading indicator is shown." FOLDED="true" POSITION="left" />
          <node TEXT="9. If the user tries to access a restricted section from 'Solutions', access is denied." FOLDED="true" POSITION="left" />
          <node TEXT="10. If the 'Solutions' page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The 'Solutions' page meets WCAG 2.1 AA accessibility standards." FOLDED="true" POSITION="left" />
          <node TEXT="2. The 'Solutions' page loads in under 2.5 seconds on a broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="3. The 'Solutions' page is fully responsive across all major browsers and devices." FOLDED="true" POSITION="left" />
          <node TEXT="4. The 'Solutions' page's images are optimized for fast loading." FOLDED="true" POSITION="left" />
          <node TEXT="5. The 'Solutions' page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="6. The 'Solutions' page is crawlable and indexable by search engines." FOLDED="true" POSITION="left" />
          <node TEXT="7. The 'Solutions' page does not leak sensitive information in the page source." FOLDED="true" POSITION="left" />
          <node TEXT="8. The 'Solutions' page supports screen readers and keyboard navigation." FOLDED="true" POSITION="left" />
          <node TEXT="9. The 'Solutions' page maintains layout integrity when zoomed to 200%." FOLDED="true" POSITION="left" />
          <node TEXT="10. The 'Solutions' page does not trigger any browser security warnings." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="Join Our Team Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the 'Join Our Team' link in the header navigates the user to the 'Join Our Team' page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The 'Join Our Team' page displays open roles and job listings." FOLDED="true" POSITION="left" />
          <node TEXT="3. The 'Join Our Team' page's application form is visible and can be submitted successfully." FOLDED="true" POSITION="left" />
          <node TEXT="4. The 'Join Our Team' page's newsletter subscription form accepts valid email addresses." FOLDED="true" POSITION="left" />
          <node TEXT="5. The 'Join Our Team' page's DEI information is accessible via provided links." FOLDED="true" POSITION="left" />
          <node TEXT="6. The 'Join Our Team' page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
          <node TEXT="7. The 'Join Our Team' page's testimonials and team highlights are visible." FOLDED="true" POSITION="left" />
          <node TEXT="8. The 'Join Our Team' page is responsive and displays correctly on all devices." FOLDED="true" POSITION="left" />
          <node TEXT="9. The 'Join Our Team' page's FAQ section is accessible and displays answers." FOLDED="true" POSITION="left" />
          <node TEXT="10. The 'Join Our Team' page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempting to access the 'Join Our Team' page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
          <node TEXT="2. Submitting the application form with missing required fields displays validation errors." FOLDED="true" POSITION="left" />
          <node TEXT="3. Submitting the newsletter form with an invalid email address shows an error message." FOLDED="true" POSITION="left" />
          <node TEXT="4. If job listings fail to load, an appropriate error message is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="5. If the user is not authenticated (if required), the 'Join Our Team' page remains accessible." FOLDED="true" POSITION="left" />
          <node TEXT="6. If JavaScript is disabled, the main content and forms are still accessible." FOLDED="true" POSITION="left" />
          <node TEXT="7. If the 'Join Our Team' page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="8. If the user clicks the 'Join Our Team' link multiple times rapidly, only one navigation occurs." FOLDED="true" POSITION="left" />
          <node TEXT="9. If the user tries to access a restricted section from 'Join Our Team', access is denied." FOLDED="true" POSITION="left" />
          <node TEXT="10. If the 'Join Our Team' page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The 'Join Our Team' page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="2. The 'Join Our Team' page loads in under 2.5 seconds on a broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="3. The 'Join Our Team' page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="4. The 'Join Our Team' page's images and graphics are optimized for fast loading." FOLDED="true" POSITION="left" />
          <node TEXT="5. The 'Join Our Team' page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="6. The 'Join Our Team' page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
          <node TEXT="7. The 'Join Our Team' page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
          <node TEXT="8. The 'Join Our Team' page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
          <node TEXT="9. The 'Join Our Team' page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
          <node TEXT="10. The 'Join Our Team' page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="Hybrid Workplace Playbook Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the 'Hybrid Workplace Playbook' link in the header navigates the user to the playbook page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The playbook page displays the main content, including the playbook summary and sections." FOLDED="true" POSITION="left" />
          <node TEXT="3. The playbook page's download link for the PDF functions and triggers a file download." FOLDED="true" POSITION="left" />
          <node TEXT="4. The playbook page's audio version link opens and plays the audio content." FOLDED="true" POSITION="left" />
          <node TEXT="5. All images and infographics on the playbook page load correctly." FOLDED="true" POSITION="left" />
          <node TEXT="6. The playbook page's internal navigation (e.g., to sections) works as expected." FOLDED="true" POSITION="left" />
          <node TEXT="7. The playbook page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
          <node TEXT="8. The playbook page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
          <node TEXT="9. The playbook page's external links (e.g., to research) open in a new tab." FOLDED="true" POSITION="left" />
          <node TEXT="10. The playbook page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempting to access the playbook page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
          <node TEXT="2. If the playbook PDF is missing, the download link displays an error message." FOLDED="true" POSITION="left" />
          <node TEXT="3. If the audio version fails to load, an error message is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="4. If images on the playbook page fail to load, alt text is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="5. If the user is not authenticated (if required), the playbook page remains accessible." FOLDED="true" POSITION="left" />
          <node TEXT="6. If JavaScript is disabled, the main content of the playbook page is still accessible." FOLDED="true" POSITION="left" />
          <node TEXT="7. If the playbook page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="8. If the user clicks the playbook link multiple times rapidly, only one navigation occurs." FOLDED="true" POSITION="left" />
          <node TEXT="9. If the user tries to download a corrupted PDF, an error is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="10. If the playbook page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The playbook page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="2. The playbook page loads in under 2.5 seconds on a broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="3. The playbook page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="4. The playbook PDF is under 10MB for quick download." FOLDED="true" POSITION="left" />
          <node TEXT="5. The playbook page's text and graphics are clear at 200% zoom." FOLDED="true" POSITION="left" />
          <node TEXT="6. The playbook page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
          <node TEXT="7. The playbook page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
          <node TEXT="8. The playbook page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
          <node TEXT="9. The playbook page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
          <node TEXT="10. The playbook page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="Blog Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the 'Blog' link in the header navigates the user to the main blog page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The blog page displays a list of recent blog posts with titles and summaries." FOLDED="true" POSITION="left" />
          <node TEXT="3. Clicking a blog post title navigates the user to the full post." FOLDED="true" POSITION="left" />
          <node TEXT="4. The blog page's category filters work and display relevant posts." FOLDED="true" POSITION="left" />
          <node TEXT="5. The blog page's pagination controls allow navigation to older and newer posts." FOLDED="true" POSITION="left" />
          <node TEXT="6. The blog page's images and featured images load correctly." FOLDED="true" POSITION="left" />
          <node TEXT="7. The blog page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
          <node TEXT="8. The blog page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
          <node TEXT="9. The blog page's newsletter signup form is visible and accepts valid emails." FOLDED="true" POSITION="left" />
          <node TEXT="10. The blog page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempting to access the blog page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
          <node TEXT="2. If a blog post is deleted, its link returns a 404 error page." FOLDED="true" POSITION="left" />
          <node TEXT="3. If images on the blog page fail to load, alt text is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="4. If the user is not authenticated (if required), the blog page remains accessible." FOLDED="true" POSITION="left" />
          <node TEXT="5. If JavaScript is disabled, the main content and posts are still accessible." FOLDED="true" POSITION="left" />
          <node TEXT="6. If the blog page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="7. If the user clicks the 'Blog' link multiple times rapidly, only one navigation occurs." FOLDED="true" POSITION="left" />
          <node TEXT="8. If the user submits an invalid email in the newsletter form, an error is shown." FOLDED="true" POSITION="left" />
          <node TEXT="9. If the blog page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
          <node TEXT="10. If a category filter returns no posts, a 'no posts found' message is displayed." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The blog page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="2. The blog page loads in under 2.5 seconds on a broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="3. The blog page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="4. The blog page's images are optimized for fast loading." FOLDED="true" POSITION="left" />
          <node TEXT="5. The blog page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="6. The blog page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
          <node TEXT="7. The blog page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
          <node TEXT="8. The blog page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
          <node TEXT="9. The blog page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
          <node TEXT="10. The blog page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="Newsletter Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the 'Newsletter' link in the header navigates the user to the newsletter signup page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The newsletter page displays a form with an email input and subscribe button." FOLDED="true" POSITION="left" />
          <node TEXT="3. Submitting a valid email address subscribes the user to the newsletter." FOLDED="true" POSITION="left" />
          <node TEXT="4. The newsletter page displays confirmation after successful subscription." FOLDED="true" POSITION="left" />
          <node TEXT="5. The newsletter page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
          <node TEXT="6. The newsletter page's description and benefits are visible to the user." FOLDED="true" POSITION="left" />
          <node TEXT="7. The newsletter page's form prevents duplicate subscriptions with the same email." FOLDED="true" POSITION="left" />
          <node TEXT="8. The newsletter page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
          <node TEXT="9. The newsletter page's privacy policy link is visible and functional." FOLDED="true" POSITION="left" />
          <node TEXT="10. The newsletter page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempting to access the newsletter page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
          <node TEXT="2. Submitting the form with an invalid email address displays a validation error." FOLDED="true" POSITION="left" />
          <node TEXT="3. Submitting the form with an empty email field displays a required field error." FOLDED="true" POSITION="left" />
          <node TEXT="4. If the subscription service is down, an error message is shown to the user." FOLDED="true" POSITION="left" />
          <node TEXT="5. If the user is not authenticated (if required), the newsletter page remains accessible." FOLDED="true" POSITION="left" />
          <node TEXT="6. If JavaScript is disabled, the main content and form are still accessible." FOLDED="true" POSITION="left" />
          <node TEXT="7. If the newsletter page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="8. If the user clicks the subscribe button multiple times rapidly, only one subscription occurs." FOLDED="true" POSITION="left" />
          <node TEXT="9. If the newsletter page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
          <node TEXT="10. If the user tries to subscribe with a blacklisted email, an error is displayed." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The newsletter page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="2. The newsletter page loads in under 2 seconds on a broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="3. The newsletter page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="4. The newsletter page's form is protected against spam and bots." FOLDED="true" POSITION="left" />
          <node TEXT="5. The newsletter page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="6. The newsletter page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
          <node TEXT="7. The newsletter page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
          <node TEXT="8. The newsletter page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
          <node TEXT="9. The newsletter page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
          <node TEXT="10. The newsletter page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="TALK TO US Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the 'TALK TO US' link in the header navigates the user to the contact page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The contact page displays a form with all required fields (name, email, message, etc.)." FOLDED="true" POSITION="left" />
          <node TEXT="3. Submitting the contact form with valid data sends the inquiry successfully." FOLDED="true" POSITION="left" />
          <node TEXT="4. The contact page displays a confirmation message after successful submission." FOLDED="true" POSITION="left" />
          <node TEXT="5. The contact page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
          <node TEXT="6. The contact page's captcha field validates correct answers before submission." FOLDED="true" POSITION="left" />
          <node TEXT="7. The contact page's phone and email fields accept valid formats only." FOLDED="true" POSITION="left" />
          <node TEXT="8. The contact page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
          <node TEXT="9. The contact page's links to other resources (e.g., Join Our Team) are functional." FOLDED="true" POSITION="left" />
          <node TEXT="10. The contact page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempting to access the contact page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
          <node TEXT="2. Submitting the form with missing required fields displays validation errors." FOLDED="true" POSITION="left" />
          <node TEXT="3. Submitting the form with an invalid email address shows an error message." FOLDED="true" POSITION="left" />
          <node TEXT="4. Submitting the form with an incorrect captcha answer prevents submission." FOLDED="true" POSITION="left" />
          <node TEXT="5. If the contact service is down, an error message is shown to the user." FOLDED="true" POSITION="left" />
          <node TEXT="6. If JavaScript is disabled, the main content and form are still accessible." FOLDED="true" POSITION="left" />
          <node TEXT="7. If the contact page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="8. If the user clicks the submit button multiple times rapidly, only one submission occurs." FOLDED="true" POSITION="left" />
          <node TEXT="9. If the contact page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
          <node TEXT="10. If the user tries to submit a message with a blacklisted word, an error is displayed." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The contact page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="2. The contact page loads in under 2 seconds on a broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="3. The contact page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="4. The contact form is protected against spam and automated submissions." FOLDED="true" POSITION="left" />
          <node TEXT="5. The contact page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="6. The contact page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
          <node TEXT="7. The contact page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
          <node TEXT="8. The contact page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
          <node TEXT="9. The contact page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
          <node TEXT="10. The contact page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
          </node>
        </node>
      <node TEXT="Home Page Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Clicking the 'Home Page' link in the header navigates the user to the main landing page." FOLDED="true" POSITION="left" />
          <node TEXT="2. The home page displays the hero section with headline, description, and call-to-action buttons." FOLDED="true" POSITION="left" />
          <node TEXT="3. The home page's 'TALK TO US' and 'JOIN OUR TEAM' buttons navigate to the correct pages." FOLDED="true" POSITION="left" />
          <node TEXT="4. The home page displays client logos in the 'Trusted By' section." FOLDED="true" POSITION="left" />
          <node TEXT="5. The home page's testimonial section displays client quotes and names." FOLDED="true" POSITION="left" />
          <node TEXT="6. The home page's navigation menu is visible and functional." FOLDED="true" POSITION="left" />
          <node TEXT="7. The home page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
          <node TEXT="8. The home page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
          <node TEXT="9. The home page's images and graphics load without errors." FOLDED="true" POSITION="left" />
          <node TEXT="10. The home page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. Attempting to access the home page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
          <node TEXT="2. If images on the home page fail to load, alt text is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="3. If the user is not authenticated (if required), the home page remains accessible." FOLDED="true" POSITION="left" />
          <node TEXT="4. If JavaScript is disabled, the main content and navigation are still accessible." FOLDED="true" POSITION="left" />
          <node TEXT="5. If the home page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
          <node TEXT="6. If the user clicks the 'Home Page' link multiple times rapidly, only one navigation occurs." FOLDED="true" POSITION="left" />
          <node TEXT="7. If the home page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
          <node TEXT="8. If a call-to-action button is broken, an error message is displayed." FOLDED="true" POSITION="left" />
          <node TEXT="9. If the home page's testimonial section fails to load, a placeholder is shown." FOLDED="true" POSITION="left" />
          <node TEXT="10. If the home page's navigation menu fails to render, a fallback menu is displayed." FOLDED="true" POSITION="left" />
          </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
          <node TEXT="1. The home page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
          <node TEXT="2. The home page loads in under 2 seconds on a broadband connection." FOLDED="true" POSITION="left" />
          <node TEXT="3. The home page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
          <node TEXT="4. The home page's images are optimized for fast loading." FOLDED="true" POSITION="left" />
          <node TEXT="5. The home page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
          <node TEXT="6. The home page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
          <node TEXT="7. The home page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
          <node TEXT="8. The home page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
          <node TEXT="9. The home page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
          <node TEXT="10. The home page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
          </node>
        </node>
      </node>
    <node TEXT="Error Page" CREATED="1766390505924" MODIFIED="1766390505924"><richcontent TYPE="NODE"><html><head /><body><img src="screenshot\404_screenshot.png" alt="404 Screenshot" width="500" height="250" /></body></html></richcontent></node></node>
  </map>