<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="newsletter">
    <node TEXT="Client Newsletter">
      <node TEXT="Summary: Learn about solutions, stories, best practices, and leadership." />
      <node TEXT="Form">
        <node TEXT="Email Address" />
        <node TEXT="Subscribe Button" />
      </node>
    </node>
    <node TEXT="Talent Newsletter">
      <node TEXT="Summary: Get updates on open roles, events, and talent news." />
      <node TEXT="Form">
        <node TEXT="Email Address" />
        <node TEXT="Subscribe Button" />
      </node>
    </node>
    <node TEXT="Work with us">
      <node TEXT="Clients">
        <node TEXT="TALK TO US">
          <node TEXT="Link: https://lionsandtigers.com/talk-to-us/" />
        </node>
      </node>
      <node TEXT="Talent">
        <node TEXT="JOIN OUR TEAM">
          <node TEXT="Link: https://lionsandtigers.com/join-our-team/" />
        </node>
      </node>
    </node>
  </node>
</map>