<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="newsletter">
    <node TEXT="Client Newsletter">
      <node TEXT="Summary: Solutions, success stories, best practices, thought leadership" />
      <node TEXT="Form">
        <node TEXT="Email Input" />
        <node TEXT="SUBSCRIBE Button" />
      </node>
    </node>
    <node TEXT="Talent Newsletter">
      <node TEXT="Summary: Open roles, events, talent news, Role Call newsletter" />
      <node TEXT="Form">
        <node TEXT="Email Input" />
        <node TEXT="SUBSCRIBE Button" />
      </node>
    </node>
    <node TEXT="Work with us">
      <node TEXT="CLIENTS">
        <node TEXT="TALK TO US">
          <node TEXT="https://lionsandtigers.com/talk-to-us/" />
        </node>
      </node>
      <node TEXT="TALENT">
        <node TEXT="JOIN OUR TEAM">
          <node TEXT="https://lionsandtigers.com/join-our-team/" />
        </node>
      </node>
    </node>
  </node>
</map>