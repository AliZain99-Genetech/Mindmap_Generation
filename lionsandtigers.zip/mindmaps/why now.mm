<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="why now">
    <node TEXT="Workforce Reimagined">
      <node TEXT="Unlocking the Power of Blended Teams" />
      <node TEXT="Read the Research Report">
        <node TEXT="Link: Read the Research Report" LINK="https://lionsandtigers.com/why-now/" />
      </node>
    </node>
    <node TEXT="The American workforce is at an inflection point">
      <node TEXT="Key statistics on workforce changes in 2025 and beyond" />
    </node>
    <node TEXT="Why This Study">
      <node TEXT="Purpose of research and methodology summary" />
      <node TEXT="Brea Starmer">
        <node TEXT="Link: Brea Starmer" LINK="https://www.linkedin.com/in/breastarmer/" />
      </node>
    </node>
    <node TEXT="Blended Teams: Key Insights">
      <node TEXT="Expert quote: Re-architecting work for flexibility and expertise" />
      <node TEXT="The Data Is In: Blended Teams Work" />
      <node TEXT="Statistics: Skills, quality, innovation as competitive edges" />
    </node>
    <node TEXT="The Value Compounds Over Time">
      <node TEXT="Impact increases with long-term use of blended teams" />
    </node>
    <node TEXT="Why It Matters">
      <node TEXT="Blended teams as a lifeline and future of work" />
    </node>
    <node TEXT="The 2025 Blended Workforce Survey">
      <node TEXT="Overview of Read the Room Advisors' study" />
      <node TEXT="Download Full Survey Report">
        <node TEXT="Link: Download Full Survey Report" LINK="https://lionsandtigers.com/why-now/" />
      </node>
    </node>
  </node>
</map>