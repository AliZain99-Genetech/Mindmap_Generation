<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="why now">
    <node TEXT="Workforce Reimagined – Unlocking the Power of Blended Teams">
      <node TEXT="Summary: Traditional workforce models are failing; new research on blended teams" />
      <node TEXT="Read the Research Report">
        <node TEXT="Link" LINK="https://lionsandtigers.com/why-now/" />
      </node>
    </node>
    <node TEXT="The American workforce is at an inflection point">
      <node TEXT="Summary: Key statistics about women, freelancers, and the future workforce" />
    </node>
    <node TEXT="Why This Study">
      <node TEXT="Summary: The shift for leaders; study overview and goals" />
      <node TEXT="Brea Starmer">
        <node TEXT="Link" LINK="https://www.linkedin.com/in/breastarmer/" />
      </node>
    </node>
    <node TEXT="Expert Insight – Paul Estes Quote">
      <node TEXT="Summary: Leaders who prioritize flexibility and expertise will thrive" />
    </node>
    <node TEXT="The Data Is In: Blended Teams Work">
      <node TEXT="Summary: Data-driven benefits of blended teams, including speed, innovation, skills, and quality" />
    </node>
    <node TEXT="The Value Compounds Over Time">
      <node TEXT="Summary: Strategic advantage increases with longer tenure using blended teams" />
    </node>
    <node TEXT="Future Workforce Arc – Pam Cohen Quote">
      <node TEXT="Summary: Blended teams are now a fundamental part of work" />
    </node>
    <node TEXT="Why It Matters">
      <node TEXT="Summary: Blended teams support women, caregivers, and AI transitions" />
    </node>
    <node TEXT="The 2025 Blended Workforce Survey">
      <node TEXT="Summary: Research conducted by Read the Room Advisors; survey methodology and purpose" />
      <node TEXT="Download Full Survey Report">
        <node TEXT="Link" LINK="https://lionsandtigers.com/why-now/" />
      </node>
    </node>
  </node>
</map>