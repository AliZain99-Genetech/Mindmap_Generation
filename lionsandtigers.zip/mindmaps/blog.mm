<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="blog">
    <node TEXT="Courage at Work introduction">
      <node TEXT="Welcome message and overview" />
    </node>
    <node TEXT="Explore Blog Topics">
      <node TEXT="Thought Leadership   Best Practices">
        <node TEXT="thought leadership" LINK="https://lionsandtigers.com/category/thought-leadership/" />
        <node TEXT="best practices" LINK="https://lionsandtigers.com/category/best-practices/" />
      </node>
      <node TEXT="New   Noteworthy">
        <node TEXT="noteworthy" LINK="https://lionsandtigers.com/category/noteworthy/" />
        <node TEXT="new" LINK="https://lionsandtigers.com/category/new/" />
      </node>
      <node TEXT="People   Projects">
        <node TEXT="people" LINK="https://lionsandtigers.com/category/people/" />
      </node>
    </node>
    <node TEXT="Featured Blog Posts">
      <node TEXT="Workforce Reimagined Research Launch Event">
        <node TEXT="read more" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" />
        <node TEXT="Workforce Reimagined Research Launch Event" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" />
      </node>
      <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic">
        <node TEXT="read more" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" />
        <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" />
      </node>
      <node TEXT="Building Better Workplaces for Women">
        <node TEXT="read more" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" />
        <node TEXT="Building Better Workplaces for Women: 3 Power Moves to Help You Grow, Lead, and Thrive" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" />
      </node>
      <node TEXT="Elevating Culture   Community: Miranda Leurquin's New Chapter at L T">
        <node TEXT="read more" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" />
        <node TEXT="Elevating Culture   Community:  Miranda Leurquin’s New Chapter at L T" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" />
      </node>
      <node TEXT="Older Entries">
        <node TEXT="« Older Entries" LINK="https://lionsandtigers.com/blog/page/2/?et_blog" />
      </node>
    </node>
    <node TEXT="Newsletter Signup Form">
      <node TEXT="Email Input" />
      <node TEXT="SUBSCRIBE Button" />
      <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/" />
    </node>
    <node TEXT="Media">
      <node TEXT="Media" LINK="https://lionsandtigers.com/media/" />
      <node TEXT="Take me there" LINK="https://lionsandtigers.com/media/" />
    </node>
  </node>
</map>