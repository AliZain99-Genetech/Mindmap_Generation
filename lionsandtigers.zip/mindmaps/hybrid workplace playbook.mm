<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="hybrid workplace playbook">
    <node TEXT="Main Content">
      <node TEXT="Avoiding the All-Or-Nothing Workplace: Enabling People to Operate at their Highest   Best Use">
        <node TEXT="Brea Starmer, Founder/CEO of Lions   Tigers" LINK="https://lionsandtigers.com/brea-starmer/" />
        <node TEXT="Download a pdf of the playbook" LINK="https://lionsandtigers.com/playbook-download/" />
        <node TEXT="audio version." LINK="https://player.captivate.fm/episode/ae64d6e2-5fb9-49fb-95e8-46d0a2433c68" />
      </node>
      <node TEXT="Contents Summary:">
        <node TEXT="Future Now of Work" />
        <node TEXT="Reimagining the Workplace with the Highest   Best Use Operating System™" />
        <node TEXT="Our Process of Establishing HBU" />
        <node TEXT="Blending Our Workforce: Example" />
        <node TEXT="Building the Plane While You Fly It" />
        <node TEXT="A Few Things to Dream About" />
        <node TEXT="In Conclusion" />
      </node>
    </node>
    <node TEXT="Visible Sections">
      <node TEXT="The Future Now of Work">
        <node TEXT="How I Lost My Job and Found My Way" />
        <node TEXT="The Workplace Isn’t Working for Everyone" />
        <node TEXT="The “Great Resignation”" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#great-resignation" />
        <node TEXT="We’re Losing Those We Most Seek" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#losing-those-we-seek" />
        <node TEXT="Where’d They Go? 50% Independent" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#whered-they-go" />
        <node TEXT="Pew Research Center’s resignation findings" LINK="https://www.pewresearch.org/fact-tank/2022/03/09/majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disrespected/" />
        <node TEXT="business leaders say they are highly committed" LINK="https://www.mckinsey.com/featured-insights/diversity-and-inclusion/women-in-the-workplace" />
        <node TEXT="since 75% of American women would go broke while taking 8 weeks of leave" LINK="https://www.fatherly.com/news/75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave" />
        <node TEXT="30-year low." LINK="https://en.wikipedia.org/wiki/Labor_force_in_the_United_States#cite_note-45" />
        <node TEXT="employees age 30 to 45" LINK="https://www.superstaff.com/blog/top-20-great-resignation-statistics/" />
        <node TEXT="One-third" LINK="https://www.latimes.com/politics/story/2021-08-18/pandemic-pushes-moms-to-scale-back-or-quit-their-careers" />
        <node TEXT="disappeared from the workforce" LINK="https://www.fastcompany.com/90848858/women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics" />
        <node TEXT="black female labor participation" LINK="https://www.businessinsider.com/black-women-leaving-corporate-america-entreprenurship-startups-2022-12" />
        <node TEXT="McKinsey" LINK="https://www.mckinsey.com/capabilities/people-and-organizational-performance/our-insights/great-attrition-or-great-attraction-the-choice-is-yours" />
        <node TEXT="70 million Americans" LINK="https://www.zippia.com/advice/how-many-freelancers-in-the-us/" />
        <node TEXT="Gallup survey" LINK="https://www.gallup.com/workplace/397751/returning-office-current-preferred-future-state-remote-work.aspx" />
        <node TEXT="research shows" LINK="https://www.vox.com/recode/23129752/work-from-home-productivity" />
      </node>
      <node TEXT="We Must Adopt Blended Work Ecosystems">
        <node TEXT="MITSloan" LINK="https://shop.sloanreview.mit.edu/store/workforce-ecosystems-a-new-strategic-approach-to-the-future-of-work" />
        <node TEXT="A.team" LINK="http://www.a.team/" />
        <node TEXT="HBR, BCG" LINK="https://www.hbs.edu/managing-the-future-of-work/Documents/Building_The_On_Demand_Workforce.pdf" />
      </node>
      <node TEXT="The Era of Sustainability: Measuring Impact Over Hours" />
      <node TEXT="Reimagining the Workplace with the Highest   Best Use Operating System™">
        <node TEXT="The Highest   Best Use Operating System" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-op-system" />
        <node TEXT="The 3Ms of HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#3ms-hbu" />
        <node TEXT="Applying the 3Ms to our Blended Work Ecosystem" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#3ms-blended-work" />
      </node>
      <node TEXT="Our Process of Establishing HBU">
        <node TEXT="First Step: Highest   Best ORGANIZATION" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-organization" />
        <node TEXT="Second Step: Highest   Best YOU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-you" />
        <node TEXT="Third Step: Highest   Best COMMUNITY" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-community" />
        <node TEXT="Stitching It All Together: Your Ecosystem is Unique" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#stitching-it-all-together" />
      </node>
      <node TEXT="Unlocking HBU: High-EQ Change Management" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#unlocking-hbu" />
      <node TEXT="Blending Our Workforce: Natalie’s Example" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#natalies-example" />
      <node TEXT="Building the Plane While You Fly It">
        <node TEXT="Very Practical Advice for Proliferating HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#practical-advice" />
        <node TEXT="How to Convince Your Boss or Peers You Need HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#convince-your-boss" />
        <node TEXT="The P L Benefits of a Blended Workforce" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#benefits-of-blended" />
        <node TEXT="Human Resources vs Procurement: Who Manages the Blended Workforce?" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hr-procurement" />
      </node>
      <node TEXT="A Few Things to Dream About">
        <node TEXT="Every Org Needs a “Gig Economy”" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#gig-economy" />
        <node TEXT="Commitments to Diversity are Now Public" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#commitments-to-diversity" />
        <node TEXT="Portable Benefits for Independent Workers" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#portable-benefits" />
        <node TEXT="Hybrid   Flex Work Permanence" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#work-permanence" />
      </node>
      <node TEXT="In Conclusion" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#conclusion" />
      <node TEXT="Where to from here?">
        <node TEXT="Download a pdf version" LINK="https://lionsandtigers.com/playbook-download/" />
        <node TEXT="Reach out to our team" LINK="https://lionsandtigers.com/talk-to-us/" />
        <node TEXT="Subscribe to the newsletter" LINK="https://lionsandtigers.com/newsletter/" />
        <node TEXT="Follow Brea on LinkedIn" LINK="https://www.linkedin.com/in/breastarmer/" />
        <node TEXT="Check out our blog" LINK="https://lionsandtigers.com/blog/" />
      </node>
    </node>
  </node>
</map>