<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="hybrid workplace playbook">
    <node TEXT="Avoiding the All-Or-Nothing Workplace: Introduction">
      <node TEXT="Enabling People to Operate at their Highest   Best Use" />
      <node TEXT="Brea Starmer, Founder/CEO" />
      <node TEXT="Download a pdf of the playbook">
        <node TEXT="here" LINK="https://lionsandtigers.com/playbook-download/" />
      </node>
      <node TEXT="Listen to the audio version">
        <node TEXT="audio version." LINK="https://player.captivate.fm/episode/ae64d6e2-5fb9-49fb-95e8-46d0a2433c68" />
      </node>
    </node>
    <node TEXT="Contents Overview">
      <node TEXT="Future Now of Work sections summary" />
      <node TEXT="Workplace Isn #39;t Working, The Great Resignation, HBU System, 3Ms, Community, Practical Advice - all summarized" />
    </node>
    <node TEXT="Workplace Transformation Story">
      <node TEXT="Personal layoff, freelance pivot, moms and work shift" />
      <node TEXT="since 75% of American women would go broke while taking 8 weeks of leave" LINK="https://www.fatherly.com/news/75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave" />
    </node>
    <node TEXT="Why must work be binary?">
      <node TEXT="Call for systemic work evolution, inclusion, and hybrid workplaces" />
    </node>
    <node TEXT="The Workplace Isn #39;t Working for Everyone">
      <node TEXT="Real-world example, lack of workplace flexibility and impact" />
    </node>
    <node TEXT="The “Great Resignation”   Losing Talent">
      <node TEXT="Major exodus, inclusion gaps, statistics on work departure" />
      <node TEXT="business leaders say they are highly committed" LINK="https://www.mckinsey.com/featured-insights/diversity-and-inclusion/women-in-the-workplace" />
      <node TEXT="30-year low." LINK="https://en.wikipedia.org/wiki/Labor_force_in_the_United_States#cite_note-45" />
      <node TEXT="employees age 30 to 45" LINK="https://www.superstaff.com/blog/top-20-great-resignation-statistics/" />
      <node TEXT="One-third" LINK="https://www.latimes.com/politics/story/2021-08-18/pandemic-pushes-moms-to-scale-back-or-quit-their-careers" />
      <node TEXT="disappeared from the workforce" LINK="https://www.fastcompany.com/90848858/women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics" />
      <node TEXT="black female labor participation" LINK="https://www.businessinsider.com/black-women-leaving-corporate-america-entreprenurship-startups-2022-12" />
      <node TEXT="Pew Research Center’s resignation findings" LINK="https://www.pewresearch.org/fact-tank/2022/03/09/majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disrespected/" />
      <node TEXT="McKinsey" LINK="https://www.mckinsey.com/capabilities/people-and-organizational-performance/our-insights/great-attrition-or-great-attraction-the-choice-is-yours" />
      <node TEXT="70 million Americans" LINK="https://www.zippia.com/advice/how-many-freelancers-in-the-us/" />
      <node TEXT="Gallup survey" LINK="https://www.gallup.com/workplace/397751/returning-office-current-preferred-future-state-remote-work.aspx" />
      <node TEXT="research shows" LINK="https://www.vox.com/recode/23129752/work-from-home-productivity" />
      <node TEXT="HBR, BCG" LINK="https://www.hbs.edu/managing-the-future-of-work/Documents/Building_The_On_Demand_Workforce.pdf" />
      <node TEXT="recently polled" LINK="https://www.forbes.com/sites/tracybrower/2022/07/24/burnout-is-a-worldwide-problem-5-ways-work-must-change/?sh=1bbaf3a76c1e" />
    </node>
    <node TEXT="Blended Work Ecosystems   Sustainability">
      <node TEXT="Blended workforce value, agility, reduced costs, innovation" />
      <node TEXT="A.team" LINK="http://www.a.team/" />
      <node TEXT="MITSloan reference" />
      <node TEXT="Era of Sustainability: Measuring Impact Over Hours" />
    </node>
    <node TEXT="Highest   Best Use Operating System™">
      <node TEXT="System for business priorities, talent/task alignment, belonging" />
      <node TEXT="The 3Ms: Magnet, Momentum, Maximum" />
      <node TEXT="Applying the 3Ms to the work ecosystem" />
    </node>
    <node TEXT="Our Process of Establishing HBU">
      <node TEXT="First Step: Highest   Best Organization" />
      <node TEXT="Second Step: Highest   Best You" />
      <node TEXT="Third Step: Highest   Best Community" />
      <node TEXT="Stitching It All Together: Your Ecosystem is Unique" />
    </node>
    <node TEXT="Unlocking HBU: High-EQ Change Management">
      <node TEXT="TRUST model: Transparency, Relationships, Uproot, Sustainability, Tribute" />
      <node TEXT="Dr. Renee St. Jacques" LINK="https://www.reneestjacques.com/" />
    </node>
    <node TEXT="Blending Our Workforce: Natalie’s Example">
      <node TEXT="Fictional scenario of blended team leadership and implementation" />
    </node>
    <node TEXT="Building the Plane While You Fly It">
      <node TEXT="Adapting new work models in real time; guidance for change" />
      <node TEXT="Very Practical Advice for Proliferating HBU" />
      <node TEXT="How to Convince Your Boss or Peers You Need HBU" />
      <node TEXT="The P L Benefits of a Blended Workforce" />
      <node TEXT="Human Resources vs Procurement: Who Manages the Blended Workforce?" />
    </node>
    <node TEXT="A Few Things to Dream About">
      <node TEXT="Every Org Needs a 'Gig Economy'" />
      <node TEXT="FLEX network" LINK="https://www.webwire.com/ViewPressRel.asp?aId=242981" />
      <node TEXT="public version in the Netherlands" LINK="https://unileverfreelancers.talent-pool.com/" />
      <node TEXT="Josh Bersin highlights" LINK="https://joshbersin.com/2019/07/the-company-as-a-talent-network-unilever-and-schneider-electric-show-the-way/" />
      <node TEXT="Jon Younger recently published" LINK="https://www.forbes.com/sites/jonyounger/2022/12/01/six-ways-that-freelancers-will-improve-project-team-engagement-and-performance/?sh=45f3f32f1b81" />
      <node TEXT="Commitments to Diversity are Now Public" />
      <node TEXT="public commitment" LINK="https://docs.google.com/spreadsheets/d/11OBEAG8yQs3olTDDFwt6PoSy9Lqjk9cWslCc-H_ytyo/edit#gid=0" />
      <node TEXT="Measure Up initiative" LINK="https://www.prnewswire.com/news-releases/fortune-and-refinitiv-encourage-unprecedented-corporate-diversity-disclosure-and-accountability-through-new-measure-up-partnership-301159688.html" />
      <node TEXT="Diverse company lists like these" LINK="https://vervoe.com/most-diverse-companies/" />
      <node TEXT="inclusive approach to procurement" LINK="https://hbr.org/2020/08/why-you-need-a-supplier-diversity-program" />
      <node TEXT="Portable Benefits for Independent Workers" />
      <node TEXT="National Conference of State Legislators" LINK="https://www.ncsl.org/research/labor-and-employment/portable-benefits-for-gig-workers.aspx#:~:text=Policymakers%2C%20industry%20innovators%2C%20labor%20organizers,and%20drive%20broader%20economic%20prosperity." />
      <node TEXT="potential" LINK="https://www.aspeninstitute.org/publications/designing-portable-benefits/" />
      <node TEXT="Hybrid   Flex Work Permanence" />
      <node TEXT="According to Gallup" LINK="https://www.gallup.com/workplace/390632/future-hybrid-work-key-questions-answered-data.aspx" />
      <node TEXT="enable non-linear days" LINK="https://www.bbc.com/worklife/article/20220928-the-non-linear-workdays-changing-the-shape-of-productivity" />
      <node TEXT="flexible work policy examples" LINK="https://www.shrm.org/resourcesandtools/tools-and-samples/policies/pages/cms_000593.aspx#:~:text=Flextime%2C%20in%20which%20an%20employee,leave%20earlier%20in%20the%20afternoon." />
      <node TEXT="Mercer reports" LINK="https://www.mercer.us/content/dam/mercer/attachments/north-america/us/us-2022-inside-employees-minds-infographic.pdf?utm_source=marketo&amp;utm_medium=email&amp;utm_campaign=NSW1&amp;utm_term=rethinking-the-way-we-work-flexible-work-policies&amp;utm_content=newsletter&amp;utm_country=us&amp;adobe_mc=MCMID%3D28544653033654653390475691018962050474%7CMCORGID%3D7205F0F5559E57A87F000101%2540AdobeOrg%7CTS%3D1671228362" />
    </node>
    <node TEXT="In Conclusion">
      <node TEXT="Summary of call to action, rebuilding, access, inclusion, burnout prevention" />
    </node>
    <node TEXT="Where to from here?">
      <node TEXT="Download a pdf version" LINK="https://lionsandtigers.com/playbook-download/" />
      <node TEXT="Reach out to our team" LINK="https://lionsandtigers.com/talk-to-us/" />
      <node TEXT="here (Subscribe to newsletter)" LINK="https://lionsandtigers.com/newsletter/" />
      <node TEXT="Brea on LinkedIn" LINK="https://www.linkedin.com/in/breastarmer/" />
      <node TEXT="our blog" LINK="https://lionsandtigers.com/blog/" />
    </node>
  </node>
</map>