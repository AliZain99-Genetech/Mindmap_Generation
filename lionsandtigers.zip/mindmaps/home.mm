<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Professional Workforce   Staffing Solutions - Lions   Tigers">
    <node TEXT="Header">
      <node TEXT="Logo" />
      <node TEXT="Navigation">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" />
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/" />
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" />
        <node TEXT="Resources">
          <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
          <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" />
          <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/" />
        </node>
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
      </node>
    </node>
    <node TEXT="Home Page">
      <node TEXT="Hero Section">
        <node TEXT="Build Your Dream Team" />
        <node TEXT="Description">
          <node TEXT="Highly skilled marketing, comms, operations   change specialists waiting for you. Drive your business   your people forward – no compromises." />
        </node>
        <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/" />
        <node TEXT="Hero Image" />
      </node>
      <node TEXT="Trusted By">
        <node TEXT="Logos">
          <node TEXT="XBOX" />
          <node TEXT="ada developers academy" />
          <node TEXT="Alaska Airlines" />
          <node TEXT="GitHub" />
          <node TEXT="Microsoft" />
          <node TEXT="Minecraft" />
          <node TEXT="Tribute" />
        </node>
      </node>
      <node TEXT="Model Section">
        <node TEXT="Our model fits your needs   our people" />
        <node TEXT="Description">
          <node TEXT="We design the solutions that fit your needs – today   tomorrow." />
        </node>
        <node TEXT="Model Types">
          <node TEXT="Full-time   Fractional" />
          <node TEXT="Individuals   Teams" />
          <node TEXT="Time   Outcome Based" />
        </node>
      </node>
      <node TEXT="Client Testimonial">
        <node TEXT="A Word From Our Clients" />
        <node TEXT="Testimonial Quote" />
        <node TEXT="Client Name">
          <node TEXT="DeAnna Paddleford" />
          <node TEXT="Change Management Strategy Lead" />
        </node>
      </node>
      <node TEXT="Culture Section">
        <node TEXT="Want to build a culture of high performance   belonging?" />
        <node TEXT="Description">
          <node TEXT="We built a playbook for leaders who are thinking about workforce innovation and need a system for change. Our Highest   Best Use Operating System™ maximizes human potential aligned to business outcomes, while guarding against burnout and exclusion." />
        </node>
        <node TEXT="LEARN MORE Button" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
      </node>
      <node TEXT="Vision   Mission">
        <node TEXT="Vision">
          <node TEXT="To unlock the full potential of the workforce." />
        </node>
        <node TEXT="Mission">
          <node TEXT="We strengthen businesses with the power of the independent workforce by building blended, human-centered teams." />
        </node>
        <node TEXT="OUR STORY Button" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Team Image" />
        <node TEXT="Team Diversity Note">
          <node TEXT="Our team self-identifies as 87% women." />
        </node>
      </node>
      <node TEXT="Work With Us">
        <node TEXT="Clients">
          <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/" />
        </node>
        <node TEXT="Talent">
          <node TEXT="JOIN OUR TEAM Button" LINK="https://lionsandtigers.com/join-our-team/" />
        </node>
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Company Info">
        <node TEXT="Lions   Tigers Logo" />
        <node TEXT="Professional Staffing   Workforce Solutions Partner" />
      </node>
      <node TEXT="About Us">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" />
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" />
        <node TEXT="DEI" LINK="https://lionsandtigers.com/dei/" />
      </node>
      <node TEXT="Solutions">
        <node TEXT="Working Together" LINK="https://lionsandtigers.com/solutions/#working-together" />
        <node TEXT="Engagement Model" LINK="https://lionsandtigers.com/solutions/#engagement-model" />
        <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" />
        <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories" />
      </node>
      <node TEXT="Resources">
        <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
        <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" />
        <node TEXT="Media" LINK="https://lionsandtigers.com/media/" />
        <node TEXT="General Inquiries" LINK="https://lionsandtigers.com/general-inquiries/" />
      </node>
      <node TEXT="Newsletter">
        <node TEXT="Description">
          <node TEXT="Learn about our solutions, our success stories, best practices, and thought leadership." />
        </node>
        <node TEXT="Newsletter Form">
          <node TEXT="Email (input field)" />
          <node TEXT="SUBSCRIBE (button)" />
        </node>
      </node>
      <node TEXT="Social Media">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers" />
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco" />
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/" />
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco" />
      </node>
      <node TEXT="Privacy Policy" LINK="https://lionsandtigers.com/privacy-policy/" />
    </node>
  </node>
</map>