<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="our story">
    <node TEXT="The Power of  ">
      <node TEXT="Introduction">
        <node TEXT="If tomorrow is never promised, then today needs to fulfill more of what we want." />
      </node>
    </node>
    <node TEXT="How it all started: Re-imagining Work   Life">
      <node TEXT="Summary">
        <node TEXT="Created conditions for individuals to thrive on their terms   in community." />
      </node>
      <node TEXT="Video: Story of Brea Starmer" />
    </node>
    <node TEXT="Vision and Mission">
      <node TEXT="Vision: To unlock the full potential of the workforce." />
      <node TEXT="Mission: Strengthen businesses with blended, human-centered teams." />
    </node>
    <node TEXT="Our Values">
      <node TEXT="Community: Nurturing collective action and economic access." />
      <node TEXT="Impact: Ownership, outcomes over output." />
      <node TEXT="Stewardship: Leave things better than we found them." />
      <node TEXT="Courage: Lead with resilience and empathy." />
    </node>
    <node TEXT="Recent Recognition">
      <node TEXT="Awards and Industry Recognition" />
    </node>
    <node TEXT="L T Talent Network">
      <node TEXT="Team Showcase Photos" />
    </node>
    <node TEXT="Staff Team">
      <node TEXT="Brea Starmer (Founder, CEO)">
        <node TEXT="Bio">
          <node TEXT="Bio" LINK="https://lionsandtigers.com/brea-starmer" />
        </node>
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/breastarmer" />
      </node>
      <node TEXT="Ashley Jude (President)">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/ashleyjude" />
      </node>
      <node TEXT="Lorraine Cunningham (Chief Technology   Financial Officer)">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/cunninghamlorraine" />
      </node>
      <node TEXT="LaShunte Portrey (Business Development)">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/lashunteportrey/" />
      </node>
      <node TEXT="Steven Rowe (Client Experience)">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/sttrowe" />
      </node>
      <node TEXT="Reiko Kono (Client Experience)">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/reiko-kono-161056171/" />
      </node>
      <node TEXT="Shannon Lee (Client Experience Team)">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/shannon-lee13/" />
      </node>
      <node TEXT="Nan Jackson (Marketing)">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/nanbjackson" />
      </node>
      <node TEXT="Miranda Leurquin (Talent Advocacy)">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mirandaleurquin/" />
      </node>
      <node TEXT="Jocylynn Kelley (Talent Advocacy)">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/jocylynn-kelley/" />
      </node>
      <node TEXT="Allison Monat (Talent Advocacy)">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/allisonsmonat" />
      </node>
      <node TEXT="Mercedes Dunn (Talent Advocacy)">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mercedesdunn/" />
      </node>
    </node>
    <node TEXT="Clients">
      <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
    </node>
    <node TEXT="Talent">
      <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" />
    </node>
  </node>
</map>