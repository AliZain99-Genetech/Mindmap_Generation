<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="our story">
    <node TEXT="The Power of   (introduction)">
      <node TEXT="Re-imagining Work   Life (section summary)" />
      <node TEXT="Video (main intro video)" />
    </node>
    <node TEXT="Vision   Mission">
      <node TEXT="Vision: Unlock the full potential of the workforce" />
      <node TEXT="Mission: Strengthen businesses by building blended, human-centered teams" />
    </node>
    <node TEXT="Our Values">
      <node TEXT="Community: Collective action for representation and economic access" />
      <node TEXT="Entrepreneurship: Ownership, highest   best use, outcomes over output" />
      <node TEXT="Stewardship: Service plus advocacy, invest to leave things better" />
      <node TEXT="Courage: Leadership through resilience, push boundaries" />
    </node>
    <node TEXT="Recent Recognition">
      <node TEXT="Awards and badges (visual row of recognitions)" />
    </node>
    <node TEXT="L T Talent Network">
      <node TEXT="Team   Community Photo Grid" />
    </node>
    <node TEXT="Staff Team">
      <node TEXT="Brea Starmer, Founder, CEO">
        <node TEXT="Bio">
          <node TEXT="https://lionsandtigers.com/brea-starmer" />
        </node>
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/breastarmer" />
        </node>
      </node>
      <node TEXT="Ashley Jude, President">
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/ashleyjude" />
        </node>
      </node>
      <node TEXT="Lorraine Cunningham, CTO   Financial Officer">
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/cunninghamlorraine" />
        </node>
      </node>
      <node TEXT="LaShunte Portrey, Business Development">
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/lashunteportrey/" />
        </node>
      </node>
      <node TEXT="Steven Rowe, Client Experience">
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/sttrowe" />
        </node>
      </node>
      <node TEXT="Reiko Kono, Client Experience">
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/reiko-kono-161056171/" />
        </node>
      </node>
      <node TEXT="Shannon Lee, Client Experience Team">
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/shannon-lee13/" />
        </node>
      </node>
      <node TEXT="Nan Jackson, Marketing">
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/nanbjackson" />
        </node>
      </node>
      <node TEXT="Miranda Leurquin, Talent Advocacy">
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/mirandaleurquin/" />
        </node>
      </node>
      <node TEXT="Jocylynn Kelley, Talent Advocacy">
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/jocylynn-kelley/" />
        </node>
      </node>
      <node TEXT="Allison Monat, Talent Advocacy">
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/allisonsmonat" />
        </node>
      </node>
      <node TEXT="Mercedes Dunn, Talent Advocacy">
        <node TEXT="LinkedIn">
          <node TEXT="https://www.linkedin.com/in/mercedesdunn/" />
        </node>
      </node>
    </node>
    <node TEXT="Work with us">
      <node TEXT="TALK TO US">
        <node TEXT="https://lionsandtigers.com/talk-to-us/" />
      </node>
      <node TEXT="JOIN OUR TEAM">
        <node TEXT="https://lionsandtigers.com/join-our-team/" />
      </node>
    </node>
  </node>
</map>