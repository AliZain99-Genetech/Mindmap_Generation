<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="solutions">
    <node TEXT="Built For Fortune 500s   Startups">
      <node TEXT="Powered by 100+ consultants, design the team   solutions you need now." />
    </node>
    <node TEXT="Working together">
      <node TEXT="Co-design workforce solutions aligned to your key outcomes." />
      <node TEXT="ROAR Methodology Results" />
    </node>
    <node TEXT="Engagement Model Built for You">
      <node TEXT="Full-time   Fractional" />
      <node TEXT="Individuals   Teams" />
      <node TEXT="Time   Outcome Based" />
    </node>
    <node TEXT="Capabilities   Skillsets">
      <node TEXT="Communications   Marketing" />
      <node TEXT="Operations" />
      <node TEXT="Change" />
    </node>
    <node TEXT="Client Stories">
      <node TEXT="To scale myself   level up my team" />
      <node TEXT="My team to feel safe   inclusive" />
      <node TEXT="Product insights   raving fans" />
      <node TEXT="Flexibility   less risk" />
      <node TEXT="A sprint staff   domain experts" />
    </node>
    <node TEXT="Work with us">
      <node TEXT="Clients">
        <node TEXT="TALK TO US">
          <node TEXT="https://lionsandtigers.com/talk-to-us/" />
        </node>
      </node>
      <node TEXT="Talent">
        <node TEXT="JOIN OUR TEAM">
          <node TEXT="https://lionsandtigers.com/join-our-team/" />
        </node>
      </node>
    </node>
  </node>
</map>