<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="solutions">
    <node TEXT="Built For Fortune 500s   Startups">
      <node TEXT="Powered by 100+ consultants, workforce design   solutions." />
    </node>
    <node TEXT="Working together">
      <node TEXT="Collaborative ROAR methodology co-designs workforce solutions." />
      <node TEXT="ROAR Framework: Results, Ownership, Accountability, Relationship" />
    </node>
    <node TEXT="Engagement Model Built for YOU" LINK="https://lionsandtigers.com/solutions/#engagement-model">
      <node TEXT="Talent available: Full-time   Fractional, Individuals   Teams, Time   Outcome Based" />
      <node TEXT="Team structure and experience levels summary" />
    </node>
    <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets">
      <node TEXT="Communications   Marketing, Operations, Change" />
    </node>
    <node TEXT="Client Stories" LINK="https://lionsandtigers.com/solutions/#client-stories">
      <node TEXT="Case study needs: Scale team, inclusivity, product insights, flexibility, domain experts" />
    </node>
    <node TEXT="Work with us">
      <node TEXT="CLIENTS">
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
      </node>
      <node TEXT="TALENT">
        <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" />
      </node>
    </node>
  </node>
</map>