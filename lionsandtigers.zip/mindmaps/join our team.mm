<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="join our team">
    <node TEXT="Intro: Inclusive Community   Flexibility">
      <node TEXT="We are an inclusive community of marketing, comms, operations and change specialists who value high-impact work   flexibility." />
      <node TEXT="EXPLORE OPEN ROLES">
        <node TEXT="Link: EXPLORE OPEN ROLES" LINK="https://lionsandtigers.com/join-our-team/#open-roles" />
      </node>
    </node>
    <node TEXT="What it means to be a great place to work">
      <node TEXT="We are re-writing what it means to be a great place to work." />
      <node TEXT="Flexibility: Flexible roles, 5 to 40 hours a week" />
      <node TEXT="Community: Join a supportive team" />
      <node TEXT="Values: Community, impact, stewardship, courage" />
      <node TEXT="Resources   Growth: Workshops, resource library, support" />
      <node TEXT="Remote Work: Work from anywhere" />
      <node TEXT="Transparency: Meetings, channels, 1:1s, informed team" />
      <node TEXT="DEI: Multi-year anti-racist journey">
        <node TEXT="more" LINK="https://lionsandtigers.com/dei" />
      </node>
      <node TEXT="Fun: Family picnics, parties, happy hours" />
    </node>
    <node TEXT="Open Roles">
      <node TEXT="Open Jobs: Data Analyst, Events Manager, Communications Manager, Project Manager, Change Management, and open applications." />
      <node TEXT="CONSULTANT FAQ">
        <node TEXT="Link: CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/" />
      </node>
    </node>
    <node TEXT="Talent Newsletter">
      <node TEXT="Sign up for open roles and news" />
      <node TEXT="Form">
        <node TEXT="Field: Enter Your email address" />
        <node TEXT="SUBSCRIBE" />
      </node>
    </node>
    <node TEXT="Team Impact Stats">
      <node TEXT="97.5% consultant retention rate" />
      <node TEXT="$34M paid out to consultants" />
      <node TEXT="100% work fully remote or hybrid" />
      <node TEXT="87% women team members (self-identified)" />
    </node>
    <node TEXT="What Happens After You Apply">
      <node TEXT="1. Apply for a role via online application" />
      <node TEXT="2. Application reviewed by a real person" />
      <node TEXT="3. If a fit, contacted for an initial call" />
      <node TEXT="4. You will not be ghosted" />
      <node TEXT="CONSULTANT FAQ">
        <node TEXT="Link: CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/" />
      </node>
    </node>
    <node TEXT="From Our Team">
      <node TEXT="Testimonial: Ability to chart own path, flexibility, and personal reflection" />
    </node>
  </node>
</map>