<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="join our team">
    <node TEXT="Inclusive community   open roles">
      <node TEXT="Explore open roles">
        <node TEXT="EXPLORE OPEN ROLES">
          <node TEXT="https://lionsandtigers.com/join-our-team/#open-roles" />
        </node>
      </node>
    </node>
    <node TEXT="What it means to be a great place to work">
      <node TEXT="Summary: Flexibility, community, values, growth, remote work, DEI, transparency, fun" />
      <node TEXT="DEI">
        <node TEXT="more">
          <node TEXT="https://lionsandtigers.com/dei" />
        </node>
      </node>
    </node>
    <node TEXT="Open Roles">
      <node TEXT="Open jobs board and positions listing" />
    </node>
    <node TEXT="Talent Newsletter">
      <node TEXT="Subscribe for open roles   updates (form)">
        <node TEXT="Field: Enter Your email address" />
        <node TEXT="Button: SUBSCRIBE" />
      </node>
    </node>
    <node TEXT="Consultant stats   highlights">
      <node TEXT="Retention rate, payouts, remote/hybrid stats, women ratio summary" />
    </node>
    <node TEXT="What Happens After You Apply">
      <node TEXT="Application process steps summarized" />
      <node TEXT="CONSULTANT FAQ">
        <node TEXT="CONSULTANT FAQ">
          <node TEXT="https://lionsandtigers.com/consultant-faq/" />
        </node>
      </node>
    </node>
    <node TEXT="From Our Team">
      <node TEXT="Testimonial quote" />
    </node>
  </node>
</map>