<?xml version='1.0' encoding='UTF-8'?>
<map version="1.0.1">
  <node TEXT="Professional Workforce   Staffing Solutions - Lions   Tigers" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Logo" FOLDED="true"/>
      <node TEXT="Navigation" FOLDED="true">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" FOLDED="true">
          <node TEXT="The Power of   (introduction)" FOLDED="true">
            <node TEXT="Re-imagining Work   Life (section summary)" FOLDED="true"/>
            <node TEXT="Video (main intro video)" FOLDED="true"/>
          </node>
          <node TEXT="Vision   Mission" FOLDED="true">
            <node TEXT="Vision: Unlock the full potential of the workforce" FOLDED="true"/>
            <node TEXT="Mission: Strengthen businesses by building blended, human-centered teams" FOLDED="true"/>
          </node>
          <node TEXT="Our Values" FOLDED="true">
            <node TEXT="Community: Collective action for representation and economic access" FOLDED="true"/>
            <node TEXT="Entrepreneurship: Ownership, highest   best use, outcomes over output" FOLDED="true"/>
            <node TEXT="Stewardship: Service plus advocacy, invest to leave things better" FOLDED="true"/>
            <node TEXT="Courage: Leadership through resilience, push boundaries" FOLDED="true"/>
          </node>
          <node TEXT="Recent Recognition" FOLDED="true">
            <node TEXT="Awards and badges (visual row of recognitions)" FOLDED="true"/>
          </node>
          <node TEXT="L T Talent Network" FOLDED="true">
            <node TEXT="Team   Community Photo Grid" FOLDED="true"/>
          </node>
          <node TEXT="Staff Team" FOLDED="true">
            <node TEXT="Brea Starmer, Founder, CEO" FOLDED="true">
              <node TEXT="Bio" FOLDED="true">
                <node TEXT="brea-starmer" LINK="https://lionsandtigers.com/brea-starmer" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_brea-starmer.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="breastarmer" LINK="https://www.linkedin.com/in/breastarmer" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Ashley Jude, President" FOLDED="true">
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="ashleyjude" LINK="https://www.linkedin.com/in/ashleyjude" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_ashleyjude.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Lorraine Cunningham, CTO   Financial Officer" FOLDED="true">
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="cunninghamlorraine" LINK="https://www.linkedin.com/in/cunninghamlorraine" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_cunninghamlorraine.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="LaShunte Portrey, Business Development" FOLDED="true">
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="lashunteportrey" LINK="https://www.linkedin.com/in/lashunteportrey/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_lashunteportrey.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Steven Rowe, Client Experience" FOLDED="true">
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="sttrowe" LINK="https://www.linkedin.com/in/sttrowe" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_sttrowe.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Reiko Kono, Client Experience" FOLDED="true">
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="reiko-kono-161056171" LINK="https://www.linkedin.com/in/reiko-kono-161056171/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_reiko-kono-161056171.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Shannon Lee, Client Experience Team" FOLDED="true">
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="shannon-lee13" LINK="https://www.linkedin.com/in/shannon-lee13/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_shannon-lee13.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Nan Jackson, Marketing" FOLDED="true">
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="nanbjackson" LINK="https://www.linkedin.com/in/nanbjackson" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_nanbjackson.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Miranda Leurquin, Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="mirandaleurquin" LINK="https://www.linkedin.com/in/mirandaleurquin/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_mirandaleurquin.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Jocylynn Kelley, Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="jocylynn-kelley" LINK="https://www.linkedin.com/in/jocylynn-kelley/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_jocylynn-kelley.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Allison Monat, Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="allisonsmonat" LINK="https://www.linkedin.com/in/allisonsmonat" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_allisonsmonat.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Mercedes Dunn, Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" FOLDED="true">
                <node TEXT="mercedesdunn" LINK="https://www.linkedin.com/in/mercedesdunn/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_mercedesdunn.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
          </node>
          <node TEXT="Work with us" FOLDED="true">
            <node TEXT="TALK TO US" FOLDED="true">
              <node TEXT="talk-to-us" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Contact Introduction" FOLDED="true">
                <node TEXT="Consultant inquiry instructions" FOLDED="true"/>
                <node TEXT="Team join interest" FOLDED="true">
                  <node TEXT="Learn more" FOLDED="true">
                    <node TEXT="here (Join Our Team)" FOLDED="true">
                      <node TEXT="join-our-team" LINK="https://lionsandtigers.com/join-our-team" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                    </node>
                  </node>
                </node>
              </node>
              <node TEXT="Contact Form" FOLDED="true">
                <node TEXT="*First Name" FOLDED="true"/>
                <node TEXT="*Last Name" FOLDED="true"/>
                <node TEXT="*Title" FOLDED="true"/>
                <node TEXT="*Organization" FOLDED="true"/>
                <node TEXT="*Email" FOLDED="true"/>
                <node TEXT="*Phone" FOLDED="true"/>
                <node TEXT="*Message" FOLDED="true"/>
                <node TEXT="Math Captcha" FOLDED="true"/>
                <node TEXT="Submit Button" FOLDED="true"/>
              </node>
            </node>
            <node TEXT="JOIN OUR TEAM" FOLDED="true">
              <node TEXT="join-our-team" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" FOLDED="true">
          <node TEXT="Workforce Reimagined – Unlocking the Power of Blended Teams" FOLDED="true">
            <node TEXT="Summary: Traditional workforce models are failing; new research on blended teams" FOLDED="true"/>
            <node TEXT="Read the Research Report" FOLDED="true">
              <node TEXT="Link" LINK="https://lionsandtigers.com/why-now/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="The American workforce is at an inflection point" FOLDED="true">
            <node TEXT="Summary: Key statistics about women, freelancers, and the future workforce" FOLDED="true"/>
          </node>
          <node TEXT="Why This Study" FOLDED="true">
            <node TEXT="Summary: The shift for leaders; study overview and goals" FOLDED="true"/>
            <node TEXT="Brea Starmer" FOLDED="true">
              <node TEXT="Link" LINK="https://www.linkedin.com/in/breastarmer/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Expert Insight – Paul Estes Quote" FOLDED="true">
            <node TEXT="Summary: Leaders who prioritize flexibility and expertise will thrive" FOLDED="true"/>
          </node>
          <node TEXT="The Data Is In: Blended Teams Work" FOLDED="true">
            <node TEXT="Summary: Data-driven benefits of blended teams, including speed, innovation, skills, and quality" FOLDED="true"/>
          </node>
          <node TEXT="The Value Compounds Over Time" FOLDED="true">
            <node TEXT="Summary: Strategic advantage increases with longer tenure using blended teams" FOLDED="true"/>
          </node>
          <node TEXT="Future Workforce Arc – Pam Cohen Quote" FOLDED="true">
            <node TEXT="Summary: Blended teams are now a fundamental part of work" FOLDED="true"/>
          </node>
          <node TEXT="Why It Matters" FOLDED="true">
            <node TEXT="Summary: Blended teams support women, caregivers, and AI transitions" FOLDED="true"/>
          </node>
          <node TEXT="The 2025 Blended Workforce Survey" FOLDED="true">
            <node TEXT="Summary: Research conducted by Read the Room Advisors; survey methodology and purpose" FOLDED="true"/>
            <node TEXT="Download Full Survey Report" FOLDED="true">
              <node TEXT="Link" LINK="https://lionsandtigers.com/why-now/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/" FOLDED="true">
          <node TEXT="Built For Fortune 500s   Startups" FOLDED="true">
            <node TEXT="Powered by 100+ consultants, design the team   solutions you need now." FOLDED="true"/>
          </node>
          <node TEXT="Working together" FOLDED="true">
            <node TEXT="Co-design workforce solutions aligned to your key outcomes." FOLDED="true"/>
            <node TEXT="ROAR Methodology Results" FOLDED="true"/>
          </node>
          <node TEXT="Engagement Model Built for You" FOLDED="true">
            <node TEXT="Full-time   Fractional" FOLDED="true"/>
            <node TEXT="Individuals   Teams" FOLDED="true"/>
            <node TEXT="Time   Outcome Based" FOLDED="true"/>
          </node>
          <node TEXT="Capabilities   Skillsets" FOLDED="true">
            <node TEXT="Communications   Marketing" FOLDED="true"/>
            <node TEXT="Operations" FOLDED="true"/>
            <node TEXT="Change" FOLDED="true"/>
          </node>
          <node TEXT="Client Stories" FOLDED="true">
            <node TEXT="To scale myself   level up my team" FOLDED="true"/>
            <node TEXT="My team to feel safe   inclusive" FOLDED="true"/>
            <node TEXT="Product insights   raving fans" FOLDED="true"/>
            <node TEXT="Flexibility   less risk" FOLDED="true"/>
            <node TEXT="A sprint staff   domain experts" FOLDED="true"/>
          </node>
          <node TEXT="Work with us" FOLDED="true">
            <node TEXT="Clients" FOLDED="true">
              <node TEXT="TALK TO US" FOLDED="true">
                <node TEXT="talk-to-us" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Talent" FOLDED="true">
              <node TEXT="JOIN OUR TEAM" FOLDED="true">
                <node TEXT="join-our-team" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true">
          <node TEXT="Intro: Inclusive Community   Flexibility" FOLDED="true">
            <node TEXT="We are an inclusive community of marketing, comms, operations and change specialists who value high-impact work   flexibility." FOLDED="true"/>
            <node TEXT="EXPLORE OPEN ROLES" FOLDED="true">
              <node TEXT="Link: EXPLORE OPEN ROLES" LINK="https://lionsandtigers.com/join-our-team/#open-roles" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team_open-roles.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="What it means to be a great place to work" FOLDED="true">
            <node TEXT="We are re-writing what it means to be a great place to work." FOLDED="true"/>
            <node TEXT="Flexibility: Flexible roles, 5 to 40 hours a week" FOLDED="true"/>
            <node TEXT="Community: Join a supportive team" FOLDED="true"/>
            <node TEXT="Values: Community, impact, stewardship, courage" FOLDED="true"/>
            <node TEXT="Resources   Growth: Workshops, resource library, support" FOLDED="true"/>
            <node TEXT="Remote Work: Work from anywhere" FOLDED="true"/>
            <node TEXT="Transparency: Meetings, channels, 1:1s, informed team" FOLDED="true"/>
            <node TEXT="DEI: Multi-year anti-racist journey" FOLDED="true">
              <node TEXT="more" LINK="https://lionsandtigers.com/dei" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_dei.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Fun: Family picnics, parties, happy hours" FOLDED="true"/>
          </node>
          <node TEXT="Open Roles" FOLDED="true">
            <node TEXT="Open Jobs: Data Analyst, Events Manager, Communications Manager, Project Manager, Change Management, and open applications." FOLDED="true"/>
            <node TEXT="CONSULTANT FAQ" FOLDED="true">
              <node TEXT="Link: CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_consultant-faq.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Talent Newsletter" FOLDED="true">
            <node TEXT="Sign up for open roles and news" FOLDED="true"/>
            <node TEXT="Form" FOLDED="true">
              <node TEXT="Field: Enter Your email address" FOLDED="true"/>
              <node TEXT="SUBSCRIBE" FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Team Impact Stats" FOLDED="true">
            <node TEXT="97.5% consultant retention rate" FOLDED="true"/>
            <node TEXT="$34M paid out to consultants" FOLDED="true"/>
            <node TEXT="100% work fully remote or hybrid" FOLDED="true"/>
            <node TEXT="87% women team members (self-identified)" FOLDED="true"/>
          </node>
          <node TEXT="What Happens After You Apply" FOLDED="true">
            <node TEXT="1. Apply for a role via online application" FOLDED="true"/>
            <node TEXT="2. Application reviewed by a real person" FOLDED="true"/>
            <node TEXT="3. If a fit, contacted for an initial call" FOLDED="true"/>
            <node TEXT="4. You will not be ghosted" FOLDED="true"/>
            <node TEXT="CONSULTANT FAQ" FOLDED="true">
              <node TEXT="Link: CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_consultant-faq.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="From Our Team" FOLDED="true">
            <node TEXT="Testimonial: Ability to chart own path, flexibility, and personal reflection" FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Resources" FOLDED="true">
          <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" FOLDED="true">
            <node TEXT="Avoiding the All-Or-Nothing Workplace: Introduction" FOLDED="true">
              <node TEXT="Enabling People to Operate at their Highest   Best Use" FOLDED="true"/>
              <node TEXT="Brea Starmer, Founder/CEO" FOLDED="true"/>
              <node TEXT="Download a pdf of the playbook" FOLDED="true">
                <node TEXT="here" LINK="https://lionsandtigers.com/playbook-download/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_playbook-download.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Listen to the audio version" FOLDED="true">
                <node TEXT="audio version." LINK="https://player.captivate.fm/episode/ae64d6e2-5fb9-49fb-95e8-46d0a2433c68" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_player.captivate.fm_episode_ae64d6e2-5fb9-49fb-95e8-46d0a2433c68.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Contents Overview" FOLDED="true">
              <node TEXT="Future Now of Work sections summary" FOLDED="true"/>
              <node TEXT="Workplace Isn #39;t Working, The Great Resignation, HBU System, 3Ms, Community, Practical Advice - all summarized" FOLDED="true"/>
            </node>
            <node TEXT="Workplace Transformation Story" FOLDED="true">
              <node TEXT="Personal layoff, freelance pivot, moms and work shift" FOLDED="true"/>
              <node TEXT="since 75% of American women would go broke while taking 8 weeks of leave" LINK="https://www.fatherly.com/news/75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.fatherly.com_news_75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Why must work be binary?" FOLDED="true">
              <node TEXT="Call for systemic work evolution, inclusion, and hybrid workplaces" FOLDED="true"/>
            </node>
            <node TEXT="The Workplace Isn #39;t Working for Everyone" FOLDED="true">
              <node TEXT="Real-world example, lack of workplace flexibility and impact" FOLDED="true"/>
            </node>
            <node TEXT="The “Great Resignation”   Losing Talent" FOLDED="true">
              <node TEXT="Major exodus, inclusion gaps, statistics on work departure" FOLDED="true"/>
              <node TEXT="business leaders say they are highly committed" LINK="https://www.mckinsey.com/featured-insights/diversity-and-inclusion/women-in-the-workplace" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.mckinsey.com_featured-insights_diversity-and-inclusion_women-in-the-workplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="30-year low." LINK="https://en.wikipedia.org/wiki/Labor_force_in_the_United_States#cite_note-45" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_en.wikipedia.org_wiki_Labor_force_in_the_United_States_cite_note-45.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="employees age 30 to 45" LINK="https://www.superstaff.com/blog/top-20-great-resignation-statistics/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.superstaff.com_blog_top-20-great-resignation-statistics.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="One-third" LINK="https://www.latimes.com/politics/story/2021-08-18/pandemic-pushes-moms-to-scale-back-or-quit-their-careers" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.latimes.com_politics_story_2021-08-18_pandemic-pushes-moms-to-scale-back-or-quit-their-careers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="disappeared from the workforce" LINK="https://www.fastcompany.com/90848858/women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.fastcompany.com_90848858_women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="black female labor participation" LINK="https://www.businessinsider.com/black-women-leaving-corporate-america-entreprenurship-startups-2022-12" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.businessinsider.com_black-women-leaving-corporate-america-entreprenurship-startups-2022-12.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Pew Research Center’s resignation findings" LINK="https://www.pewresearch.org/fact-tank/2022/03/09/majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disrespected/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.pewresearch.org_fact-tank_2022_03_09_majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disres.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="McKinsey" LINK="https://www.mckinsey.com/capabilities/people-and-organizational-performance/our-insights/great-attrition-or-great-attraction-the-choice-is-yours" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.mckinsey.com_capabilities_people-and-organizational-performance_our-insights_great-attrition-or-great-attraction-the-choice-is-yours.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="70 million Americans" LINK="https://www.zippia.com/advice/how-many-freelancers-in-the-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.zippia.com_advice_how-many-freelancers-in-the-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Gallup survey" LINK="https://www.gallup.com/workplace/397751/returning-office-current-preferred-future-state-remote-work.aspx" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.gallup.com_workplace_397751_returning-office-current-preferred-future-state-remote-work.aspx.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="research shows" LINK="https://www.vox.com/recode/23129752/work-from-home-productivity" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.vox.com_recode_23129752_work-from-home-productivity.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="HBR, BCG" LINK="https://www.hbs.edu/managing-the-future-of-work/Documents/Building_The_On_Demand_Workforce.pdf" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.hbs.edu_managing-the-future-of-work_Documents_Building_The_On_Demand_Workforce.pdf.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="recently polled" LINK="https://www.forbes.com/sites/tracybrower/2022/07/24/burnout-is-a-worldwide-problem-5-ways-work-must-change/?sh=1bbaf3a76c1e" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.forbes.com_sites_tracybrower_2022_07_24_burnout-is-a-worldwide-problem-5-ways-work-must-change_sh_1bbaf3a76c1e.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Blended Work Ecosystems   Sustainability" FOLDED="true">
              <node TEXT="Blended workforce value, agility, reduced costs, innovation" FOLDED="true"/>
              <node TEXT="A.team" LINK="http://www.a.team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/http_www.a.team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="MITSloan reference" FOLDED="true"/>
              <node TEXT="Era of Sustainability: Measuring Impact Over Hours" FOLDED="true"/>
            </node>
            <node TEXT="Highest   Best Use Operating System™" FOLDED="true">
              <node TEXT="System for business priorities, talent/task alignment, belonging" FOLDED="true"/>
              <node TEXT="The 3Ms: Magnet, Momentum, Maximum" FOLDED="true"/>
              <node TEXT="Applying the 3Ms to the work ecosystem" FOLDED="true"/>
            </node>
            <node TEXT="Our Process of Establishing HBU" FOLDED="true">
              <node TEXT="First Step: Highest   Best Organization" FOLDED="true"/>
              <node TEXT="Second Step: Highest   Best You" FOLDED="true"/>
              <node TEXT="Third Step: Highest   Best Community" FOLDED="true"/>
              <node TEXT="Stitching It All Together: Your Ecosystem is Unique" FOLDED="true"/>
            </node>
            <node TEXT="Unlocking HBU: High-EQ Change Management" FOLDED="true">
              <node TEXT="TRUST model: Transparency, Relationships, Uproot, Sustainability, Tribute" FOLDED="true"/>
              <node TEXT="Dr. Renee St. Jacques" LINK="https://www.reneestjacques.com/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.reneestjacques.com.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Blending Our Workforce: Natalie’s Example" FOLDED="true">
              <node TEXT="Fictional scenario of blended team leadership and implementation" FOLDED="true"/>
            </node>
            <node TEXT="Building the Plane While You Fly It" FOLDED="true">
              <node TEXT="Adapting new work models in real time; guidance for change" FOLDED="true"/>
              <node TEXT="Very Practical Advice for Proliferating HBU" FOLDED="true"/>
              <node TEXT="How to Convince Your Boss or Peers You Need HBU" FOLDED="true"/>
              <node TEXT="The P L Benefits of a Blended Workforce" FOLDED="true"/>
              <node TEXT="Human Resources vs Procurement: Who Manages the Blended Workforce?" FOLDED="true"/>
            </node>
            <node TEXT="A Few Things to Dream About" FOLDED="true">
              <node TEXT="Every Org Needs a 'Gig Economy'" FOLDED="true"/>
              <node TEXT="FLEX network" LINK="https://www.webwire.com/ViewPressRel.asp?aId=242981" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.webwire.com_ViewPressRel.asp_aId_242981.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="public version in the Netherlands" LINK="https://unileverfreelancers.talent-pool.com/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_unileverfreelancers.talent-pool.com.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Josh Bersin highlights" LINK="https://joshbersin.com/2019/07/the-company-as-a-talent-network-unilever-and-schneider-electric-show-the-way/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_joshbersin.com_2019_07_the-company-as-a-talent-network-unilever-and-schneider-electric-show-the-way.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Jon Younger recently published" LINK="https://www.forbes.com/sites/jonyounger/2022/12/01/six-ways-that-freelancers-will-improve-project-team-engagement-and-performance/?sh=45f3f32f1b81" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.forbes.com_sites_jonyounger_2022_12_01_six-ways-that-freelancers-will-improve-project-team-engagement-and-performance_sh_45f3f32f1b81.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Commitments to Diversity are Now Public" FOLDED="true"/>
              <node TEXT="public commitment" LINK="https://docs.google.com/spreadsheets/d/11OBEAG8yQs3olTDDFwt6PoSy9Lqjk9cWslCc-H_ytyo/edit#gid=0" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_docs.google.com_spreadsheets_d_11OBEAG8yQs3olTDDFwt6PoSy9Lqjk9cWslCc-H_ytyo_edit_gid_0.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Measure Up initiative" LINK="https://www.prnewswire.com/news-releases/fortune-and-refinitiv-encourage-unprecedented-corporate-diversity-disclosure-and-accountability-through-new-measure-up-partnership-301159688.html" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.prnewswire.com_news-releases_fortune-and-refinitiv-encourage-unprecedented-corporate-diversity-disclosure-and-accountability-through-new-mea.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Diverse company lists like these" LINK="https://vervoe.com/most-diverse-companies/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_vervoe.com_most-diverse-companies.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="inclusive approach to procurement" LINK="https://hbr.org/2020/08/why-you-need-a-supplier-diversity-program" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_hbr.org_2020_08_why-you-need-a-supplier-diversity-program.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Portable Benefits for Independent Workers" FOLDED="true"/>
              <node TEXT="National Conference of State Legislators" LINK="https://www.ncsl.org/research/labor-and-employment/portable-benefits-for-gig-workers.aspx#:~:text=Policymakers%2C%20industry%20innovators%2C%20labor%20organizers,and%20drive%20broader%20economic%20prosperity." FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.ncsl.org_research_labor-and-employment_portable-benefits-for-gig-workers.aspx_~_text_Policymakers_2C_20industry_20innovators_2C_20labor_20or.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="potential" LINK="https://www.aspeninstitute.org/publications/designing-portable-benefits/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.aspeninstitute.org_publications_designing-portable-benefits.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Hybrid   Flex Work Permanence" FOLDED="true"/>
              <node TEXT="According to Gallup" LINK="https://www.gallup.com/workplace/390632/future-hybrid-work-key-questions-answered-data.aspx" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.gallup.com_workplace_390632_future-hybrid-work-key-questions-answered-data.aspx.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="enable non-linear days" LINK="https://www.bbc.com/worklife/article/20220928-the-non-linear-workdays-changing-the-shape-of-productivity" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.bbc.com_worklife_article_20220928-the-non-linear-workdays-changing-the-shape-of-productivity.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="flexible work policy examples" LINK="https://www.shrm.org/resourcesandtools/tools-and-samples/policies/pages/cms_000593.aspx#:~:text=Flextime%2C%20in%20which%20an%20employee,leave%20earlier%20in%20the%20afternoon." FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.shrm.org_resourcesandtools_tools-and-samples_policies_pages_cms_000593.aspx_~_text_Flextime_2C_20in_20which_20an_20employee,leave_20earlier_.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Mercer reports" LINK="https://www.mercer.us/content/dam/mercer/attachments/north-america/us/us-2022-inside-employees-minds-infographic.pdf?utm_source=marketo&amp;utm_medium=email&amp;utm_campaign=NSW1&amp;utm_term=rethinking-the-way-we-work-flexible-work-policies&amp;utm_content=newsletter&amp;utm_country=us&amp;adobe_mc=MCMID%3D28544653033654653390475691018962050474%7CMCORGID%3D7205F0F5559E57A87F000101%2540AdobeOrg%7CTS%3D1671228362" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.mercer.us_content_dam_mercer_attachments_north-america_us_us-2022-inside-employees-minds-infographic.pdf_utm_source_marketo_utm_medium_email.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="In Conclusion" FOLDED="true">
              <node TEXT="Summary of call to action, rebuilding, access, inclusion, burnout prevention" FOLDED="true"/>
            </node>
            <node TEXT="Where to from here?" FOLDED="true">
              <node TEXT="Download a pdf version" LINK="https://lionsandtigers.com/playbook-download/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_playbook-download.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Reach out to our team" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="here (Subscribe to newsletter)" LINK="https://lionsandtigers.com/newsletter/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_newsletter.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Brea on LinkedIn" LINK="https://www.linkedin.com/in/breastarmer/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="our blog" LINK="https://lionsandtigers.com/blog/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" FOLDED="true">
            <node TEXT="Courage at Work introduction" FOLDED="true">
              <node TEXT="Welcome message and overview" FOLDED="true"/>
            </node>
            <node TEXT="Explore Blog Topics" FOLDED="true">
              <node TEXT="Thought Leadership   Best Practices" FOLDED="true">
                <node TEXT="thought leadership" LINK="https://lionsandtigers.com/category/thought-leadership/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_thought-leadership.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="best practices" LINK="https://lionsandtigers.com/category/best-practices/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_best-practices.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="New   Noteworthy" FOLDED="true">
                <node TEXT="noteworthy" LINK="https://lionsandtigers.com/category/noteworthy/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_noteworthy.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="new" LINK="https://lionsandtigers.com/category/new/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_new.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="People   Projects" FOLDED="true">
                <node TEXT="people" LINK="https://lionsandtigers.com/category/people/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_category_people.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Featured Blog Posts" FOLDED="true">
              <node TEXT="Workforce Reimagined Research Launch Event" FOLDED="true">
                <node TEXT="read more" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_workforce-reimagined-research-launch-event.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Workforce Reimagined Research Launch Event" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_workforce-reimagined-research-launch-event.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic" FOLDED="true">
                <node TEXT="read more" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Building Better Workplaces for Women" FOLDED="true">
                <node TEXT="read more" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Building Better Workplaces for Women: 3 Power Moves to Help You Grow, Lead, and Thrive" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Elevating Culture   Community: Miranda Leurquin's New Chapter at L T" FOLDED="true">
                <node TEXT="read more" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_elevating-culture-community-miranda-hickmans-new-chapter-at-lt.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
                <node TEXT="Elevating Culture   Community:  Miranda Leurquin’s New Chapter at L T" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_elevating-culture-community-miranda-hickmans-new-chapter-at-lt.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
              <node TEXT="Older Entries" FOLDED="true">
                <node TEXT="« Older Entries" LINK="https://lionsandtigers.com/blog/page/2/?et_blog" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog_page_2_et_blog.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              </node>
            </node>
            <node TEXT="Newsletter Signup Form" FOLDED="true">
              <node TEXT="Email Input" FOLDED="true"/>
              <node TEXT="SUBSCRIBE Button" FOLDED="true"/>
              <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/" FOLDED="true">
                <node TEXT="Client Newsletter" FOLDED="true">
                  <node TEXT="Summary: Learn about solutions, stories, best practices, and leadership." FOLDED="true"/>
                  <node TEXT="Form" FOLDED="true">
                    <node TEXT="Email Address" FOLDED="true"/>
                    <node TEXT="Subscribe Button" FOLDED="true"/>
                  </node>
                </node>
                <node TEXT="Talent Newsletter" FOLDED="true">
                  <node TEXT="Summary: Get updates on open roles, events, and talent news." FOLDED="true"/>
                  <node TEXT="Form" FOLDED="true">
                    <node TEXT="Email Address" FOLDED="true"/>
                    <node TEXT="Subscribe Button" FOLDED="true"/>
                  </node>
                </node>
                <node TEXT="Work with us" FOLDED="true">
                  <node TEXT="Clients" FOLDED="true">
                    <node TEXT="TALK TO US" FOLDED="true">
                      <node TEXT="Link: https://lionsandtigers.com/talk-to-us/" FOLDED="true"/>
                    </node>
                  </node>
                  <node TEXT="Talent" FOLDED="true">
                    <node TEXT="JOIN OUR TEAM" FOLDED="true">
                      <node TEXT="Link: https://lionsandtigers.com/join-our-team/" FOLDED="true"/>
                    </node>
                  </node>
                </node>
              <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_newsletter.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Media" FOLDED="true">
              <node TEXT="Media" LINK="https://lionsandtigers.com/media/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_media.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
              <node TEXT="Take me there" LINK="https://lionsandtigers.com/media/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_media.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
          <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_newsletter.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Page Content" FOLDED="true">
      <node TEXT="Hero Section" FOLDED="true">
        <node TEXT="Build Your Dream Team" FOLDED="true"/>
        <node TEXT="Description: Highly skilled marketing, comms, operations   change specialists waiting for you. Drive your business   your people forward – no compromises." FOLDED="true"/>
        <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Hero Image" FOLDED="true"/>
      </node>
      <node TEXT="Trusted By" FOLDED="true">
        <node TEXT="Logos: XBOX, ada developers academy, Alaska Airlines, GitHub, Microsoft, Minecraft, Tribute" FOLDED="true"/>
      </node>
      <node TEXT="Model Section" FOLDED="true">
        <node TEXT="Our model fits your needs   our people" FOLDED="true"/>
        <node TEXT="Description: We design the solutions that fit your needs – today   tomorrow." FOLDED="true"/>
        <node TEXT="Model Types" FOLDED="true">
          <node TEXT="Full-time   Fractional" FOLDED="true"/>
          <node TEXT="Individuals   Teams" FOLDED="true"/>
          <node TEXT="Time   Outcome Based" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="Client Testimonial" FOLDED="true">
        <node TEXT="A Word From Our Clients" FOLDED="true"/>
        <node TEXT="Testimonial Text: Lions   Tigers brings a talented team of experts, with skills and expertise specific to each project, program and team..." FOLDED="true"/>
        <node TEXT="DeAnna Paddleford, Change Management Strategy Lead" FOLDED="true"/>
      </node>
      <node TEXT="Culture   Belonging" FOLDED="true">
        <node TEXT="Want to build a culture of high performance   belonging?" FOLDED="true"/>
        <node TEXT="Description: We built a playbook for leaders who are thinking about workforce innovation and need a system for change..." FOLDED="true"/>
        <node TEXT="LEARN MORE Button" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Vision   Mission" FOLDED="true">
        <node TEXT="Vision: To unlock the full potential of the workforce." FOLDED="true"/>
        <node TEXT="Mission: We strengthen businesses with the power of the independent workforce by building blended, human-centered teams." FOLDED="true"/>
        <node TEXT="OUR STORY Button" LINK="https://lionsandtigers.com/our-story/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Team Image" FOLDED="true"/>
      </node>
      <node TEXT="Work with us" FOLDED="true">
        <node TEXT="Clients" FOLDED="true">
          <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Talent" FOLDED="true">
          <node TEXT="JOIN OUR TEAM Button" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
      </node>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="About Us" FOLDED="true">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="DEI" LINK="https://lionsandtigers.com/dei/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_dei.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Solutions" FOLDED="true">
        <node TEXT="Working Together" LINK="https://lionsandtigers.com/solutions/#working-together" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_working-together.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Engagement Model" LINK="https://lionsandtigers.com/solutions/#engagement-model" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_engagement-model.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_capabilities-skillsets.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions_client-stories.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Resources" FOLDED="true">
        <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_blog.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Media" LINK="https://lionsandtigers.com/media/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_media.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="General Inquiries" LINK="https://lionsandtigers.com/general-inquiries/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_general-inquiries.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Newsletter" FOLDED="true">
        <node TEXT="Description: Learn about our solutions, our success stories, best practices, and thought leadership." FOLDED="true"/>
        <node TEXT="Newsletter Signup Form" FOLDED="true">
          <node TEXT="Email (input field)" FOLDED="true"/>
        </node>
      </node>
      <node TEXT="Privacy Policy" LINK="https://lionsandtigers.com/privacy-policy/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_privacy-policy.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Social Media" FOLDED="true">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_company_lionsandtigers.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_twitter.com_lionstigersco.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.instagram.com_lionstigersco.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.youtube.com_lionstigersco.png" width="500" height="250"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
  </node>
</map>
