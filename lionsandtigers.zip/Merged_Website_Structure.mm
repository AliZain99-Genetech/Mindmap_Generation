<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Professional Workforce   Staffing Solutions - Lions   Tigers">
    <node TEXT="Header">
      <node TEXT="Logo" />
      <node TEXT="Navigation">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/">
          <node TEXT="The Power of   (introduction)">
            <node TEXT="Re-imagining Work   Life (section summary)" />
            <node TEXT="Video (main intro video)" />
          </node>
          <node TEXT="Vision   Mission">
            <node TEXT="Vision: Unlock the full potential of the workforce" />
            <node TEXT="Mission: Strengthen businesses by building blended, human-centered teams" />
          </node>
          <node TEXT="Our Values">
            <node TEXT="Community: Collective action for representation and economic access" />
            <node TEXT="Entrepreneurship: Ownership, highest   best use, outcomes over output" />
            <node TEXT="Stewardship: Service plus advocacy, invest to leave things better" />
            <node TEXT="Courage: Leadership through resilience, push boundaries" />
          </node>
          <node TEXT="Recent Recognition">
            <node TEXT="Awards and badges (visual row of recognitions)" />
          </node>
          <node TEXT="L T Talent Network">
            <node TEXT="Team   Community Photo Grid" />
          </node>
          <node TEXT="Staff Team">
            <node TEXT="Brea Starmer, Founder, CEO">
              <node TEXT="Bio">
                <node TEXT="brea-starmer" LINK="https://lionsandtigers.com/brea-starmer" />
              </node>
              <node TEXT="LinkedIn">
                <node TEXT="breastarmer" LINK="https://www.linkedin.com/in/breastarmer" />
              </node>
            </node>
            <node TEXT="Ashley Jude, President">
              <node TEXT="LinkedIn">
                <node TEXT="ashleyjude" LINK="https://www.linkedin.com/in/ashleyjude" />
              </node>
            </node>
            <node TEXT="Lorraine Cunningham, CTO   Financial Officer">
              <node TEXT="LinkedIn">
                <node TEXT="cunninghamlorraine" LINK="https://www.linkedin.com/in/cunninghamlorraine" />
              </node>
            </node>
            <node TEXT="LaShunte Portrey, Business Development">
              <node TEXT="LinkedIn">
                <node TEXT="lashunteportrey" LINK="https://www.linkedin.com/in/lashunteportrey/" />
              </node>
            </node>
            <node TEXT="Steven Rowe, Client Experience">
              <node TEXT="LinkedIn">
                <node TEXT="sttrowe" LINK="https://www.linkedin.com/in/sttrowe" />
              </node>
            </node>
            <node TEXT="Reiko Kono, Client Experience">
              <node TEXT="LinkedIn">
                <node TEXT="reiko-kono-161056171" LINK="https://www.linkedin.com/in/reiko-kono-161056171/" />
              </node>
            </node>
            <node TEXT="Shannon Lee, Client Experience Team">
              <node TEXT="LinkedIn">
                <node TEXT="shannon-lee13" LINK="https://www.linkedin.com/in/shannon-lee13/" />
              </node>
            </node>
            <node TEXT="Nan Jackson, Marketing">
              <node TEXT="LinkedIn">
                <node TEXT="nanbjackson" LINK="https://www.linkedin.com/in/nanbjackson" />
              </node>
            </node>
            <node TEXT="Miranda Leurquin, Talent Advocacy">
              <node TEXT="LinkedIn">
                <node TEXT="mirandaleurquin" LINK="https://www.linkedin.com/in/mirandaleurquin/" />
              </node>
            </node>
            <node TEXT="Jocylynn Kelley, Talent Advocacy">
              <node TEXT="LinkedIn">
                <node TEXT="jocylynn-kelley" LINK="https://www.linkedin.com/in/jocylynn-kelley/" />
              </node>
            </node>
            <node TEXT="Allison Monat, Talent Advocacy">
              <node TEXT="LinkedIn">
                <node TEXT="allisonsmonat" LINK="https://www.linkedin.com/in/allisonsmonat" />
              </node>
            </node>
            <node TEXT="Mercedes Dunn, Talent Advocacy">
              <node TEXT="LinkedIn">
                <node TEXT="mercedesdunn" LINK="https://www.linkedin.com/in/mercedesdunn/" />
              </node>
            </node>
          </node>
          <node TEXT="Work with us">
            <node TEXT="TALK TO US">
              <node TEXT="talk-to-us" LINK="https://lionsandtigers.com/talk-to-us/" />
              <node TEXT="Contact Introduction">
                <node TEXT="Consultant inquiry instructions" />
                <node TEXT="Team join interest">
                  <node TEXT="Learn more">
                    <node TEXT="here (Join Our Team)">
                      <node TEXT="join-our-team" LINK="https://lionsandtigers.com/join-our-team" />
                    </node>
                  </node>
                </node>
              </node>
              <node TEXT="Contact Form">
                <node TEXT="*First Name" />
                <node TEXT="*Last Name" />
                <node TEXT="*Title" />
                <node TEXT="*Organization" />
                <node TEXT="*Email" />
                <node TEXT="*Phone" />
                <node TEXT="*Message" />
                <node TEXT="Math Captcha" />
                <node TEXT="Submit Button" />
              </node>
            </node>
            <node TEXT="JOIN OUR TEAM">
              <node TEXT="join-our-team" LINK="https://lionsandtigers.com/join-our-team/" />
            </node>
          </node>
        </node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/">
          <node TEXT="Workforce Reimagined – Unlocking the Power of Blended Teams">
            <node TEXT="Summary: Traditional workforce models are failing; new research on blended teams" />
            <node TEXT="Read the Research Report">
              <node TEXT="Link" LINK="https://lionsandtigers.com/why-now/" />
            </node>
          </node>
          <node TEXT="The American workforce is at an inflection point">
            <node TEXT="Summary: Key statistics about women, freelancers, and the future workforce" />
          </node>
          <node TEXT="Why This Study">
            <node TEXT="Summary: The shift for leaders; study overview and goals" />
            <node TEXT="Brea Starmer">
              <node TEXT="Link" LINK="https://www.linkedin.com/in/breastarmer/" />
            </node>
          </node>
          <node TEXT="Expert Insight – Paul Estes Quote">
            <node TEXT="Summary: Leaders who prioritize flexibility and expertise will thrive" />
          </node>
          <node TEXT="The Data Is In: Blended Teams Work">
            <node TEXT="Summary: Data-driven benefits of blended teams, including speed, innovation, skills, and quality" />
          </node>
          <node TEXT="The Value Compounds Over Time">
            <node TEXT="Summary: Strategic advantage increases with longer tenure using blended teams" />
          </node>
          <node TEXT="Future Workforce Arc – Pam Cohen Quote">
            <node TEXT="Summary: Blended teams are now a fundamental part of work" />
          </node>
          <node TEXT="Why It Matters">
            <node TEXT="Summary: Blended teams support women, caregivers, and AI transitions" />
          </node>
          <node TEXT="The 2025 Blended Workforce Survey">
            <node TEXT="Summary: Research conducted by Read the Room Advisors; survey methodology and purpose" />
            <node TEXT="Download Full Survey Report">
              <node TEXT="Link" LINK="https://lionsandtigers.com/why-now/" />
            </node>
          </node>
        </node>
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/">
          <node TEXT="Built For Fortune 500s   Startups">
            <node TEXT="Powered by 100+ consultants, design the team   solutions you need now." />
          </node>
          <node TEXT="Working together">
            <node TEXT="Co-design workforce solutions aligned to your key outcomes." />
            <node TEXT="ROAR Methodology Results" />
          </node>
          <node TEXT="Engagement Model Built for You">
            <node TEXT="Full-time   Fractional" />
            <node TEXT="Individuals   Teams" />
            <node TEXT="Time   Outcome Based" />
          </node>
          <node TEXT="Capabilities   Skillsets">
            <node TEXT="Communications   Marketing" />
            <node TEXT="Operations" />
            <node TEXT="Change" />
          </node>
          <node TEXT="Client Stories">
            <node TEXT="To scale myself   level up my team" />
            <node TEXT="My team to feel safe   inclusive" />
            <node TEXT="Product insights   raving fans" />
            <node TEXT="Flexibility   less risk" />
            <node TEXT="A sprint staff   domain experts" />
          </node>
          <node TEXT="Work with us">
            <node TEXT="Clients">
              <node TEXT="TALK TO US">
                <node TEXT="talk-to-us" LINK="https://lionsandtigers.com/talk-to-us/" />
              </node>
            </node>
            <node TEXT="Talent">
              <node TEXT="JOIN OUR TEAM">
                <node TEXT="join-our-team" LINK="https://lionsandtigers.com/join-our-team/" />
              </node>
            </node>
          </node>
        </node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/">
          <node TEXT="Intro: Inclusive Community   Flexibility">
            <node TEXT="We are an inclusive community of marketing, comms, operations and change specialists who value high-impact work   flexibility." />
            <node TEXT="EXPLORE OPEN ROLES">
              <node TEXT="Link: EXPLORE OPEN ROLES" LINK="https://lionsandtigers.com/join-our-team/#open-roles" />
            </node>
          </node>
          <node TEXT="What it means to be a great place to work">
            <node TEXT="We are re-writing what it means to be a great place to work." />
            <node TEXT="Flexibility: Flexible roles, 5 to 40 hours a week" />
            <node TEXT="Community: Join a supportive team" />
            <node TEXT="Values: Community, impact, stewardship, courage" />
            <node TEXT="Resources   Growth: Workshops, resource library, support" />
            <node TEXT="Remote Work: Work from anywhere" />
            <node TEXT="Transparency: Meetings, channels, 1:1s, informed team" />
            <node TEXT="DEI: Multi-year anti-racist journey">
              <node TEXT="more" LINK="https://lionsandtigers.com/dei" />
            </node>
            <node TEXT="Fun: Family picnics, parties, happy hours" />
          </node>
          <node TEXT="Open Roles">
            <node TEXT="Open Jobs: Data Analyst, Events Manager, Communications Manager, Project Manager, Change Management, and open applications." />
            <node TEXT="CONSULTANT FAQ">
              <node TEXT="Link: CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/" />
            </node>
          </node>
          <node TEXT="Talent Newsletter">
            <node TEXT="Sign up for open roles and news" />
            <node TEXT="Form">
              <node TEXT="Field: Enter Your email address" />
              <node TEXT="SUBSCRIBE" />
            </node>
          </node>
          <node TEXT="Team Impact Stats">
            <node TEXT="97.5% consultant retention rate" />
            <node TEXT="$34M paid out to consultants" />
            <node TEXT="100% work fully remote or hybrid" />
            <node TEXT="87% women team members (self-identified)" />
          </node>
          <node TEXT="What Happens After You Apply">
            <node TEXT="1. Apply for a role via online application" />
            <node TEXT="2. Application reviewed by a real person" />
            <node TEXT="3. If a fit, contacted for an initial call" />
            <node TEXT="4. You will not be ghosted" />
            <node TEXT="CONSULTANT FAQ">
              <node TEXT="Link: CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/" />
            </node>
          </node>
          <node TEXT="From Our Team">
            <node TEXT="Testimonial: Ability to chart own path, flexibility, and personal reflection" />
          </node>
        </node>
        <node TEXT="Resources">
          <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/">
            <node TEXT="Avoiding the All-Or-Nothing Workplace: Introduction">
              <node TEXT="Enabling People to Operate at their Highest   Best Use" />
              <node TEXT="Brea Starmer, Founder/CEO" />
              <node TEXT="Download a pdf of the playbook">
                <node TEXT="here" LINK="https://lionsandtigers.com/playbook-download/" />
              </node>
              <node TEXT="Listen to the audio version">
                <node TEXT="audio version." LINK="https://player.captivate.fm/episode/ae64d6e2-5fb9-49fb-95e8-46d0a2433c68" />
              </node>
            </node>
            <node TEXT="Contents Overview">
              <node TEXT="Future Now of Work sections summary" />
              <node TEXT="Workplace Isn #39;t Working, The Great Resignation, HBU System, 3Ms, Community, Practical Advice - all summarized" />
            </node>
            <node TEXT="Workplace Transformation Story">
              <node TEXT="Personal layoff, freelance pivot, moms and work shift" />
              <node TEXT="since 75% of American women would go broke while taking 8 weeks of leave" LINK="https://www.fatherly.com/news/75-percent-of-moms-would-be-bankrupt-after-8-weeks-of-unpaid-leave" />
            </node>
            <node TEXT="Why must work be binary?">
              <node TEXT="Call for systemic work evolution, inclusion, and hybrid workplaces" />
            </node>
            <node TEXT="The Workplace Isn #39;t Working for Everyone">
              <node TEXT="Real-world example, lack of workplace flexibility and impact" />
            </node>
            <node TEXT="The “Great Resignation”   Losing Talent">
              <node TEXT="Major exodus, inclusion gaps, statistics on work departure" />
              <node TEXT="business leaders say they are highly committed" LINK="https://www.mckinsey.com/featured-insights/diversity-and-inclusion/women-in-the-workplace" />
              <node TEXT="30-year low." LINK="https://en.wikipedia.org/wiki/Labor_force_in_the_United_States#cite_note-45" />
              <node TEXT="employees age 30 to 45" LINK="https://www.superstaff.com/blog/top-20-great-resignation-statistics/" />
              <node TEXT="One-third" LINK="https://www.latimes.com/politics/story/2021-08-18/pandemic-pushes-moms-to-scale-back-or-quit-their-careers" />
              <node TEXT="disappeared from the workforce" LINK="https://www.fastcompany.com/90848858/women-of-color-are-leaving-the-workforce-and-vanishing-from-unemployment-statistics" />
              <node TEXT="black female labor participation" LINK="https://www.businessinsider.com/black-women-leaving-corporate-america-entreprenurship-startups-2022-12" />
              <node TEXT="Pew Research Center’s resignation findings" LINK="https://www.pewresearch.org/fact-tank/2022/03/09/majority-of-workers-who-quit-a-job-in-2021-cite-low-pay-no-opportunities-for-advancement-feeling-disrespected/" />
              <node TEXT="McKinsey" LINK="https://www.mckinsey.com/capabilities/people-and-organizational-performance/our-insights/great-attrition-or-great-attraction-the-choice-is-yours" />
              <node TEXT="70 million Americans" LINK="https://www.zippia.com/advice/how-many-freelancers-in-the-us/" />
              <node TEXT="Gallup survey" LINK="https://www.gallup.com/workplace/397751/returning-office-current-preferred-future-state-remote-work.aspx" />
              <node TEXT="research shows" LINK="https://www.vox.com/recode/23129752/work-from-home-productivity" />
              <node TEXT="HBR, BCG" LINK="https://www.hbs.edu/managing-the-future-of-work/Documents/Building_The_On_Demand_Workforce.pdf" />
              <node TEXT="recently polled" LINK="https://www.forbes.com/sites/tracybrower/2022/07/24/burnout-is-a-worldwide-problem-5-ways-work-must-change/?sh=1bbaf3a76c1e" />
            </node>
            <node TEXT="Blended Work Ecosystems   Sustainability">
              <node TEXT="Blended workforce value, agility, reduced costs, innovation" />
              <node TEXT="A.team" LINK="http://www.a.team/" />
              <node TEXT="MITSloan reference" />
              <node TEXT="Era of Sustainability: Measuring Impact Over Hours" />
            </node>
            <node TEXT="Highest   Best Use Operating System™">
              <node TEXT="System for business priorities, talent/task alignment, belonging" />
              <node TEXT="The 3Ms: Magnet, Momentum, Maximum" />
              <node TEXT="Applying the 3Ms to the work ecosystem" />
            </node>
            <node TEXT="Our Process of Establishing HBU">
              <node TEXT="First Step: Highest   Best Organization" />
              <node TEXT="Second Step: Highest   Best You" />
              <node TEXT="Third Step: Highest   Best Community" />
              <node TEXT="Stitching It All Together: Your Ecosystem is Unique" />
            </node>
            <node TEXT="Unlocking HBU: High-EQ Change Management">
              <node TEXT="TRUST model: Transparency, Relationships, Uproot, Sustainability, Tribute" />
              <node TEXT="Dr. Renee St. Jacques" LINK="https://www.reneestjacques.com/" />
            </node>
            <node TEXT="Blending Our Workforce: Natalie’s Example">
              <node TEXT="Fictional scenario of blended team leadership and implementation" />
            </node>
            <node TEXT="Building the Plane While You Fly It">
              <node TEXT="Adapting new work models in real time; guidance for change" />
              <node TEXT="Very Practical Advice for Proliferating HBU" />
              <node TEXT="How to Convince Your Boss or Peers You Need HBU" />
              <node TEXT="The P L Benefits of a Blended Workforce" />
              <node TEXT="Human Resources vs Procurement: Who Manages the Blended Workforce?" />
            </node>
            <node TEXT="A Few Things to Dream About">
              <node TEXT="Every Org Needs a 'Gig Economy'" />
              <node TEXT="FLEX network" LINK="https://www.webwire.com/ViewPressRel.asp?aId=242981" />
              <node TEXT="public version in the Netherlands" LINK="https://unileverfreelancers.talent-pool.com/" />
              <node TEXT="Josh Bersin highlights" LINK="https://joshbersin.com/2019/07/the-company-as-a-talent-network-unilever-and-schneider-electric-show-the-way/" />
              <node TEXT="Jon Younger recently published" LINK="https://www.forbes.com/sites/jonyounger/2022/12/01/six-ways-that-freelancers-will-improve-project-team-engagement-and-performance/?sh=45f3f32f1b81" />
              <node TEXT="Commitments to Diversity are Now Public" />
              <node TEXT="public commitment" LINK="https://docs.google.com/spreadsheets/d/11OBEAG8yQs3olTDDFwt6PoSy9Lqjk9cWslCc-H_ytyo/edit#gid=0" />
              <node TEXT="Measure Up initiative" LINK="https://www.prnewswire.com/news-releases/fortune-and-refinitiv-encourage-unprecedented-corporate-diversity-disclosure-and-accountability-through-new-measure-up-partnership-301159688.html" />
              <node TEXT="Diverse company lists like these" LINK="https://vervoe.com/most-diverse-companies/" />
              <node TEXT="inclusive approach to procurement" LINK="https://hbr.org/2020/08/why-you-need-a-supplier-diversity-program" />
              <node TEXT="Portable Benefits for Independent Workers" />
              <node TEXT="National Conference of State Legislators" LINK="https://www.ncsl.org/research/labor-and-employment/portable-benefits-for-gig-workers.aspx#:~:text=Policymakers%2C%20industry%20innovators%2C%20labor%20organizers,and%20drive%20broader%20economic%20prosperity." />
              <node TEXT="potential" LINK="https://www.aspeninstitute.org/publications/designing-portable-benefits/" />
              <node TEXT="Hybrid   Flex Work Permanence" />
              <node TEXT="According to Gallup" LINK="https://www.gallup.com/workplace/390632/future-hybrid-work-key-questions-answered-data.aspx" />
              <node TEXT="enable non-linear days" LINK="https://www.bbc.com/worklife/article/20220928-the-non-linear-workdays-changing-the-shape-of-productivity" />
              <node TEXT="flexible work policy examples" LINK="https://www.shrm.org/resourcesandtools/tools-and-samples/policies/pages/cms_000593.aspx#:~:text=Flextime%2C%20in%20which%20an%20employee,leave%20earlier%20in%20the%20afternoon." />
              <node TEXT="Mercer reports" LINK="https://www.mercer.us/content/dam/mercer/attachments/north-america/us/us-2022-inside-employees-minds-infographic.pdf?utm_source=marketo&amp;utm_medium=email&amp;utm_campaign=NSW1&amp;utm_term=rethinking-the-way-we-work-flexible-work-policies&amp;utm_content=newsletter&amp;utm_country=us&amp;adobe_mc=MCMID%3D28544653033654653390475691018962050474%7CMCORGID%3D7205F0F5559E57A87F000101%2540AdobeOrg%7CTS%3D1671228362" />
            </node>
            <node TEXT="In Conclusion">
              <node TEXT="Summary of call to action, rebuilding, access, inclusion, burnout prevention" />
            </node>
            <node TEXT="Where to from here?">
              <node TEXT="Download a pdf version" LINK="https://lionsandtigers.com/playbook-download/" />
              <node TEXT="Reach out to our team" LINK="https://lionsandtigers.com/talk-to-us/" />
              <node TEXT="here (Subscribe to newsletter)" LINK="https://lionsandtigers.com/newsletter/" />
              <node TEXT="Brea on LinkedIn" LINK="https://www.linkedin.com/in/breastarmer/" />
              <node TEXT="our blog" LINK="https://lionsandtigers.com/blog/" />
            </node>
          </node>
          <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/">
            <node TEXT="Courage at Work introduction">
              <node TEXT="Welcome message and overview" />
            </node>
            <node TEXT="Explore Blog Topics">
              <node TEXT="Thought Leadership   Best Practices">
                <node TEXT="thought leadership" LINK="https://lionsandtigers.com/category/thought-leadership/" />
                <node TEXT="best practices" LINK="https://lionsandtigers.com/category/best-practices/" />
              </node>
              <node TEXT="New   Noteworthy">
                <node TEXT="noteworthy" LINK="https://lionsandtigers.com/category/noteworthy/" />
                <node TEXT="new" LINK="https://lionsandtigers.com/category/new/" />
              </node>
              <node TEXT="People   Projects">
                <node TEXT="people" LINK="https://lionsandtigers.com/category/people/" />
              </node>
            </node>
            <node TEXT="Featured Blog Posts">
              <node TEXT="Workforce Reimagined Research Launch Event">
                <node TEXT="read more" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" />
                <node TEXT="Workforce Reimagined Research Launch Event" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" />
              </node>
              <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic">
                <node TEXT="read more" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" />
                <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" />
              </node>
              <node TEXT="Building Better Workplaces for Women">
                <node TEXT="read more" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" />
                <node TEXT="Building Better Workplaces for Women: 3 Power Moves to Help You Grow, Lead, and Thrive" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" />
              </node>
              <node TEXT="Elevating Culture   Community: Miranda Leurquin's New Chapter at L T">
                <node TEXT="read more" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" />
                <node TEXT="Elevating Culture   Community:  Miranda Leurquin’s New Chapter at L T" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" />
              </node>
              <node TEXT="Older Entries">
                <node TEXT="« Older Entries" LINK="https://lionsandtigers.com/blog/page/2/?et_blog" />
              </node>
            </node>
            <node TEXT="Newsletter Signup Form">
              <node TEXT="Email Input" />
              <node TEXT="SUBSCRIBE Button" />
              <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/">
                <node TEXT="Client Newsletter">
                  <node TEXT="Summary: Learn about solutions, stories, best practices, and leadership." />
                  <node TEXT="Form">
                    <node TEXT="Email Address" />
                    <node TEXT="Subscribe Button" />
                  </node>
                </node>
                <node TEXT="Talent Newsletter">
                  <node TEXT="Summary: Get updates on open roles, events, and talent news." />
                  <node TEXT="Form">
                    <node TEXT="Email Address" />
                    <node TEXT="Subscribe Button" />
                  </node>
                </node>
                <node TEXT="Work with us">
                  <node TEXT="Clients">
                    <node TEXT="TALK TO US">
                      <node TEXT="Link: https://lionsandtigers.com/talk-to-us/" />
                    </node>
                  </node>
                  <node TEXT="Talent">
                    <node TEXT="JOIN OUR TEAM">
                      <node TEXT="Link: https://lionsandtigers.com/join-our-team/" />
                    </node>
                  </node>
                </node>
              </node>
            </node>
            <node TEXT="Media">
              <node TEXT="Media" LINK="https://lionsandtigers.com/media/" />
              <node TEXT="Take me there" LINK="https://lionsandtigers.com/media/" />
            </node>
          </node>
          <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/" />
        </node>
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
      </node>
    </node>
    <node TEXT="Page Content">
      <node TEXT="Hero Section">
        <node TEXT="Build Your Dream Team" />
        <node TEXT="Description: Highly skilled marketing, comms, operations   change specialists waiting for you. Drive your business   your people forward – no compromises." />
        <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/" />
        <node TEXT="Hero Image" />
      </node>
      <node TEXT="Trusted By">
        <node TEXT="Logos: XBOX, ada developers academy, Alaska Airlines, GitHub, Microsoft, Minecraft, Tribute" />
      </node>
      <node TEXT="Model Section">
        <node TEXT="Our model fits your needs   our people" />
        <node TEXT="Description: We design the solutions that fit your needs – today   tomorrow." />
        <node TEXT="Model Types">
          <node TEXT="Full-time   Fractional" />
          <node TEXT="Individuals   Teams" />
          <node TEXT="Time   Outcome Based" />
        </node>
      </node>
      <node TEXT="Client Testimonial">
        <node TEXT="A Word From Our Clients" />
        <node TEXT="Testimonial Text: Lions   Tigers brings a talented team of experts, with skills and expertise specific to each project, program and team..." />
        <node TEXT="DeAnna Paddleford, Change Management Strategy Lead" />
      </node>
      <node TEXT="Culture   Belonging">
        <node TEXT="Want to build a culture of high performance   belonging?" />
        <node TEXT="Description: We built a playbook for leaders who are thinking about workforce innovation and need a system for change..." />
        <node TEXT="LEARN MORE Button" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
      </node>
      <node TEXT="Vision   Mission">
        <node TEXT="Vision: To unlock the full potential of the workforce." />
        <node TEXT="Mission: We strengthen businesses with the power of the independent workforce by building blended, human-centered teams." />
        <node TEXT="OUR STORY Button" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Team Image" />
      </node>
      <node TEXT="Work with us">
        <node TEXT="Clients">
          <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/" />
        </node>
        <node TEXT="Talent">
          <node TEXT="JOIN OUR TEAM Button" LINK="https://lionsandtigers.com/join-our-team/" />
        </node>
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="About Us">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" />
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" />
        <node TEXT="DEI" LINK="https://lionsandtigers.com/dei/" />
      </node>
      <node TEXT="Solutions">
        <node TEXT="Working Together" LINK="https://lionsandtigers.com/solutions/#working-together" />
        <node TEXT="Engagement Model" LINK="https://lionsandtigers.com/solutions/#engagement-model" />
        <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" />
        <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories" />
      </node>
      <node TEXT="Resources">
        <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
        <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" />
        <node TEXT="Media" LINK="https://lionsandtigers.com/media/" />
        <node TEXT="General Inquiries" LINK="https://lionsandtigers.com/general-inquiries/" />
      </node>
      <node TEXT="Newsletter">
        <node TEXT="Description: Learn about our solutions, our success stories, best practices, and thought leadership." />
        <node TEXT="Newsletter Signup Form">
          <node TEXT="Email (input field)" />
        </node>
      </node>
      <node TEXT="Privacy Policy" LINK="https://lionsandtigers.com/privacy-policy/" />
      <node TEXT="Social Media">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers" />
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco" />
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/" />
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco" />
      </node>
    </node>
  </node>
</map>