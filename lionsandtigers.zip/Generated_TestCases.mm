<map version="1.0.1">
<node TEXT="Test Cases" POSITION="left" FOLDED="true">

    <node TEXT="Our Story Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Our Story' link in the header navigates the user to the correct 'Our Story' page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The 'Our Story' page loads all main content sections, including company history and values." FOLDED="true" POSITION="left" />
            <node TEXT="3. All images and videos on the 'Our Story' page display correctly without broken links." FOLDED="true" POSITION="left" />
            <node TEXT="4. The 'Our Story' page is accessible from every page via the header navigation." FOLDED="true" POSITION="left" />
            <node TEXT="5. The 'Our Story' page displays the leadership team bios with working LinkedIn links." FOLDED="true" POSITION="left" />
            <node TEXT="6. The 'Our Story' page includes recent recognition and awards, and these are visible to the user." FOLDED="true" POSITION="left" />
            <node TEXT="7. The 'Our Story' page's navigation breadcrumbs accurately reflect the user's location." FOLDED="true" POSITION="left" />
            <node TEXT="8. The 'Our Story' page is responsive and displays correctly on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
            <node TEXT="9. The 'Our Story' page's internal links (e.g., to team bios) function as expected." FOLDED="true" POSITION="left" />
            <node TEXT="10. The 'Our Story' page loads within 3 seconds under normal network conditions." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempting to access the 'Our Story' page with an invalid URL returns a 404 error page." FOLDED="true" POSITION="left" />
            <node TEXT="2. If the 'Our Story' page is deleted from the server, the link in the header does not break the site." FOLDED="true" POSITION="left" />
            <node TEXT="3. If images on the 'Our Story' page are missing, the page displays appropriate placeholders or alt text." FOLDED="true" POSITION="left" />
            <node TEXT="4. If the user is not authenticated (if required), the 'Our Story' page still loads as a public page." FOLDED="true" POSITION="left" />
            <node TEXT="5. If JavaScript is disabled, the main content of the 'Our Story' page remains accessible." FOLDED="true" POSITION="left" />
            <node TEXT="6. If the 'Our Story' page fails to load due to a server error, an error message is displayed to the user." FOLDED="true" POSITION="left" />
            <node TEXT="7. If the user clicks the 'Our Story' link multiple times rapidly, only one page load occurs." FOLDED="true" POSITION="left" />
            <node TEXT="8. If the 'Our Story' page is accessed with a slow network, a loading indicator is shown." FOLDED="true" POSITION="left" />
            <node TEXT="9. If the user tries to access a restricted section from 'Our Story', access is denied appropriately." FOLDED="true" POSITION="left" />
            <node TEXT="10. If the 'Our Story' page is accessed in a language not supported, the default language is shown." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The 'Our Story' page meets WCAG 2.1 AA accessibility standards." FOLDED="true" POSITION="left" />
            <node TEXT="2. The 'Our Story' page loads in under 2 seconds on a broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="3. The 'Our Story' page is fully responsive across all major browsers and devices." FOLDED="true" POSITION="left" />
            <node TEXT="4. The 'Our Story' page's images are optimized for fast loading without loss of quality." FOLDED="true" POSITION="left" />
            <node TEXT="5. The 'Our Story' page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
            <node TEXT="6. The 'Our Story' page is crawlable and indexable by search engines." FOLDED="true" POSITION="left" />
            <node TEXT="7. The 'Our Story' page does not leak any sensitive information in the page source." FOLDED="true" POSITION="left" />
            <node TEXT="8. The 'Our Story' page supports screen readers and keyboard navigation." FOLDED="true" POSITION="left" />
            <node TEXT="9. The 'Our Story' page maintains layout integrity when zoomed to 200%." FOLDED="true" POSITION="left" />
            <node TEXT="10. The 'Our Story' page does not trigger any browser security warnings." FOLDED="true" POSITION="left" />
        </node>
    </node>

    <node TEXT="Why Now Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Why Now' link in the header navigates the user to the 'Why Now' page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The 'Why Now' page displays the research report and key statistics sections." FOLDED="true" POSITION="left" />
            <node TEXT="3. The 'Why Now' page's download links for reports function and trigger downloads." FOLDED="true" POSITION="left" />
            <node TEXT="4. All infographics and images on the 'Why Now' page load correctly." FOLDED="true" POSITION="left" />
            <node TEXT="5. The 'Why Now' page's internal navigation (e.g., to survey results) works as expected." FOLDED="true" POSITION="left" />
            <node TEXT="6. The 'Why Now' page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
            <node TEXT="7. The 'Why Now' page's expert quotes and data are visible and formatted properly." FOLDED="true" POSITION="left" />
            <node TEXT="8. The 'Why Now' page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
            <node TEXT="9. The 'Why Now' page's external links (e.g., to LinkedIn) open in a new tab." FOLDED="true" POSITION="left" />
            <node TEXT="10. The 'Why Now' page loads without JavaScript errors in the browser console." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempting to access the 'Why Now' page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
            <node TEXT="2. If the research report file is missing, the download link displays an error message." FOLDED="true" POSITION="left" />
            <node TEXT="3. If images on the 'Why Now' page fail to load, alt text is displayed." FOLDED="true" POSITION="left" />
            <node TEXT="4. If the user is not authenticated (if required), the 'Why Now' page remains accessible." FOLDED="true" POSITION="left" />
            <node TEXT="5. If the 'Why Now' page is accessed with JavaScript disabled, main content is still visible." FOLDED="true" POSITION="left" />
            <node TEXT="6. If the 'Why Now' page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
            <node TEXT="7. If the user clicks the 'Why Now' link multiple times quickly, only one navigation occurs." FOLDED="true" POSITION="left" />
            <node TEXT="8. If the 'Why Now' page is accessed with a slow network, a loading spinner is shown." FOLDED="true" POSITION="left" />
            <node TEXT="9. If the user tries to download a corrupted report, an error is displayed." FOLDED="true" POSITION="left" />
            <node TEXT="10. If the 'Why Now' page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The 'Why Now' page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="2. The 'Why Now' page loads in under 2.5 seconds on a broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="3. The 'Why Now' page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
            <node TEXT="4. The 'Why Now' page's downloadable files are under 5MB for quick access." FOLDED="true" POSITION="left" />
            <node TEXT="5. The 'Why Now' page's text and graphics are clear at 200% zoom." FOLDED="true" POSITION="left" />
            <node TEXT="6. The 'Why Now' page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
            <node TEXT="7. The 'Why Now' page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
            <node TEXT="8. The 'Why Now' page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
            <node TEXT="9. The 'Why Now' page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
            <node TEXT="10. The 'Why Now' page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
        </node>
    </node>

    <node TEXT="Solutions Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Solutions' link in the header navigates the user to the 'Solutions' page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The 'Solutions' page displays all solution offerings and engagement models." FOLDED="true" POSITION="left" />
            <node TEXT="3. The 'Solutions' page's internal anchor links (e.g., to client stories) work correctly." FOLDED="true" POSITION="left" />
            <node TEXT="4. All images and case studies on the 'Solutions' page load without errors." FOLDED="true" POSITION="left" />
            <node TEXT="5. The 'Solutions' page's contact buttons (e.g., 'Talk to Us') function as expected." FOLDED="true" POSITION="left" />
            <node TEXT="6. The 'Solutions' page is accessible from every other page via the header." FOLDED="true" POSITION="left" />
            <node TEXT="7. The 'Solutions' page's downloadable resources are available and trigger downloads." FOLDED="true" POSITION="left" />
            <node TEXT="8. The 'Solutions' page is responsive and displays correctly on all device sizes." FOLDED="true" POSITION="left" />
            <node TEXT="9. The 'Solutions' page's team and skillset sections are visible and formatted properly." FOLDED="true" POSITION="left" />
            <node TEXT="10. The 'Solutions' page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempting to access the 'Solutions' page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
            <node TEXT="2. If a downloadable resource is missing, the download link displays an error message." FOLDED="true" POSITION="left" />
            <node TEXT="3. If images on the 'Solutions' page fail to load, alt text is displayed." FOLDED="true" POSITION="left" />
            <node TEXT="4. If the user is not authenticated (if required), the 'Solutions' page remains accessible." FOLDED="true" POSITION="left" />
            <node TEXT="5. If JavaScript is disabled, the main content of the 'Solutions' page is still accessible." FOLDED="true" POSITION="left" />
            <node TEXT="6. If the 'Solutions' page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
            <node TEXT="7. If the user clicks the 'Solutions' link multiple times rapidly, only one navigation occurs." FOLDED="true" POSITION="left" />
            <node TEXT="8. If the 'Solutions' page is accessed with a slow network, a loading indicator is shown." FOLDED="true" POSITION="left" />
            <node TEXT="9. If the user tries to access a restricted section from 'Solutions', access is denied." FOLDED="true" POSITION="left" />
            <node TEXT="10. If the 'Solutions' page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The 'Solutions' page meets WCAG 2.1 AA accessibility standards." FOLDED="true" POSITION="left" />
            <node TEXT="2. The 'Solutions' page loads in under 2.5 seconds on a broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="3. The 'Solutions' page is fully responsive across all major browsers and devices." FOLDED="true" POSITION="left" />
            <node TEXT="4. The 'Solutions' page's images are optimized for fast loading." FOLDED="true" POSITION="left" />
            <node TEXT="5. The 'Solutions' page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
            <node TEXT="6. The 'Solutions' page is crawlable and indexable by search engines." FOLDED="true" POSITION="left" />
            <node TEXT="7. The 'Solutions' page does not leak sensitive information in the page source." FOLDED="true" POSITION="left" />
            <node TEXT="8. The 'Solutions' page supports screen readers and keyboard navigation." FOLDED="true" POSITION="left" />
            <node TEXT="9. The 'Solutions' page maintains layout integrity when zoomed to 200%." FOLDED="true" POSITION="left" />
            <node TEXT="10. The 'Solutions' page does not trigger any browser security warnings." FOLDED="true" POSITION="left" />
        </node>
    </node>

    <node TEXT="Join Our Team Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Join Our Team' link in the header navigates the user to the 'Join Our Team' page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The 'Join Our Team' page displays open roles and job listings." FOLDED="true" POSITION="left" />
            <node TEXT="3. The 'Join Our Team' page's application form is visible and can be submitted successfully." FOLDED="true" POSITION="left" />
            <node TEXT="4. The 'Join Our Team' page's newsletter subscription form accepts valid email addresses." FOLDED="true" POSITION="left" />
            <node TEXT="5. The 'Join Our Team' page's DEI information is accessible via provided links." FOLDED="true" POSITION="left" />
            <node TEXT="6. The 'Join Our Team' page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
            <node TEXT="7. The 'Join Our Team' page's testimonials and team highlights are visible." FOLDED="true" POSITION="left" />
            <node TEXT="8. The 'Join Our Team' page is responsive and displays correctly on all devices." FOLDED="true" POSITION="left" />
            <node TEXT="9. The 'Join Our Team' page's FAQ section is accessible and displays answers." FOLDED="true" POSITION="left" />
            <node TEXT="10. The 'Join Our Team' page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempting to access the 'Join Our Team' page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
            <node TEXT="2. Submitting the application form with missing required fields displays validation errors." FOLDED="true" POSITION="left" />
            <node TEXT="3. Submitting the newsletter form with an invalid email address shows an error message." FOLDED="true" POSITION="left" />
            <node TEXT="4. If job listings fail to load, an appropriate error message is displayed." FOLDED="true" POSITION="left" />
            <node TEXT="5. If the user is not authenticated (if required), the 'Join Our Team' page remains accessible." FOLDED="true" POSITION="left" />
            <node TEXT="6. If JavaScript is disabled, the main content and forms are still accessible." FOLDED="true" POSITION="left" />
            <node TEXT="7. If the 'Join Our Team' page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
            <node TEXT="8. If the user clicks the 'Join Our Team' link multiple times rapidly, only one navigation occurs." FOLDED="true" POSITION="left" />
            <node TEXT="9. If the user tries to access a restricted section from 'Join Our Team', access is denied." FOLDED="true" POSITION="left" />
            <node TEXT="10. If the 'Join Our Team' page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The 'Join Our Team' page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="2. The 'Join Our Team' page loads in under 2.5 seconds on a broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="3. The 'Join Our Team' page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
            <node TEXT="4. The 'Join Our Team' page's images and graphics are optimized for fast loading." FOLDED="true" POSITION="left" />
            <node TEXT="5. The 'Join Our Team' page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
            <node TEXT="6. The 'Join Our Team' page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
            <node TEXT="7. The 'Join Our Team' page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
            <node TEXT="8. The 'Join Our Team' page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
            <node TEXT="9. The 'Join Our Team' page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
            <node TEXT="10. The 'Join Our Team' page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
        </node>
    </node>

    <node TEXT="Hybrid Workplace Playbook Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Hybrid Workplace Playbook' link in the header navigates the user to the playbook page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The playbook page displays the main content, including the playbook summary and sections." FOLDED="true" POSITION="left" />
            <node TEXT="3. The playbook page's download link for the PDF functions and triggers a file download." FOLDED="true" POSITION="left" />
            <node TEXT="4. The playbook page's audio version link opens and plays the audio content." FOLDED="true" POSITION="left" />
            <node TEXT="5. All images and infographics on the playbook page load correctly." FOLDED="true" POSITION="left" />
            <node TEXT="6. The playbook page's internal navigation (e.g., to sections) works as expected." FOLDED="true" POSITION="left" />
            <node TEXT="7. The playbook page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
            <node TEXT="8. The playbook page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
            <node TEXT="9. The playbook page's external links (e.g., to research) open in a new tab." FOLDED="true" POSITION="left" />
            <node TEXT="10. The playbook page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempting to access the playbook page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
            <node TEXT="2. If the playbook PDF is missing, the download link displays an error message." FOLDED="true" POSITION="left" />
            <node TEXT="3. If the audio version fails to load, an error message is displayed." FOLDED="true" POSITION="left" />
            <node TEXT="4. If images on the playbook page fail to load, alt text is displayed." FOLDED="true" POSITION="left" />
            <node TEXT="5. If the user is not authenticated (if required), the playbook page remains accessible." FOLDED="true" POSITION="left" />
            <node TEXT="6. If JavaScript is disabled, the main content of the playbook page is still accessible." FOLDED="true" POSITION="left" />
            <node TEXT="7. If the playbook page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
            <node TEXT="8. If the user clicks the playbook link multiple times rapidly, only one navigation occurs." FOLDED="true" POSITION="left" />
            <node TEXT="9. If the user tries to download a corrupted PDF, an error is displayed." FOLDED="true" POSITION="left" />
            <node TEXT="10. If the playbook page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The playbook page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="2. The playbook page loads in under 2.5 seconds on a broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="3. The playbook page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
            <node TEXT="4. The playbook PDF is under 10MB for quick download." FOLDED="true" POSITION="left" />
            <node TEXT="5. The playbook page's text and graphics are clear at 200% zoom." FOLDED="true" POSITION="left" />
            <node TEXT="6. The playbook page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
            <node TEXT="7. The playbook page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
            <node TEXT="8. The playbook page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
            <node TEXT="9. The playbook page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
            <node TEXT="10. The playbook page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
        </node>
    </node>

    <node TEXT="Blog Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Blog' link in the header navigates the user to the main blog page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The blog page displays a list of recent blog posts with titles and summaries." FOLDED="true" POSITION="left" />
            <node TEXT="3. Clicking a blog post title navigates the user to the full post." FOLDED="true" POSITION="left" />
            <node TEXT="4. The blog page's category filters work and display relevant posts." FOLDED="true" POSITION="left" />
            <node TEXT="5. The blog page's pagination controls allow navigation to older and newer posts." FOLDED="true" POSITION="left" />
            <node TEXT="6. The blog page's images and featured images load correctly." FOLDED="true" POSITION="left" />
            <node TEXT="7. The blog page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
            <node TEXT="8. The blog page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
            <node TEXT="9. The blog page's newsletter signup form is visible and accepts valid emails." FOLDED="true" POSITION="left" />
            <node TEXT="10. The blog page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempting to access the blog page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
            <node TEXT="2. If a blog post is deleted, its link returns a 404 error page." FOLDED="true" POSITION="left" />
            <node TEXT="3. If images on the blog page fail to load, alt text is displayed." FOLDED="true" POSITION="left" />
            <node TEXT="4. If the user is not authenticated (if required), the blog page remains accessible." FOLDED="true" POSITION="left" />
            <node TEXT="5. If JavaScript is disabled, the main content and posts are still accessible." FOLDED="true" POSITION="left" />
            <node TEXT="6. If the blog page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
            <node TEXT="7. If the user clicks the 'Blog' link multiple times rapidly, only one navigation occurs." FOLDED="true" POSITION="left" />
            <node TEXT="8. If the user submits an invalid email in the newsletter form, an error is shown." FOLDED="true" POSITION="left" />
            <node TEXT="9. If the blog page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
            <node TEXT="10. If a category filter returns no posts, a 'no posts found' message is displayed." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The blog page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="2. The blog page loads in under 2.5 seconds on a broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="3. The blog page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
            <node TEXT="4. The blog page's images are optimized for fast loading." FOLDED="true" POSITION="left" />
            <node TEXT="5. The blog page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
            <node TEXT="6. The blog page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
            <node TEXT="7. The blog page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
            <node TEXT="8. The blog page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
            <node TEXT="9. The blog page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
            <node TEXT="10. The blog page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
        </node>
    </node>

    <node TEXT="Newsletter Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Newsletter' link in the header navigates the user to the newsletter signup page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The newsletter page displays a form with an email input and subscribe button." FOLDED="true" POSITION="left" />
            <node TEXT="3. Submitting a valid email address subscribes the user to the newsletter." FOLDED="true" POSITION="left" />
            <node TEXT="4. The newsletter page displays confirmation after successful subscription." FOLDED="true" POSITION="left" />
            <node TEXT="5. The newsletter page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
            <node TEXT="6. The newsletter page's description and benefits are visible to the user." FOLDED="true" POSITION="left" />
            <node TEXT="7. The newsletter page's form prevents duplicate subscriptions with the same email." FOLDED="true" POSITION="left" />
            <node TEXT="8. The newsletter page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
            <node TEXT="9. The newsletter page's privacy policy link is visible and functional." FOLDED="true" POSITION="left" />
            <node TEXT="10. The newsletter page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempting to access the newsletter page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
            <node TEXT="2. Submitting the form with an invalid email address displays a validation error." FOLDED="true" POSITION="left" />
            <node TEXT="3. Submitting the form with an empty email field displays a required field error." FOLDED="true" POSITION="left" />
            <node TEXT="4. If the subscription service is down, an error message is shown to the user." FOLDED="true" POSITION="left" />
            <node TEXT="5. If the user is not authenticated (if required), the newsletter page remains accessible." FOLDED="true" POSITION="left" />
            <node TEXT="6. If JavaScript is disabled, the main content and form are still accessible." FOLDED="true" POSITION="left" />
            <node TEXT="7. If the newsletter page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
            <node TEXT="8. If the user clicks the subscribe button multiple times rapidly, only one subscription occurs." FOLDED="true" POSITION="left" />
            <node TEXT="9. If the newsletter page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
            <node TEXT="10. If the user tries to subscribe with a blacklisted email, an error is displayed." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The newsletter page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="2. The newsletter page loads in under 2 seconds on a broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="3. The newsletter page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
            <node TEXT="4. The newsletter page's form is protected against spam and bots." FOLDED="true" POSITION="left" />
            <node TEXT="5. The newsletter page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
            <node TEXT="6. The newsletter page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
            <node TEXT="7. The newsletter page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
            <node TEXT="8. The newsletter page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
            <node TEXT="9. The newsletter page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
            <node TEXT="10. The newsletter page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
        </node>
    </node>

    <node TEXT="TALK TO US Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'TALK TO US' link in the header navigates the user to the contact page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The contact page displays a form with all required fields (name, email, message, etc.)." FOLDED="true" POSITION="left" />
            <node TEXT="3. Submitting the contact form with valid data sends the inquiry successfully." FOLDED="true" POSITION="left" />
            <node TEXT="4. The contact page displays a confirmation message after successful submission." FOLDED="true" POSITION="left" />
            <node TEXT="5. The contact page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
            <node TEXT="6. The contact page's captcha field validates correct answers before submission." FOLDED="true" POSITION="left" />
            <node TEXT="7. The contact page's phone and email fields accept valid formats only." FOLDED="true" POSITION="left" />
            <node TEXT="8. The contact page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
            <node TEXT="9. The contact page's links to other resources (e.g., Join Our Team) are functional." FOLDED="true" POSITION="left" />
            <node TEXT="10. The contact page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempting to access the contact page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
            <node TEXT="2. Submitting the form with missing required fields displays validation errors." FOLDED="true" POSITION="left" />
            <node TEXT="3. Submitting the form with an invalid email address shows an error message." FOLDED="true" POSITION="left" />
            <node TEXT="4. Submitting the form with an incorrect captcha answer prevents submission." FOLDED="true" POSITION="left" />
            <node TEXT="5. If the contact service is down, an error message is shown to the user." FOLDED="true" POSITION="left" />
            <node TEXT="6. If JavaScript is disabled, the main content and form are still accessible." FOLDED="true" POSITION="left" />
            <node TEXT="7. If the contact page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
            <node TEXT="8. If the user clicks the submit button multiple times rapidly, only one submission occurs." FOLDED="true" POSITION="left" />
            <node TEXT="9. If the contact page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
            <node TEXT="10. If the user tries to submit a message with a blacklisted word, an error is displayed." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The contact page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="2. The contact page loads in under 2 seconds on a broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="3. The contact page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
            <node TEXT="4. The contact form is protected against spam and automated submissions." FOLDED="true" POSITION="left" />
            <node TEXT="5. The contact page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
            <node TEXT="6. The contact page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
            <node TEXT="7. The contact page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
            <node TEXT="8. The contact page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
            <node TEXT="9. The contact page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
            <node TEXT="10. The contact page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
        </node>
    </node>

    <node TEXT="Home Page Test Cases" POSITION="left" FOLDED="true">
        <node TEXT="Positive Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Clicking the 'Home Page' link in the header navigates the user to the main landing page." FOLDED="true" POSITION="left" />
            <node TEXT="2. The home page displays the hero section with headline, description, and call-to-action buttons." FOLDED="true" POSITION="left" />
            <node TEXT="3. The home page's 'TALK TO US' and 'JOIN OUR TEAM' buttons navigate to the correct pages." FOLDED="true" POSITION="left" />
            <node TEXT="4. The home page displays client logos in the 'Trusted By' section." FOLDED="true" POSITION="left" />
            <node TEXT="5. The home page's testimonial section displays client quotes and names." FOLDED="true" POSITION="left" />
            <node TEXT="6. The home page's navigation menu is visible and functional." FOLDED="true" POSITION="left" />
            <node TEXT="7. The home page is accessible from all other pages via the header." FOLDED="true" POSITION="left" />
            <node TEXT="8. The home page is responsive and displays correctly on all device types." FOLDED="true" POSITION="left" />
            <node TEXT="9. The home page's images and graphics load without errors." FOLDED="true" POSITION="left" />
            <node TEXT="10. The home page loads without JavaScript or console errors." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Negative Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. Attempting to access the home page with an invalid URL returns a 404 error." FOLDED="true" POSITION="left" />
            <node TEXT="2. If images on the home page fail to load, alt text is displayed." FOLDED="true" POSITION="left" />
            <node TEXT="3. If the user is not authenticated (if required), the home page remains accessible." FOLDED="true" POSITION="left" />
            <node TEXT="4. If JavaScript is disabled, the main content and navigation are still accessible." FOLDED="true" POSITION="left" />
            <node TEXT="5. If the home page fails to load due to a server error, an error message is shown." FOLDED="true" POSITION="left" />
            <node TEXT="6. If the user clicks the 'Home Page' link multiple times rapidly, only one navigation occurs." FOLDED="true" POSITION="left" />
            <node TEXT="7. If the home page is accessed in an unsupported language, the default language is shown." FOLDED="true" POSITION="left" />
            <node TEXT="8. If a call-to-action button is broken, an error message is displayed." FOLDED="true" POSITION="left" />
            <node TEXT="9. If the home page's testimonial section fails to load, a placeholder is shown." FOLDED="true" POSITION="left" />
            <node TEXT="10. If the home page's navigation menu fails to render, a fallback menu is displayed." FOLDED="true" POSITION="left" />
        </node>
        <node TEXT="Non-Functional" POSITION="left" FOLDED="true">
            <node TEXT="1. The home page meets accessibility standards for screen readers." FOLDED="true" POSITION="left" />
            <node TEXT="2. The home page loads in under 2 seconds on a broadband connection." FOLDED="true" POSITION="left" />
            <node TEXT="3. The home page is fully responsive on desktop, tablet, and mobile devices." FOLDED="true" POSITION="left" />
            <node TEXT="4. The home page's images are optimized for fast loading." FOLDED="true" POSITION="left" />
            <node TEXT="5. The home page's text is readable with sufficient color contrast." FOLDED="true" POSITION="left" />
            <node TEXT="6. The home page is SEO optimized for relevant keywords." FOLDED="true" POSITION="left" />
            <node TEXT="7. The home page does not expose sensitive data in the source code." FOLDED="true" POSITION="left" />
            <node TEXT="8. The home page supports keyboard navigation for all interactive elements." FOLDED="true" POSITION="left" />
            <node TEXT="9. The home page maintains layout integrity across all major browsers." FOLDED="true" POSITION="left" />
            <node TEXT="10. The home page does not trigger browser security or mixed content warnings." FOLDED="true" POSITION="left" />
        </node>
    </node>

</node>
</map>