<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Professional Workforce   Staffing Solutions - Lions   Tigers">
    <node TEXT="Header">
      <node TEXT="Logo" />
      <node TEXT="Navigation">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/">
          <node TEXT="The Power of   / Part-time   Impact">
            <node TEXT="Summary">Company founded to fulfill more of what we want by asking 'Why not amp;?'</node>
          </node>
          <node TEXT="How it all started: Re-imagining Work   Life">
            <node TEXT="Summary">Story of company origins and mission to create new conditions for work and life fulfillment</node>
            <node TEXT="Play Video" />
          </node>
          <node TEXT="Vision   Mission">
            <node TEXT="Vision">To unlock the full potential of the workforce.</node>
            <node TEXT="Mission">We strengthen businesses with independent workforce by building blended, human-centered teams.</node>
          </node>
          <node TEXT="Our Values">
            <node TEXT="Community">Collective action to uplift and prioritize economic access amp; representation.</node>
            <node TEXT="Impact">Care deeply, measure success in outcomes not output, ownership of showing up.</node>
            <node TEXT="Stewardship">Service plus advocacy, responsibility for client amp; company investments, leave all better than found.</node>
            <node TEXT="Courage">Resilience and boldness, lead with action and empathy, push boundaries for what is possible.</node>
          </node>
          <node TEXT="Recent Recognition">
            <node TEXT="Summary">Awards and industry recognition displayed in logos.</node>
          </node>
          <node TEXT="L T Talent Network">
            <node TEXT="Summary">Mosaic/collage of people illustrating the breadth of the network.</node>
          </node>
          <node TEXT="Staff Team">
            <node TEXT="Brea Starmer | Founder, CEO">
              <node TEXT="Bio" LINK="https://lionsandtigers.com/brea-starmer" />
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/breastarmer" />
            </node>
            <node TEXT="Ashley Jude | President">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/ashleyjude" />
            </node>
            <node TEXT="Lorraine Cunningham | Chief Technology   Financial Officer">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/cunninghamlorraine" />
            </node>
            <node TEXT="LaShunte Portrey | Business Development">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/lashunteportrey/" />
            </node>
            <node TEXT="Steven Rowe | Client Experience">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/sttrowe" />
            </node>
            <node TEXT="Reiko Kono | Client Experience">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/reiko-kono-161056171/" />
            </node>
            <node TEXT="Shannon Lee | Client Experience Team">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/shannon-lee13/" />
            </node>
            <node TEXT="Nan Jackson | Marketing">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/nanbjackson" />
            </node>
            <node TEXT="Miranda Leurquin | Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mirandaleurquin/" />
            </node>
            <node TEXT="Jocylynn Kelley | Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/jocylynn-kelley/" />
            </node>
            <node TEXT="Allison Monat | Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/allisonsmonat" />
            </node>
            <node TEXT="Mercedes Dunn | Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mercedesdunn/" />
            </node>
          </node>
          <node TEXT="For Clients and Talent">
            <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/">
              <node TEXT="Contact Us Section">
                <node TEXT="Intro: Hire our consultants or join our team" />
                <node TEXT="Learn more about joining our team">
                  <node TEXT="here" LINK="https://lionsandtigers.com/join-our-team" />
                </node>
              </node>
              <node TEXT="Contact Form">
                <node TEXT="First Name" />
                <node TEXT="Last Name" />
                <node TEXT="Title" />
                <node TEXT="Organization" />
                <node TEXT="Email" />
                <node TEXT="Phone" />
                <node TEXT="Message" />
                <node TEXT="Captcha: 10 + 10 =" />
                <node TEXT="Submit" />
              </node>
            </node>
            <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" />
          </node>
        </node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/">
          <node TEXT="Workforce Reimagined - Unlocking the Power of Blended Teams">
            <node TEXT="Read the Research Report">
              <node TEXT="Link: Read the Research Report" LINK="https://lionsandtigers.com/why-now/" />
            </node>
          </node>
          <node TEXT="Inflection Point - The American workforce is at a turning point">
            <node TEXT="Key Data Points and Trends Summary" />
          </node>
          <node TEXT="Why This Study - The need for data on blended teams">
            <node TEXT="Brea Starmer" />
          </node>
          <node TEXT="Expert Insight Quote">
            <node TEXT="Paul Estes on future work flexibility" />
          </node>
          <node TEXT="Blended Teams Work - Results   Benefits">
            <node TEXT="Competitive Edge, Quality, Speed" />
          </node>
          <node TEXT="The Value Compounds Over Time" />
          <node TEXT="Research Findings Quote">
            <node TEXT="Pam Cohen - blended teams as future work" />
          </node>
          <node TEXT="Why It Matters - Blended teams are a lifeline for workforce change" />
          <node TEXT="The 2025 Blended Workforce Survey">
            <node TEXT="Download Full Survey Report">
              <node TEXT="Link: Download Full Survey Report" LINK="https://lionsandtigers.com/why-now/" />
            </node>
          </node>
        </node>
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/">
          <node TEXT="Built For Fortune 500s   Startups">
            <node TEXT="Powered by 100+ consultants, building custom solutions aligned to client outcomes" />
          </node>
          <node TEXT="Working together">
            <node TEXT="Co-designing workforce solutions with ROAR methodology" />
            <node TEXT="ROAR Results">
              <node TEXT="Results: Start with business impact and results, go beyond the project ask" />
            </node>
          </node>
          <node TEXT="Engagement Model Built for YOU">
            <node TEXT="Our talent is available through:" />
            <node TEXT="Full-time   Fractional" />
            <node TEXT="Individuals   Teams" />
            <node TEXT="Time   Outcome Based" />
          </node>
          <node TEXT="Capabilities   Skillsets">
            <node TEXT="Communications   Marketing" />
            <node TEXT="Operations" />
            <node TEXT="Change" />
          </node>
          <node TEXT="Client Stories">
            <node TEXT="Solving clients' challenges using flexible teams" />
            <node TEXT="Read more about our Case Studies">
              <node TEXT="Case Studies">
                <node TEXT="Link" LINK="https://lionsandtigers.com/solutions/#client-stories" />
              </node>
            </node>
          </node>
          <node TEXT="Work with us">
            <node TEXT="Clients">
              <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
            </node>
            <node TEXT="Talent">
              <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" />
            </node>
          </node>
        </node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/">
          <node TEXT="Page Introduction   Explore Open Roles">
            <node TEXT="Short summary: Inclusive community of marketing, comms, operations and change specialists, with a focus on high-impact work   flexibility." />
            <node TEXT="EXPLORE OPEN ROLES">
              <node TEXT="https://lionsandtigers.com/join-our-team/#open-roles" />
            </node>
          </node>
          <node TEXT="What it means to be a great place to work">
            <node TEXT="Summary: Focus on flexible roles, passions, family, and organizational values. Conscious effort to put people first." />
            <node TEXT="Flexibility">
              <node TEXT="Great talent for any number of hours per week." />
            </node>
            <node TEXT="Community">
              <node TEXT="Join, hands down, some of the best people we've ever worked with." />
            </node>
            <node TEXT="Values">
              <node TEXT="Community, impact, stewardship, courage; attracting aligned talent and clients." />
            </node>
            <node TEXT="Resources   Growth">
              <node TEXT="Workshops, best practices, contractor support, and more." />
            </node>
            <node TEXT="Remote Work">
              <node TEXT="Primarily remote company; work from home or favorite space." />
            </node>
            <node TEXT="Transparency">
              <node TEXT="Team meetings, slack channels, 1:1s to stay connected." />
            </node>
            <node TEXT="More">
              <node TEXT="https://lionsandtigers.com/dei" />
            </node>
          </node>
          <node TEXT="Open Roles">
            <node TEXT="List of current open consultant positions, searchable by location." />
            <node TEXT="Consultant Profile Updates Form">
              <node TEXT="Form fields">
                <node TEXT="Name" />
                <node TEXT="Email" />
                <node TEXT="Resume" />
                <node TEXT="Availability" />
              </node>
            </node>
          </node>
          <node TEXT="Newsletter Signup">
            <node TEXT="Enter your email address" />
            <node TEXT="SUBSCRIBE" />
          </node>
          <node TEXT="Stats At a Glance">
            <node TEXT="97.5% consultant retention, $34M paid, 100% remote/hybrid team, 87% women" />
          </node>
          <node TEXT="What Happens After You Apply">
            <node TEXT="Step-by-step: Application reviewed by real person, initial call if fit, no ghosting." />
            <node TEXT="CONSULTANT FAQ">
              <node TEXT="https://lionsandtigers.com/consultant-faq/" />
            </node>
          </node>
          <node TEXT="Team Member Testimonial">
            <node TEXT="Staff reflection on charting own path and focusing on what's important." />
          </node>
        </node>
        <node TEXT="Resources">
          <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/">
            <node TEXT="Avoiding the All-Or-Nothing Workplace: enabling people to operate at their highest   best use">
              <node TEXT="Brea Starmer, Founder/CEO" LINK="https://lionsandtigers.com/brea-starmer/" />
              <node TEXT="Download a pdf of the playbook">
                <node TEXT="here" LINK="https://lionsandtigers.com/playbook-download/" />
              </node>
              <node TEXT="Listen to the">
                <node TEXT="audio version." LINK="https://player.captivate.fm/episode/ae64d6e2-5fb9-49fb-95e8-46d0a2433c68" />
              </node>
            </node>
            <node TEXT="Contents">
              <node TEXT="The Future Now of Work" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#future-now-of-work">
                <node TEXT="How I Lost My Job and Found My Way" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#lost-my-job" />
                <node TEXT="The Workplace Isn’t Working for Everyone" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#workplace-isnt-working" />
                <node TEXT="The “Great Resignation”" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#great-resignation" />
                <node TEXT="We’re Losing Those We Most Seek" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#losing-those-we-seek" />
                <node TEXT="Where’d They Go? 50% Independent" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#whered-they-go" />
              </node>
              <node TEXT="We Must Adopt Blended Work Ecosystems" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#blended-work-ecosystems" />
              <node TEXT="The Era of Sustainability: Measuring Impact Over Hours" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#era-of-sustainability" />
              <node TEXT="Reimagining the Workplace with the Highest   Best Use Operating System™" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#reimagining-the-workplace">
                <node TEXT="The Highest   Best Use Operating System" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-op-system" />
                <node TEXT="The 3Ms of HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#3ms-hbu" />
                <node TEXT="Applying the 3Ms to our Blended Work Ecosystem" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#3ms-blended-work" />
              </node>
              <node TEXT="Our Process of Establishing HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#establishing-hbu">
                <node TEXT="First Step: Highest   Best ORGANIZATION" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-organization" />
                <node TEXT="Second Step: Highest   Best YOU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-you" />
                <node TEXT="Third Step: Highest   Best COMMUNITY" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hbu-community" />
                <node TEXT="Stitching It All Together: Your Ecosystem is Unique" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#stitching-it-all-together" />
              </node>
              <node TEXT="Unlocking HBU: High-EQ Change Management" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#unlocking-hbu" />
              <node TEXT="Blending Our Workforce: Natalie’s Example" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#natalies-example" />
              <node TEXT="Building the Plane While You Fly It" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#building-the-plane" />
              <node TEXT="Very Practical Advice for Proliferating HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#practical-advice" />
              <node TEXT="How to Convince Your Boss or Peers You Need HBU" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#convince-your-boss" />
              <node TEXT="The P L Benefits of a Blended Workforce" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#benefits-of-blended" />
              <node TEXT="Human Resources vs Procurement: Who Manages the Blended Workforce?" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#hr-procurement" />
              <node TEXT="A Few Things to Dream About" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#dream" />
              <node TEXT="Every Org Needs a “Gig Economy”" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#gig-economy" />
              <node TEXT="Commitments to Diversity are Now Public" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#commitments-to-diversity" />
              <node TEXT="Portable Benefits for Independent Workers" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#portable-benefits" />
              <node TEXT="Hybrid   Flex Work Permanence" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#work-permanence" />
              <node TEXT="In Conclusion" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/#conclusion" />
            </node>
            <node TEXT="Newsletter Signup Form">
              <node TEXT="Email input" />
              <node TEXT="Subscribe" />
            </node>
            <node TEXT="Key Links">
              <node TEXT="Reach out to our team" LINK="https://lionsandtigers.com/talk-to-us/" />
              <node TEXT="our blog" LINK="https://lionsandtigers.com/blog/" />
              <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/">
                <node TEXT="Client Newsletter">
                  <node TEXT="Summary">Learn about solutions, success stories, best practices, and thought leadership.</node>
                  <node TEXT="Form">
                    <node TEXT="Email Address Input" />
                    <node TEXT="Subscribe Button" />
                  </node>
                </node>
                <node TEXT="Talent Newsletter">
                  <node TEXT="Summary">Hear about open roles, events, and talent news from Lions amp; Tigers.</node>
                  <node TEXT="Form">
                    <node TEXT="Email Address Input" />
                    <node TEXT="Subscribe Button" />
                  </node>
                </node>
                <node TEXT="Work with us">
                  <node TEXT="CLIENTS">
                    <node TEXT="TALK TO US">
                      <node TEXT="Link" LINK="https://lionsandtigers.com/talk-to-us/" />
                    </node>
                  </node>
                  <node TEXT="TALENT">
                    <node TEXT="JOIN OUR TEAM">
                      <node TEXT="Link" LINK="https://lionsandtigers.com/join-our-team/" />
                    </node>
                  </node>
                </node>
              </node>
            </node>
          </node>
          <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/">
            <node TEXT="Courage at Work">
              <node TEXT="Summary: Thought leadership, best practices, company news, and people stories" />
            </node>
            <node TEXT="Sections Overview">
              <node TEXT="Thought Leadership   Best Practices">
                <node TEXT="Category link">
                  <node TEXT="thought leadership" LINK="https://lionsandtigers.com/category/thought-leadership/" />
                  <node TEXT="best practices" LINK="https://lionsandtigers.com/category/best-practices/" />
                </node>
              </node>
              <node TEXT="New   Noteworthy">
                <node TEXT="Category link">
                  <node TEXT="noteworthy" LINK="https://lionsandtigers.com/category/noteworthy/" />
                  <node TEXT="new" LINK="https://lionsandtigers.com/category/new/" />
                </node>
              </node>
              <node TEXT="People   Projects">
                <node TEXT="Category link">
                  <node TEXT="people" LINK="https://lionsandtigers.com/category/people/" />
                </node>
              </node>
            </node>
            <node TEXT="Highlighted Posts">
              <node TEXT="Workforce Reimagined Research Launch Event">
                <node TEXT="Event summary: Unlocking the Power of Blended Teams" />
                <node TEXT="read more" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" />
                <node TEXT="Workforce Reimagined Research Launch Event" LINK="https://lionsandtigers.com/workforce-reimagined-research-launch-event/" />
              </node>
              <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic">
                <node TEXT="Event summary: Community picnic and gathering highlights" />
                <node TEXT="read more" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" />
                <node TEXT="Looking Ahead, Together: Highlights from the Lions   Tigers 2025 Picnic" LINK="https://lionsandtigers.com/looking-ahead-together-highlights-from-the-lions-tigers-2025-picnic/" />
              </node>
              <node TEXT="Building Better Workplaces for Women: 3 Power Moves to Help You Grow, Lead, and Thrive">
                <node TEXT="Post summary: Strategies for women's career growth and leadership" />
                <node TEXT="read more" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" />
                <node TEXT="Building Better Workplaces for Women: 3 Power Moves to Help You Grow, Lead, and Thrive" LINK="https://lionsandtigers.com/building-better-workplaces-for-women-3-power-moves-to-help-you-grow-lead-and-thrive/" />
              </node>
              <node TEXT="Elevating Culture   Community: Miranda Leurquin’s New Chapter at L T">
                <node TEXT="Post summary: Leadership journey and positive team impact" />
                <node TEXT="read more" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" />
                <node TEXT="Elevating Culture   Community:  Miranda Leurquin’s New Chapter at L T" LINK="https://lionsandtigers.com/elevating-culture-community-miranda-hickmans-new-chapter-at-lt/" />
              </node>
              <node TEXT="Older Entries">
                <node TEXT="« Older Entries" LINK="https://lionsandtigers.com/blog/page/2/?et_blog" />
              </node>
            </node>
            <node TEXT="Newsletter Signup">
              <node TEXT="Form">
                <node TEXT="Email" />
                <node TEXT="SUBSCRIBE" />
                <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/" />
              </node>
            </node>
          </node>
          <node TEXT="Newsletter" LINK="https://lionsandtigers.com/newsletter/" />
        </node>
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
      </node>
    </node>
    <node TEXT="Page Content">
      <node TEXT="Hero Section">
        <node TEXT="Build Your Dream Team" />
        <node TEXT="Description">
          <node TEXT="Highly skilled marketing, comms, operations   change specialists waiting for you. Drive your business   your people forward – no compromises." />
        </node>
        <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/" />
        <node TEXT="Hero Image" />
      </node>
      <node TEXT="Trusted By">
        <node TEXT="Logos">
          <node TEXT="Minecraft" />
          <node TEXT="Tribute" />
          <node TEXT="Xbox" />
          <node TEXT="Ada Developers Academy" />
          <node TEXT="Alaska Airlines" />
          <node TEXT="GitHub" />
          <node TEXT="Microsoft" />
        </node>
      </node>
      <node TEXT="Model Section">
        <node TEXT="Our model fits your needs   our people" />
        <node TEXT="Description">
          <node TEXT="We design the solutions that fit your needs – today   tomorrow." />
        </node>
        <node TEXT="Model Types">
          <node TEXT="Full-time   Fractional" />
          <node TEXT="Individuals   Teams" />
          <node TEXT="Time   Outcome Based" />
        </node>
      </node>
      <node TEXT="Clients   Talent Section">
        <node TEXT="Clients">
          <node TEXT="TALK TO US Button" LINK="https://lionsandtigers.com/talk-to-us/" />
        </node>
        <node TEXT="Talent">
          <node TEXT="JOIN OUR TEAM Button" LINK="https://lionsandtigers.com/join-our-team/" />
        </node>
      </node>
      <node TEXT="Testimonial Section">
        <node TEXT="A Word From Our Clients" />
        <node TEXT="Testimonial Quote" />
        <node TEXT="Client Name: DeAnna Paddleford" />
        <node TEXT="Client Title: Change Management Strategy Lead" />
      </node>
      <node TEXT="Culture Section">
        <node TEXT="Want to build a culture of high performance   belonging?" />
        <node TEXT="Description">
          <node TEXT="We built a playbook for leaders who are thinking about workforce innovation and need a system for change. Our Highest   Best Use Operating System™ maximizes human potential aligned to business outcomes, while guarding against burnout and exclusion." />
        </node>
        <node TEXT="LEARN MORE Button" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
      </node>
      <node TEXT="Vision   Mission Section">
        <node TEXT="Vision   Mission" />
        <node TEXT="Vision">
          <node TEXT="To unlock the full potential of the workforce." />
        </node>
        <node TEXT="Mission">
          <node TEXT="We strengthen businesses with the power of the independent workforce by building blended, human-centered teams." />
        </node>
        <node TEXT="OUR STORY Button" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Team Image" />
      </node>
      <node TEXT="Work with us Section" />
    </node>
    <node TEXT="Footer">
      <node TEXT="Logo" />
      <node TEXT="Company Description">
        <node TEXT="PROFESSIONAL STAFFING   WORKFORCE SOLUTIONS PARTNER" />
      </node>
      <node TEXT="About Us">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" />
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" />
        <node TEXT="DEI" LINK="https://lionsandtigers.com/dei/" />
      </node>
      <node TEXT="Solutions">
        <node TEXT="Working Together" LINK="https://lionsandtigers.com/solutions/#working-together" />
        <node TEXT="Engagement Model" LINK="https://lionsandtigers.com/solutions/#engagement-model" />
        <node TEXT="Capabilities   Skillsets" LINK="https://lionsandtigers.com/solutions/#capabilities-skillsets" />
        <node TEXT="Case Studies" LINK="https://lionsandtigers.com/solutions/#client-stories" />
      </node>
      <node TEXT="Resources">
        <node TEXT="Hybrid Workplace Playbook" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
        <node TEXT="Blog" LINK="https://lionsandtigers.com/blog/" />
        <node TEXT="Media" LINK="https://lionsandtigers.com/media/" />
        <node TEXT="General Inquiries" LINK="https://lionsandtigers.com/general-inquiries/" />
      </node>
      <node TEXT="Newsletter">
        <node TEXT="Newsletter Description">
          <node TEXT="Learn about our solutions, our success stories, best practices, and thought leadership." />
        </node>
        <node TEXT="Email Form">
          <node TEXT="Email (input field)" />
        </node>
      </node>
      <node TEXT="Privacy Policy" LINK="https://lionsandtigers.com/privacy-policy/" />
      <node TEXT="Social Media">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers" />
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco" />
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/" />
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco" />
      </node>
      <node TEXT="Do Not Sell or Share My Personal Information" />
      <node TEXT="Cookie Policy" />
    </node>
  </node>
</map>