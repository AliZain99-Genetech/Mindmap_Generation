<map version="1.0.1">
    <node TEXT="Profile">
        <node TEXT="ALI ZAIN">
            <node TEXT="Edit Profile">
                <node TEXT="Edit Profile" LINK="https://www.340bpriceguide.net/profile/profile?layout=edit"/>
            </node>
        </node>
        <node TEXT="DETAILS">
            <node TEXT="Username: Ali"/>
            <node TEXT="First Name: Ali"/>
            <node TEXT="Last Name: Zain"/>
            <node TEXT="Clinic/Hospital: ABC"/>
            <node TEXT="Email Address">
                <node TEXT="alizainsharif48@gmail.com" LINK="mailto:alizainsharif48@gmail.com"/>
            </node>
            <node TEXT="Phone Number"/>
            <node TEXT="Default Pharmacy"/>
            <node TEXT="Default Group"/>
        </node>
    </node>
</map>