<map version="1.0.1">
  <node TEXT="Contact">
    <node TEXT="Contact Form">
      <node TEXT="Name: *"/>
      <node TEXT="Email: *"/>
      <node TEXT="Company:"/>
      <node TEXT="Address:"/>
      <node TEXT="City, State Zip:"/>
      <node TEXT="Phone:"/>
      <node TEXT="Inquiry Type: *">
        <node TEXT="-- Please select --"/>
      </node>
      <node TEXT="Comment or Question: *"/>
      <node TEXT="Captcha: *"/>
    </node>
    <node TEXT="Submit">
      <node TEXT="Submit"/>
    </node>
  </node>
</map>