<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home Page" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Home" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search" FOLDED="true">
        <node TEXT="Page Title" FOLDED="true">
          <node TEXT="Search" FOLDED="true" />
        </node>
        <node TEXT="Main Content" FOLDED="true">
          <node TEXT="Search Medication or NDC or Therap" FOLDED="true">
            <node TEXT="Search Comments" FOLDED="true">
              <node TEXT="Search Comme" FOLDED="true" />
              <node TEXT="Q" FOLDED="true" />
            </node>
            <node TEXT="Sort by" FOLDED="true">
              <node TEXT="Newest" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Frequently Searched Products" FOLDED="true">
            <node TEXT="ADVAIR HFA 230-21..." LINK="https://www.340bpriceguide.net/340b-search#486" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_486.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="BREO ELLIPTA 100-25..." LINK="https://www.340bpriceguide.net/340b-search#488" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_488.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="BUTRANS 5 MCG/HR..." LINK="https://www.340bpriceguide.net/340b-search#14857" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_14857.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="DULERA 200 MCG-5..." LINK="https://www.340bpriceguide.net/340b-search#13331" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_13331.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="FARXIGA 10 MG TABL....." LINK="https://www.340bpriceguide.net/340b-search#116" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_116.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="JANUVIA 100 MG TAB..." LINK="https://www.340bpriceguide.net/340b-search#534" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_534.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="JARDIANCE 10 MG TA..." LINK="https://www.340bpriceguide.net/340b-search#185" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_185.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LANTUS SOLOSTAR 1..." LINK="https://www.340bpriceguide.net/340b-search#588" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_588.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LIDOCAINE 5% PATCH" LINK="https://www.340bpriceguide.net/340b-search#2310" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_2310.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LYRICA 100 MG CAPS..." LINK="https://www.340bpriceguide.net/340b-search#19309" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_19309.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="PROAIR RESPICLICK..." LINK="https://www.340bpriceguide.net/340b-search#18373" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_18373.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="TRADJENTA 5 MG TA..." LINK="https://www.340bpriceguide.net/340b-search#167" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_167.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="TRULICITY 1.5 MG/0...." LINK="https://www.340bpriceguide.net/340b-search#365" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_365.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="VICTOZA 2-PAK 18 M..." LINK="https://www.340bpriceguide.net/340b-search#13214" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_13214.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="XARELTO 10 MG TAB..." LINK="https://www.340bpriceguide.net/340b-search#9718" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_9718.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Comments" FOLDED="true">
            <node TEXT="Sophie Mengele" FOLDED="true">
              <node TEXT="User reports issues with Synjardy availability and 340B pricing at CVS pharmacies." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Torey explains the correct procedure for CVS pharmacies to use 340B coupon codes." FOLDED="true" />
            </node>
            <node TEXT="Tammy McCullough" FOLDED="true">
              <node TEXT="User asks about the return of the mobile app." FOLDED="true"><node TEXT="Displays information about the organization or product." FOLDED="true" /></node>
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Torey confirms the mobile app is available and provides a link to a tutorial." FOLDED="true" />
            </node>
            <node TEXT="Steven Busselen" FOLDED="true">
              <node TEXT="User questions the quantity of Synjardy dispensed by CVS." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Torey explains the normal dosing and pharmacy practices for Synjardy." FOLDED="true" />
            </node>
            <node TEXT="Sarah Munoz" FOLDED="true">
              <node TEXT="User asks if Levemir FlexPen is still covered." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Torey explains that Levemir has been removed due to discontinuation by Novo Nordisk." FOLDED="true" />
            </node>
            <node TEXT="Sandra Dardy" FOLDED="true">
              <node TEXT="User asks if lispro or 70/30 insulin is covered." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Torey confirms that lispro/70-30 is covered and suggests search terms." FOLDED="true" />
            </node>
            <node TEXT="Kirk J." FOLDED="true">
              <node TEXT="User asks about the unit cost calculation on the 340B Price Guide." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Torey explains how to select pharmacy and quantity to see the estimated cost." FOLDED="true" />
            </node>
            <node TEXT="Anonymous" FOLDED="true">
              <node TEXT="User asks how to select medications from their formulary." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Torey explains how to choose a formulary on the website." FOLDED="true" />
            </node>
            <node TEXT="Kim Kelly" FOLDED="true">
              <node TEXT="User reports discrepancies in Farxiga/Symbicort availability at Genoa." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Torey offers to contact the 340B program manager to investigate." FOLDED="true"><node TEXT="Opens contact form or company contact details." FOLDED="true" /></node>
            </node>
            <node TEXT="Kristan Stone" FOLDED="true">
              <node TEXT="User asks if Pennsaid is no longer on the 340B." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Torey confirms Pennsaid is not available and suggests an alternative." FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Torey mentions Levemir's removal and links to an article." FOLDED="true" />
            </node>
            <node TEXT="Load more comments" FOLDED="true" />
          </node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node><node TEXT="Executes a search query across site data." FOLDED="true" /></node>
      <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news" FOLDED="true">
        <node TEXT="Page Title" FOLDED="true">
          <node TEXT="Articles and News - 340B Price Guide" FOLDED="true" />
        </node>
        <node TEXT="Main Content" FOLDED="true">
          <node TEXT="Weekly Product Shortages" FOLDED="true">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Manufacturer 340B Restrictions for Oregon" FOLDED="true">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_144-status-of-manufacturer-340b-restrictions-for-oregon.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026" FOLDED="true">
            <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026." FOLDED="true">
              <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_143-changes-to-novo-nordisk-patient-assistance-program-pap-2026.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Bausch Health Exits the 340B Drug Pricing Program" FOLDED="true">
            <node TEXT="Effective October 1, 2025, Bausch Health has ended its participation in the 340B Drug Pricing Program." FOLDED="true">
              <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_142-bausch-health-exits-the-340b-drug-pricing-program.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="More Articles" FOLDED="true">
            <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" FOLDED="true" />
            <node TEXT="Communication from BPHC announcing new award terms" FOLDED="true" />
            <node TEXT="Rite Aid Winds Down 340B Operations" FOLDED="true" />
            <node TEXT="Continued Brand Name Victoza Shortages" FOLDED="true" />
          </node>
          <node TEXT="Pagination" FOLDED="true">
            <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_8.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_12.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_16.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node><node TEXT="Moves to the next step in a process or wizard." FOLDED="true" /></node>
            <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us" FOLDED="true">
        <node TEXT="Main Content" FOLDED="true">
          <node TEXT="About" FOLDED="true">
            <node TEXT="340B Price Guide is a customized publication helping entities interpret drug prices." FOLDED="true" />
          </node>
          <node TEXT="340B Guided Services" FOLDED="true">
            <node TEXT="340B Price Guide, LLC offers independent consulting for covered entities." FOLDED="true" />
          </node>
          <node TEXT="Client Testimonials" FOLDED="true">
            <node TEXT="Marvin Roman, M.D." FOLDED="true">
              <node TEXT="340B Price Guide is excellent and saves time figuring out patient affordability." FOLDED="true" />
            </node>
            <node TEXT="Kylie Fonteno, PA-C" FOLDED="true">
              <node TEXT="340B Price Guide helps see patient savings and stay updated on price changes." FOLDED="true" />
            </node>
            <node TEXT="David Homyk" FOLDED="true">
              <node TEXT="340B Price Guide is excellent and helpful for staff communication." FOLDED="true" />
            </node>
            <node TEXT="Connie Serra, MD" FOLDED="true">
              <node TEXT="340B Price Guide was incredibly helpful in solving a pricing dilemma." FOLDED="true" />
            </node>
            <node TEXT="Charity Aguirre LPN" FOLDED="true">
              <node TEXT="340B pricing helped a patient afford medication." FOLDED="true" />
            </node>
          </node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_about-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us" FOLDED="true">
        <node TEXT="Main Content" FOLDED="true">
          <node TEXT="Contact Form" FOLDED="true">
            <node TEXT="Name Field" FOLDED="true" />
            <node TEXT="Email Field" FOLDED="true" />
            <node TEXT="Company Field" FOLDED="true" />
            <node TEXT="Address Field" FOLDED="true" />
            <node TEXT="City, State Zip Field" FOLDED="true" />
            <node TEXT="Phone Field" FOLDED="true" />
            <node TEXT="Inquiry Type" FOLDED="true" />
            <node TEXT="Comment or Question" FOLDED="true"><node TEXT="Adds a note or feedback to an item." FOLDED="true" /></node>
            <node TEXT="Captcha" FOLDED="true" />
            <node TEXT="Submit" FOLDED="true"><node TEXT="Sends form data to the server." FOLDED="true" /></node>
          </node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_contact-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Main Content" FOLDED="true">
      <node TEXT="Hero Section" FOLDED="true">
        <node TEXT="Enter a medication" FOLDED="true">
          <node TEXT="Search Field" FOLDED="true" />
          <node TEXT="Find 340B Prices" FOLDED="true" />
        </node>
        <node TEXT="Values" FOLDED="true">
          <node TEXT="Compassion" FOLDED="true" />
          <node TEXT="Respect" FOLDED="true" />
          <node TEXT="Excellence" FOLDED="true" />
          <node TEXT="Empowerment" FOLDED="true" />
          <node TEXT="Community Health Centers Of Lane County" FOLDED="true" />
        </node>
      </node>
      <node TEXT="What is 340B?" FOLDED="true">
        <node TEXT="For the past 25 years, 340B has helped provide low-cost medications and better health..." FOLDED="true" />
      </node>
      <node TEXT="Weekly Product Shortages" FOLDED="true" />
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Useful Links" FOLDED="true">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/index.php" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_about-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_articles-news.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_contact-us.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information" FOLDED="true">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us" FOLDED="true">
        <node TEXT="501 Fourth Street, #854 Lake Oswego, OR 97034" FOLDED="true" />
        <node TEXT="Phone: (503)592-0681" FOLDED="true" />
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" FOLDED="true" />
      </node>
      <node TEXT="Disclaimer" FOLDED="true">
        <node TEXT="The 340B Drug Pricing Program is managed by the Health Resources and Services Administration (HRSA) Office of Pharmacy Affairs (OPA). For more information visit: www.hrsa.gov/opa" FOLDED="true" />
        <node TEXT="This material is provided for general informational purposes..." FOLDED="true" />
      </node>
    <node TEXT="Displays footer information and links." FOLDED="true" /></node>
    <node TEXT="Login" FOLDED="true"><node TEXT="After Login Flow" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/" FOLDED="true">
        <node TEXT="Navigation" FOLDED="true" />
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search" FOLDED="true">
        <node TEXT="Search Medication or NDC or Therap" FOLDED="true" />
        <node TEXT="Please assign pharmacy from the portal first." FOLDED="true" />
        <node TEXT="1 TABLET" FOLDED="true" />
        <node TEXT="Choose Patient Group" FOLDED="true" />
        <node TEXT="Choose Formulary" FOLDED="true" />
        <node TEXT="Clear All Data" FOLDED="true" />
        <node TEXT="FREQUENTLY SEARCHED PRODUCTS" FOLDED="true">
          <node TEXT="ADVAIR HFA 230-21 MCG INHALERADVAIR HFA 230-21 MCG INHALER" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#486" FOLDED="true" />
          </node>
          <node TEXT="BREO ELLIPTA 100-25 MCG INHALRBREO ELLIPTA 100-25 MCG INHALR" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#488" FOLDED="true" />
          </node>
          <node TEXT="BUTRANS 5 MCG/HR PATCHBUTRANS 5 MCG/HR PATCH" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#14857" FOLDED="true" />
          </node>
          <node TEXT="DULERA 200 MCG-5 MCG INHALERDULERA 200 MCG-5 MCG INHALER" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#13331" FOLDED="true" />
          </node>
          <node TEXT="FARXIGA 10 MG TABLETFARXIGA 10 MG TABLET" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#116" FOLDED="true" />
          </node>
          <node TEXT="JANUVIA 100 MG TABLETJANUVIA 100 MG TABLET" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#534" FOLDED="true" />
          </node>
          <node TEXT="JARDIANCE 10 MG TABLETJARDIANCE 10 MG TABLET" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#185" FOLDED="true" />
          </node>
          <node TEXT="LANTUS SOLOSTAR 100 UNIT/MLLANTUS SOLOSTAR 100 UNIT/ML" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#588" FOLDED="true" />
          </node>
          <node TEXT="LIDOCAINE 5% PATCHLIDOCAINE 5% PATCH" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#2310" FOLDED="true" />
          </node>
          <node TEXT="LYRICA 100 MG CAPSULELYRICA 100 MG CAPSULE" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#19309" FOLDED="true" />
          </node>
          <node TEXT="PROAIR RESPICLICK 90 MCG INHLRPROAIR RESPICLICK 90 MCG INHLR" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#18373" FOLDED="true" />
          </node>
          <node TEXT="TRADJENTA 5 MG TABLETTRADJENTA 5 MG TABLET" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#167" FOLDED="true" />
          </node>
          <node TEXT="TRULICITY 1.5 MG/0.5 ML PENTRULICITY 1.5 MG/0.5 ML PEN" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#365" FOLDED="true" />
          </node>
          <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PENVICTOZA 2-PAK 18 MG/3 ML PEN" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#13214" FOLDED="true" />
          </node>
          <node TEXT="XARELTO 10 MG TABLETXARELTO 10 MG TABLET" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/340b-search#9718" FOLDED="true" />
          </node>
        </node>
        <node TEXT="COMMENTS" FOLDED="true">
          <node TEXT="Ali Zain" FOLDED="true">
            <node TEXT="What do you think?" FOLDED="true" />
            <node TEXT="Post" FOLDED="true" />
          </node>
          <node TEXT="Search Comments" FOLDED="true">
            <node TEXT="Search Comme" FOLDED="true" />
          </node>
          <node TEXT="Sort by" FOLDED="true">
            <node TEXT="Newest" FOLDED="true" />
          </node>
          <node TEXT="Sophie Mengele" FOLDED="true">
            <node TEXT="User tried sending in Synjardy to 2 different pharmacies now and had issues with discount" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            <node TEXT="Responds to an existing comment or thread." FOLDED="true" /></node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            <node TEXT="Shares content via link or social media." FOLDED="true" /></node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="CVS pharmacy needs to enter the 340B coupon codes by first searching the TPPC code" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Tammy McCullough" FOLDED="true">
            <node TEXT="when can we expect the App to come back?" FOLDED="true"><node TEXT="Returns to the previous screen or step." FOLDED="true" /></node>
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Hi Tammy, the mobile app has been available for several months." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Steven Busselen" FOLDED="true">
            <node TEXT="I've noticed that a 1-year supply is often not much more expensive that a 90-day supply." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="As you know, the normal dosing for Synjardy is 2 tablets twice daily, so a 90 day supply would be 180 tablets." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Sarah Munoz" FOLDED="true">
            <node TEXT="Is Levemir FlexPen 100unit/mL still covered?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Hi Sarah, in November 2023, Novo Nordisk announced it would discontinue Levemir with remaining supplies to end this year." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Share" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Sandra Dardy" FOLDED="true">
            <node TEXT="is lispro or 70/30 insulin covered under 340b program?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
            <node TEXT="Torey Lam" FOLDED="true">
              <node TEXT="Hi Sandra, yes it is. Try searching &quot;Novolin&quot; or &quot;Novolog&quot;" FOLDED="true" />
              <node TEXT="Reply" FOLDED="true">
                <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
              </node>
            </node>
          </node>
          <node TEXT="Kirk J." FOLDED="true">
            <node TEXT="On the 340b Price Guide is the unit cost $0.04 the cost per pill?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="On the far left, remember to select the pharmacy, quantity, and patient group." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Anonymous" FOLDED="true">
            <node TEXT="How do I select medications from our formulary?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Hi Stacy, On the far left, where you search for medications, there is a drop-down option, &quot;Choose Formulary.&quot;" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Kim Kelly" FOLDED="true">
            <node TEXT="I am seeing Farxiga and symbicort as available at Genoa on 340B but the Genoa pharmacists say they are not available." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Hi Kim, I'll contact your 340B program manager to see what is going on here." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Kristan Stone" FOLDED="true">
            <node TEXT="is Pennsaid no longer on the 340b?" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Unfortunately, it is not. Please try searching for DICLOFENAC 1.5% TOPICAL SOLN." FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Torey Lam" FOLDED="true">
            <node TEXT="Levemir has been removed from 340B Price Guide since Novo Nordisk will discontinue it" FOLDED="true" />
            <node TEXT="Reply" FOLDED="true">
              <node TEXT="https://www.340bpriceguide.net/340b-search" FOLDED="true" />
            </node>
          </node>
          <node TEXT="Load more comments" FOLDED="true" />
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news" FOLDED="true">
        <node TEXT="Weekly Product Shortages" FOLDED="true">
          <node TEXT="Read more ..." FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true" />
          </node>
          <node TEXT="Print" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages?tmpl=component&amp;print=1&amp;layout=default" FOLDED="true" />
          <node TEXT="Sends current page or data to printer." FOLDED="true" /></node>
          <node TEXT="Email" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=48f36ca13f26e4d5730c8eb5ff22f26733881327" FOLDED="true" />
          </node>
        </node>
        <node TEXT="Manufacturer 340B Restrictions for Oregon" FOLDED="true">
          <node TEXT="Read more ..." FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" FOLDED="true" />
          </node>
          <node TEXT="Print" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon?tmpl=component&amp;print=1&amp;layout=default" FOLDED="true" />
          </node>
          <node TEXT="Email" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=b6e19967b78cdac7c6c13cbbfc280d6e2dbb5cc9" FOLDED="true" />
          </node>
        </node>
        <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026" FOLDED="true">
          <node TEXT="Read more ..." FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" FOLDED="true" />
          </node>
          <node TEXT="Print" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026?tmpl=component&amp;print=1&amp;layout=default" FOLDED="true" />
          </node>
          <node TEXT="Email" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=7519cc1dcaee0c8a80b4e0ec10cc94c9d82ee5cb" FOLDED="true" />
          </node>
        </node>
        <node TEXT="Bausch Health Exits the 340B Drug Pricing Program" FOLDED="true">
          <node TEXT="Read more ..." FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" FOLDED="true" />
          </node>
          <node TEXT="Print" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program?tmpl=component&amp;print=1&amp;layout=default" FOLDED="true" />
          </node>
          <node TEXT="Email" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/component/mailto/?tmpl=component&amp;template=rt_chapelco_child&amp;link=915b7f8f4733ba08ede3e87c060f748bad1a471b" FOLDED="true" />
          </node>
        </node>
        <node TEXT="Pagination" FOLDED="true">
          <node TEXT="2" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true" />
          </node>
          <node TEXT="3" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=8" FOLDED="true" />
          </node>
          <node TEXT="4" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=12" FOLDED="true" />
          </node>
          <node TEXT="5" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=16" FOLDED="true" />
          </node>
          <node TEXT="6" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true" />
          </node>
          <node TEXT="7" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=24" FOLDED="true" />
          </node>
          <node TEXT="Next" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true" />
          </node>
          <node TEXT="End" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news?start=24" FOLDED="true" />
          </node>
        </node>
        <node TEXT="More Articles" FOLDED="true">
          <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" FOLDED="true" />
          </node>
          <node TEXT="Communication from BPHC announcing new award terms" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" FOLDED="true" />
          </node>
          <node TEXT="Rite Aid Winds Down 340B Operations" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" FOLDED="true" />
          </node>
          <node TEXT="Continued Brand Name Victoza Shortages" FOLDED="true">
            <node TEXT="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" FOLDED="true" />
          </node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us" FOLDED="true">
        <node TEXT="340B Price Guide" FOLDED="true">
          <node TEXT="customized, entity-specific publication available to Federally Qualified Health Centers" FOLDED="true" />
        </node>
        <node TEXT="340B Guided Services" FOLDED="true">
          <node TEXT="340B Price Guide, LLC. offers independent 340B consulting" FOLDED="true" />
        </node>
        <node TEXT="Client Testimonials" FOLDED="true">
          <node TEXT="340B Price Guide is excellent" FOLDED="true">
            <node TEXT="Marvin Roman, M.D." FOLDED="true" />
          </node>
          <node TEXT="The 340B Price Guide really helps me" FOLDED="true">
            <node TEXT="Kylie Fonteno, PA-C" FOLDED="true" />
          </node>
          <node TEXT="340B Price Guide is excellent and has been very helpful" FOLDED="true">
            <node TEXT="David Homyk" FOLDED="true" />
          </node>
          <node TEXT="I used 340 Price Guide today!" FOLDED="true">
            <node TEXT="Connie Serra, MD" FOLDED="true" />
          </node>
          <node TEXT="I have a 69 y/o pt that was put on Januvia with Medicare" FOLDED="true">
            <node TEXT="Charity Aguirre LPN" FOLDED="true" />
          </node>
        </node>
        <node TEXT="Useful Links" FOLDED="true">
          <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_about-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_articles-news.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_contact-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Information" FOLDED="true">
          <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Contact Us." FOLDED="true">
          <node TEXT="info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" FOLDED="true" />
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_about-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us" FOLDED="true">
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="Name: *" FOLDED="true" />
          <node TEXT="Email: *" FOLDED="true" />
          <node TEXT="Company:" FOLDED="true" />
          <node TEXT="Address:" FOLDED="true" />
          <node TEXT="City, State Zip:" FOLDED="true" />
          <node TEXT="Phone:" FOLDED="true" />
          <node TEXT="Inquiry Type: *" FOLDED="true">
            <node TEXT="-- Please select --" FOLDED="true" />
          </node>
          <node TEXT="Comment or Question: *" FOLDED="true" />
          <node TEXT="Captcha: *" FOLDED="true" />
        </node>
        <node TEXT="Submit" FOLDED="true">
          <node TEXT="Submit" FOLDED="true" />
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_contact-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Profile" LINK="https://www.340bpriceguide.net/my-profile" FOLDED="true">
        <node TEXT="ALI ZAIN" FOLDED="true">
          <node TEXT="Edit Profile" FOLDED="true">
            <node TEXT="Edit Profile" LINK="https://www.340bpriceguide.net/profile/profile?layout=edit" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_profile_profile_layout_edit.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
        </node>
        <node TEXT="DETAILS" FOLDED="true">
          <node TEXT="Username: Ali" FOLDED="true" />
          <node TEXT="First Name: Ali" FOLDED="true" />
          <node TEXT="Last Name: Zain" FOLDED="true" />
          <node TEXT="Clinic/Hospital: ABC" FOLDED="true" />
          <node TEXT="Email Address" FOLDED="true">
            <node TEXT="alizainsharif48@gmail.com" LINK="mailto:alizainsharif48@gmail.com" FOLDED="true" />
          </node>
          <node TEXT="Phone Number" FOLDED="true" />
          <node TEXT="Default Pharmacy" FOLDED="true" />
          <node TEXT="Default Group" FOLDED="true" />
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_my-profile.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node><node TEXT="User profile details and account settings." FOLDED="true" /></node>
      <node TEXT="Logout" LINK="https://www.340bpriceguide.net/logout" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_logout.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node><node TEXT="Ends user session and logs out of the system." FOLDED="true" /></node>
      <node TEXT="SecureMsg" LINK="https://www.340bpriceguide.net/secure-message" FOLDED="true">
        <node TEXT="SEND SECURE MESSAGE" FOLDED="true">
          <node TEXT="Form" FOLDED="true" />
          <node TEXT="Patient Name" FOLDED="true" />
          <node TEXT="Patient DOB" FOLDED="true" />
          <node TEXT="Pharmacy" FOLDED="true" />
          <node TEXT="Medication and Strength" FOLDED="true" />
          <node TEXT="Prescription Number (if available)" FOLDED="true" />
          <node TEXT="Contact at the pharmacy (if available)" FOLDED="true" />
          <node TEXT="Problem/Comment" FOLDED="true" />
          <node TEXT="SUBMIT" FOLDED="true" />
        <node TEXT="Opens a direct message or chat box." FOLDED="true" /></node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_secure-message.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Main Content" FOLDED="true">
      <node TEXT="Community Health Centers Of Lane County" FOLDED="true" />
      <node TEXT="What is 340B?" FOLDED="true" />
      <node TEXT="Weekly Product Shortages" FOLDED="true" />
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Useful Links" FOLDED="true">
        <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/index.php" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_about-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_articles-news.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_contact-us.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information" FOLDED="true">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us" FOLDED="true">
        <node TEXT="Email" LINK="mailto:info@340Bpriceguide.com" FOLDED="true" />
      </node>
      <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/http_www.hrsa.gov_opa.png" width="950" height="500" />
        </p>
      </body>
    </html></richcontent></node></node>
    </node>
  </node>
<node TEXT="Opens authentication form to access user account." FOLDED="true" /></node>
    <node TEXT="Signup" FOLDED="true" />
  <node TEXT="Navigates to the main landing page or dashboard." FOLDED="true"><node TEXT="Centralized area showing user stats and quick actions." FOLDED="true" /></node></node>
</map>