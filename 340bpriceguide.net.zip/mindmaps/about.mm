<map version="1.0.1">
  <node TEXT="About - 340B Price Guide">
    <node TEXT="Main Content">
      <node TEXT="About">
        <node TEXT="340B Price Guide is a customized publication helping entities interpret drug prices."/>
      </node>
      <node TEXT="340B Guided Services">
        <node TEXT="340B Price Guide, LLC offers independent consulting for covered entities."/>
      </node>
      <node TEXT="Client Testimonials">
        <node TEXT="Marvin Roman, M.D.">
          <node TEXT="340B Price Guide is excellent and saves time figuring out patient affordability."/>
        </node>
        <node TEXT="Kylie Fonteno, PA-C">
          <node TEXT="340B Price Guide helps see patient savings and stay updated on price changes."/>
        </node>
        <node TEXT="David Homyk">
          <node TEXT="340B Price Guide is excellent and helpful for staff communication."/>
        </node>
        <node TEXT="Connie Serra, MD">
          <node TEXT="340B Price Guide was incredibly helpful in solving a pricing dilemma."/>
        </node>
        <node TEXT="Charity Aguirre LPN">
          <node TEXT="340B pricing helped a patient afford medication."/>
        </node>
      </node>
    </node>
  </node>
</map>