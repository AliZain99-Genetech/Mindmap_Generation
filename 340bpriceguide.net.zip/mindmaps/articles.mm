<map version="1.0.1">
  <node TEXT="articles">
    <node TEXT="Page Title">
      <node TEXT="Articles and News - 340B Price Guide"/>
    </node>
    <node TEXT="Main Content">
      <node TEXT="Weekly Product Shortages">
        <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages"/>
      </node>
      <node TEXT="Manufacturer 340B Restrictions for Oregon">
        <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon"/>
      </node>
      <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026">
        <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026.">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026"/>
        </node>
      </node>
      <node TEXT="Bausch Health Exits the 340B Drug Pricing Program">
        <node TEXT="Effective October 1, 2025, Bausch Health has ended its participation in the 340B Drug Pricing Program.">
          <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program"/>
        </node>
      </node>
      <node TEXT="More Articles">
        <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September"/>
        <node TEXT="Communication from BPHC announcing new award terms"/>
        <node TEXT="Rite Aid Winds Down 340B Operations"/>
        <node TEXT="Continued Brand Name Victoza Shortages"/>
      </node>
      <node TEXT="Pagination">
        <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4"/>
        <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8"/>
        <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12"/>
        <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16"/>
        <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20"/>
        <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4"/>
        <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=20"/>
      </node>
    </node>
  </node>
</map>