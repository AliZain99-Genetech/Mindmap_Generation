<map version="1.0.1">
  <node TEXT="Contact">
    <node TEXT="Main Content">
      <node TEXT="Contact Form">
        <node TEXT="Name Field"/>
        <node TEXT="Email Field"/>
        <node TEXT="Company Field"/>
        <node TEXT="Address Field"/>
        <node TEXT="City, State Zip Field"/>
        <node TEXT="Phone Field"/>
        <node TEXT="Inquiry Type"/>
        <node TEXT="Comment or Question"/>
        <node TEXT="Captcha"/>
        <node TEXT="Submit" />
      </node>
    </node>
  </node>
</map>